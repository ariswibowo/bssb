# SSL Certificate Generation Instructions

## Generate a new certificate

The below command will use the parameters in the attached elysian-ssl.cnf and also our existing private key file (elysian.key) to generate a new certificate named elysian.crt with a validity period of 3 years (1095 days)

    openssl req -key elysian.key -new -x509 -days 1095 -out elysian.crt -config elysian-ssl.cnf -extensions req_ext

## Create PFX file

The below command will merge elysian.key & elysian.crt into a PFX format file named elysian.pfx

    openssl pkcs12 -inkey elysian.key -in elysian.crt -export -out elysian.pfx

## Optional step

If for some reason we lost our existing private key (elysian.key), then we can use the below commands to generate a new one

    openssl genrsa -des3 -out elysian-encrypted.key 2048
    openssl rsa -in elysian-encrypted.key -out elysian.key

## Other Resources

This article is straightforward and useful in understanding the essential commands in OpenSSL https://www.digitalocean.com/community/tutorials/openssl-essentials-working-with-ssl-certificates-private-keys-and-csrs
