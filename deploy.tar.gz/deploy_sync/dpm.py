#!/usr/bin/python

"""Elysian Component Deployment Manager (DPM) CLI"""

import scripts._cli.cli as cli

if __name__ == "__main__":
    cli.main()
