import os
import json

import scripts.utils.configger as configger


def setDeploy():
    # set deploy environment
    deployName = configger.get("deploy", "#UNNOWN")
    deployManifest = "deploy-{deployName}.json".format(deployName=deployName.lower())
    deployPaths = getDeployPaths()
    deployRoot = None
    deployFile = None

    # attempt to locate the requested deploy
    for deployPath in deployPaths:
        # walk down the deploy path
        for root, _, files in os.walk(deployPath):
            # check file list for deploy file
            deployFile = next((f for f in files if f.lower() == deployManifest), None)
            if deployFile is not None:
                # deploy found!
                deployRoot = root
                break

    # handle no deploy found
    if deployFile is None:
        print("")
        print("Error: Deploy manifest '{deployName}' not found!".format(deployName=deployName))
        print("")
        print("Paths Searched:")
        for deployPath in deployPaths:
            print(deployPath)
        exit(-1)

    # load manifest
    deployManifest = os.path.join(deployRoot, deployFile)
    with open(deployManifest) as m:
        manifest = json.load(m)

    # create deploy parts object
    _deploy = {
        "name": deployName,
        "path": deployPath,
        "root": deployRoot,
        "file": deployFile,
        "manifestFile": deployManifest,
        "manifest": manifest,
    }

    # save pack manifest in configuration
    configger.set("deploy", _deploy)


def getDeployPaths():
    deployPaths = configger.get("deployPaths", [])

    if len(deployPaths) == 0:
        print("")
        print("Error: 'deployPaths' configuration setting is empty or undefined")
        exit(-1)

    return deployPaths
