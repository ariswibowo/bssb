import importlib

import scripts.utils.configger as configger


def loadOrchestrators():
    # load orchestrator deploy module
    deployOrchestrator = importlib.import_module(
        "scripts.deploy.orchestrators.{orchestrator}".format(orchestrator=configger.get("orchestrator")),
    )
    configger.set("orchestrators.deploy", deployOrchestrator)

    # load orchestrator cleanup module
    cleanupOrchestrator = importlib.import_module(
        "scripts.clean.orchestrators.{orchestrator}".format(orchestrator=configger.get("orchestrator")),
    )
    configger.set("orchestrators.cleanup", cleanupOrchestrator)
