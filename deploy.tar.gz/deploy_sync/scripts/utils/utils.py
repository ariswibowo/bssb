import sys
import subprocess
import shlex

# subprocess function for docker commands
def run_command(command, printOutput=True):
    try:
        result = []
        process = subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE)
        while True:
            output = process.stdout.readline().decode('utf-8')
            if output == '' and process.poll() is not None:
                break
            if output:
                if printOutput:
                    print(output,end='',flush=True)
                result.append(output)
        return result
    except KeyboardInterrupt:
        print("Cancelled by user.......")
        sys.exit(0)
    except OSError as e:
        print("Error occured during running: "+ command)
        print(e)
        sys.exit(0)
