import re

import scripts.utils.configger as configger


def composeFile(component, composeFileIn, composeFileOut):
    """converts raw tokenized compose file to token-replaced version"""

    # get raw compose file contents
    with open(composeFileIn) as raw:
        composeText = raw.read()

    # replace tokens with combo of configration tokesn and component tokens
    tokens = {**configger.get("tokens", {}), **component.get("tokens", {})}
    for key, value in tokens.items():
        composeText = composeText.replace("${" + key + "}", value)

    # replace "special" own-handler tokens
    composeText = replaceRdbmsConnectionStrings(composeText)
    composeText = replaceDocumentConnectionStrings(composeText)

    # write adjusted build file
    with open(composeFileOut, "w") as new:
        new.write(composeText)

    return


def replaceRdbmsConnectionStrings(composeText):
    # find all connection string tokens via regex
    # expected format: ${ConnectionString Database=[dbname]}
    connStrTokens = re.findall(r"\$\{ConnectionString.*?\}", composeText)

    # replace each connection string with constructed conn-string
    newText = composeText
    for connStrToken in connStrTokens:
        newText = newText.replace(connStrToken, getRdbmsConnectionString(connStrToken))

    return newText


def getRdbmsConnectionString(token):
    # for connection string construction we need to extract the "Database=[dbname]"
    # and the dbname property from the tokened string; this is not done very
    # elegantly below, but suits current complexity level
    connStrToken = token
    connStrToken = connStrToken.replace("${ConnectionString ", "")
    connStrToken = connStrToken.replace("}", "")
    connStrToken = connStrToken.replace(" ", "")

    database = connStrToken.replace("Database=", "")

    # construct & return connection string based on target Rdbms
    targetRdbms = configger.get("targetRdbms", "#UNKNOWN")
    if targetRdbms == "postgres":
        connProps = configger.get("postgres", {})
        connectionString = "Host={host}; Port={port}; Database={database}; Username={username}; Password={password}; Pooling=false;".format(
            host=connProps["PgHost"],
            port=connProps["PgPort"],
            database=database,
            username=connProps["PgUsername"],
            password=connProps["PgPassword"],
        )
        return connectionString

    if targetRdbms == "sqlserver":
        connProps = configger.get("sqlserver", {})
        connectionString = "Server={server},{port}; Database={database}; User Id={username}; Password={password}; Encrypt=false;".format(
            server=connProps["SqlHost"],
            port=connProps["SqlPort"],
            database=database,
            username=connProps["SqlUsername"],
            password=connProps["SqlPassword"],
        )
        return connectionString

    # earlier validation should make this path unreachable but handle por si las moscas
    return "#ERROR: Unexpected targetRdbms '{targetRdbms}'".format(targetRdbms=targetRdbms)


def replaceDocumentConnectionStrings(composeText):
    # find all connection string tokens via regex
    # expected format: ${DocumentConnectionString Database=[dbname]}
    connStrTokens = re.findall(r"\$\{DocumentConnectionString.*?\}", composeText)

    # replace each connection string with constructed conn-string
    newText = composeText
    for connStrToken in connStrTokens:
        newText = newText.replace(connStrToken, getDocumentConnectionString(connStrToken))

    return newText


def getDocumentConnectionString(token):
    # for connection string construction we need to extract the "Database=[dbname]"
    # and the dbname property from the tokened string; this is not done very
    # elegantly below, but suits current complexity level
    connStrToken = token
    connStrToken = connStrToken.replace("${DocumentConnectionString ", "")
    connStrToken = connStrToken.replace("}", "")
    connStrToken = connStrToken.replace(" ", "")

    database = connStrToken.replace("Database=", "")
    targetDocumentDb = configger.get("targetDocumentDb")

    # check the key first
    if targetDocumentDb in ["", None]:
        return ""

    # construct & return connection string based on target Document Db
    if targetDocumentDb == "arango":
        connProps = configger.get("arango", {})
        connectionString = "Uri={uri}:{port}; Database={database}; Username={username}; Password={password};".format(
            uri=connProps["ArangoUri"],
            port=connProps["ArangoPort"],
            database=database,
            username=connProps["ArangoUsername"],
            password=connProps["ArangoPassword"],
        )

        return connectionString

    # earlier validation should make this path unreachablem but handle por si las moscas
    return "#ERROR: Unexpected targetDocumentDb '{targetDocumentDb}'".format(targetDocumentDb=targetDocumentDb)
