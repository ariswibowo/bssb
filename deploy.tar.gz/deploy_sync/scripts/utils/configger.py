# Standard configuration utility that gets/sets configuration settings.

import os
import sys
import shutil
import json
from benedict import benedict

# config global settings
this = sys.modules[__name__]
this.configFileDefault = "defaultConfig.json"
this.configFile = "localConfig.json"
this.config = None


def get(key=None, default=None):
    """returns a configuration key (or all)"""
    if key is None:
        return _config()

    return _config().get(key, default)


def set(key, value, *, persist=False):
    """sets a configuration key"""
    _config()[key] = value

    # fully persist to config if required
    if persist == True:
        _updateConfig(key, value)


def _config():
    """returns config"""

    # load if empty
    if this.config is None:
        _loadConfig()

    return this.config


def _loadConfig():
    """load config"""

    # set config files
    defaultConfigFile = os.path.join(os.getcwd(), this.configFileDefault)
    configFile = os.path.join(os.getcwd(), this.configFile)

    # create config file from default if not exists
    if not os.path.exists(configFile):
        shutil.copy2(defaultConfigFile, configFile)

    # load default config
    with open(defaultConfigFile) as c:
        defaultConfig = benedict(json.load(c))

    # load local config
    with open(configFile) as c:
        localConfig = benedict(json.load(c))

    # validate configuration
    _validateConfig(defaultConfig, localConfig)

    # set the config
    this.config = localConfig


def _updateConfig(key, value):
    configFile = os.path.join(os.getcwd(), this.configFile)

    # load config
    with open(configFile) as c:
        _config = json.load(c)

    # update config
    _config[key] = value

    # save config
    with open(configFile, "w") as c:
        c.write(json.dumps(_config, indent=2))


def _validateConfig(defaultConfig, localConfig):
    """validate local vs default config to ensure all expected keys are present"""

    # get key paths list
    defaultConfigKeys = defaultConfig.keypaths()
    localConfigKeys = localConfig.keypaths()

    # get missing/extra keys, local vs default config
    missingLocalKeys = list(filter(lambda k: k not in localConfigKeys, defaultConfigKeys))
    extraLocalKeys = list(filter(lambda k: k not in defaultConfigKeys, localConfigKeys))

    # hard-stop if discrepancies found
    if len(missingLocalKeys) > 0 or len(extraLocalKeys) > 0:
        print("")
        print("Oops: Detected one or more missing/extra keys in local config file")
        print("Check against the defaultConfig for settings and adjust local config as required")

        if len(missingLocalKeys) > 0:
            print("")
            print("Missing configuration key(s):")
            for key in missingLocalKeys:
                print(" -> ", key)

        if len(extraLocalKeys) > 0:
            print("")
            print("Extra configuration key(s):")
            for key in extraLocalKeys:
                print(" -> ", key)

        exit(-1)

    # all good
    return True
