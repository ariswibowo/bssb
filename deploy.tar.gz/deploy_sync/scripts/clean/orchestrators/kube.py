import os

import scripts.utils.utils as utils
import scripts.utils.composer as composer


def deleteComponent(component):

    # skip portainer deployment for kubernetes
    if component.get("name") == "Portainer":
        return

    componentDir = "./services/" + component["name"]

    # set compose in/out file names
    composeFileRaw = componentDir + "/Kube-" + component["name"] + ".yml"
    composeFile = componentDir + "/Kube-" + component["name"] + "-deploy.yml"

    composer.composeFile(component, composeFileRaw, composeFile)

    cmd = "kubectl delete -f " + composeFile
    utils.run_command(cmd)

    # remove config file
    configfileName = component["name"].lower() + "-files"
    cmd = "kubectl delete configmap " + configfileName
    utils.run_command(cmd)

    # remove working files
    os.remove(composeFile)

    return


def finalize():
    # finalize hook
    cmd = "kubectl get secrets --ignore-not-found=true elysian-certs"
    output = utils.run_command(cmd, False)
    if output:
        cmd = "kubectl delete secret elysian-certs"
        utils.run_command(cmd)

    cmd = "kubectl get secrets --ignore-not-found=true public-certs"
    output = utils.run_command(cmd, False)
    if output:
        cmd = "kubectl delete secret public-certs"
        utils.run_command(cmd)

    return
