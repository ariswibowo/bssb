import subprocess

import scripts.utils.utils as utils


def deleteComponent(component):
    # remove service
    filter = "name=elysian_{component}".format(component=component["name"].lower())

    cmd = "docker service ls -f {filter} -q".format(filter=filter)
    output = utils.run_command(cmd, False)

    if output:
        cmd = "docker service rm {service}".format(service=output[0])
        utils.run_command(cmd, False)

    # remove configs
    filter1 = "name=elysian_{component}AppSettings".format(component=component["name"].lower())
    filter2 = "name=elysian_{component}RunShell".format(component=component["name"].lower())

    cmd = "docker config ls -f {filter1} -f {filter2} -q".format(filter1=filter1, filter2=filter2)
    output = utils.run_command(cmd, False)

    if output:
        for config in output:
            cmd = "docker config rm {config}".format(config=config)
            utils.run_command(cmd, False)

    return


def finalize():
    # finalize hook
    housekeepSecrets()
    housekeepVolumes()
    return


def housekeepSecrets():
    # remove secrets
    print(f"")
    print(f"Housekeeping secrets...")
    removeSecret("elysian.pfx")
    removeSecret("elysian.crt")
    removeSecret("elysian.key")
    removeSecret("public-cert.key")
    removeSecret("public-cert.crt")
    print(f"")

    return


def removeSecret(secretName):
    # check if the secret exist
    cmd = f"docker secret ls --filter NAME={secretName} -q"
    output = utils.run_command(cmd, False)

    # remove secret; ignore errors
    # (possible "in use" noise if used by other components)
    if output:
        print(f" >>> {secretName}...")
        cmd = f"docker secret rm {secretName}"
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=True)


def housekeepVolumes():
    # remove unused volumes
    print(f"")
    print(f"Housekeeping volumes...")
    cmd = f"docker volume prune --force"
    subprocess.run(cmd, shell=True)
    print(f"")

    return
