import scripts.utils.configger as configger
import scripts.utils.deploys as deploys
import scripts.utils.orchestrators as orchestrators


def clean(*, deploy, orchestrator):
    """multi-component cleanup (using deploy file)"""

    # initialize
    setConfig(locals())
    orchestrators.loadOrchestrators()
    deploys.setDeploy()

    # begin cleanup
    print("")
    print("Cleanup of {orchestrator} components started...".format(orchestrator=configger.get("orchestrator")))
    print("Deploy: {deploy}".format(deploy=configger.get("deploy.name")))
    print("")

    # process components; attempt stop/cleanup
    for _component in configger.get("deploy.manifest.components", []):
        cleanComponent(_component)

    # orchestrator specific finalization
    configger.get("orchestrators.cleanup").finalize()

    print("Cleanup process complete.")


def cleanComponent(component):
    """single-component cleanup (also called during deploy process)"""
    print("Removing component {component}...".format(component=component["name"]))
    configger.get("orchestrators.cleanup").deleteComponent(component)


def setConfig(args):
    # override config (default) values with args values if supplied
    for key in args.keys():
        if args[key] is not None:
            configger.set(key, args[key])
