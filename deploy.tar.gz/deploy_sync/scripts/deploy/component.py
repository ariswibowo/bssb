import scripts.utils.configger as configger

import scripts.clean.cleaner as cleaner


def deploy(component):
    structureComponent(component)

    # begin deploy sequence...
    print("")
    print("Deploying " + component["name"] + ":" + component["tag"] + " to " + component["placement"] + "...")

    # cleanup component before deploy if required
    if component["cleanBeforeDeploy"] == True:
        cleaner.cleanComponent(component)

    # call specific orchestrator to complete the deploy..
    configger.get("orchestrators.deploy").deployComponent(component)


def structureComponent(component):
    # set component props where not explicitly defined
    component["tag"] = component.get("tag", configger.get("imageTag", "#UNKNOWN"))
    component["cleanBeforeDeploy"] = component.get("cleanBeforeDeploy", configger.get("cleanBeforeDeploy", "#UNKNOWN"))
    component["placement"] = component.get("placement", configger.get("componentPlacement", "#UNKNOWN"))

    # set deploy tokens for this component
    component["tokens"] = {
        **configger.get("deploy.tokens"),
        "Tag": component["tag"],
        "Placement": component["placement"],
    }
