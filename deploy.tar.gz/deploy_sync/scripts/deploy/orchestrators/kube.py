import os
import json

import scripts.utils.composer as composer
import scripts.utils.configger as configger
import scripts.utils.utils as utils


def initialize():
    cmd = "kubectl get secrets --ignore-not-found=true elysian-certs"
    output = utils.run_command(cmd, False)

    if not output:
        # create secret to contain the ssl cert to be used for inter component communications
        cmd = "kubectl create secret generic elysian-certs --from-file=certs/"
        utils.run_command(cmd, False)

    cmd = "kubectl get secrets --ignore-not-found=true public-certs"
    output = utils.run_command(cmd, False)

    if not output:
        # create secret to contain the ssl cert files to be used for public facing component
        public_cert_key_file = configger.get("tokens.PublicCertKeyFile")
        public_cert_crt_file = configger.get("tokens.PublicCertCrtFile")
        cmd = f"kubectl create secret generic public-certs --from-file=ssl-private-key={public_cert_key_file} --from-file=ssl-certificate={public_cert_crt_file}"
        utils.run_command(cmd)

    return


def deployComponent(component):

    # skip portainer deployment for kubernetes
    if component.get("name") == "Portainer":
        return

    componentDir = "./services/" + component["name"]

    # set compose in/out file names
    composeFileRaw = componentDir + "/Kube-" + component["name"] + ".yml"
    composeFile = componentDir + "/Kube-" + component["name"] + "-deploy.yml"

    # add image pull policy as token for composer substitution
    configger.set("tokens.imagePullPolicy", configger.get("kube.imagePullPolicy"))

    composer.composeFile(component, composeFileRaw, composeFile)

    configfileName = component["name"].lower() + "-files"

    # create runtime-files configmap, files added defined in Kube-runtime-files.json
    with open(componentDir + "/Kube-runtime-files.json") as runtimeDefFile:
        runtimeDef = json.load(runtimeDefFile)

        cmd = "kubectl create configmap " + configfileName

        for filename in runtimeDef["runtimeFiles"]:
            cmd = cmd + " --from-file=" + componentDir + "/" + filename

        utils.run_command(cmd)

    # ConfigMap in kubernetes not support binary file however secret support binary file
    # Use for mounting the EDrive default template files
    if component.get("name") == "EDrive":
        secretfileName = "edrive-default-templates"
        cmd = "kubectl create secret generic " + secretfileName + " --from-file=" + componentDir + "/default-templates"
        utils.run_command(cmd)

    cmd = "kubectl create -f " + composeFile
    utils.run_command(cmd)

    # remove working files
    os.remove(composeFile)

    return
