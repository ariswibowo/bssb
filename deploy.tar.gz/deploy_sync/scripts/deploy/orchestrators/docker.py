import os

import scripts.utils.composer as composer
import scripts.utils.configger as configger
import scripts.utils.utils as utils


def initialize():
    # deploy secrets
    createSecret("elysian.pfx", "certs/elysian.pfx")
    createSecret("elysian.crt", "certs/elysian.crt")
    createSecret("elysian.key", "certs/elysian.key")
    createSecret("public-cert.key", configger.get("tokens.PublicCertKeyFile"))
    createSecret("public-cert.crt", configger.get("tokens.PublicCertCrtFile"))

    return


def deployComponent(component):

    componentDir = "./services/" + component["name"]

    # compose template YML compose file into actual deploy compose file (replacing tokens)
    composeFileRaw = componentDir + "/Docker-" + component["name"] + ".yml"
    composeFile = componentDir + "/Docker-" + component["name"] + "-deploy.yml"
    composer.composeFile(component, composeFileRaw, composeFile)

    cmd = "docker stack deploy --compose-file {composeFile} elysian --with-registry-auth --resolve-image {resolveImage}".format(
        composeFile=composeFile,
        resolveImage=configger.get("docker.resolveImage", "always"),
    )
    utils.run_command(cmd)

    # remove working files
    os.remove(composeFile)

    return


def createSecret(secret_name, secret_path):
    # check if the secret already exist
    cmd = f"docker secret ls --filter NAME={secret_name} -q"
    output = utils.run_command(cmd, False)

    # secret doesn't exist yet... create it...
    if not output:
        print(f"Creating secret {secret_name} from {secret_path}...")
        cmd = f"docker secret create {secret_name} {secret_path}"
        utils.run_command(cmd, False)
