import os

import scripts.utils.configger as configger
import scripts.utils.deploys as deploys
import scripts.utils.orchestrators as orchestrators

from . import component


def deploy(*, deploy, targetRdbms, orchestrator):
    # initialize
    setConfig(locals())
    deploys.setDeploy()
    orchestrators.loadOrchestrators()

    # begin deployment
    print("")
    print("Deployment to {orchestrator} started...".format(orchestrator=configger.get("orchestrator")))
    print("Deploy: {deploy}".format(deploy=configger.get("deploy.name")))
    print("Target: {target}".format(target=configger.get("targetRdbms")))
    print("Tag: {tag}".format(tag=configger.get("imageTag")))
    print("")

    # initialize deploy
    initialize()

    # process components; attempt deploy
    for _component in configger.get("deploy.manifest.components", []):
        component.deploy(_component)

    print("")
    print("Deployment process complete.")


def setConfig(args):
    # override config (default) values with args values if supplied
    for key in args.keys():
        if args[key] is not None:
            configger.set(key, args[key])


def initialize():
    # set standard deploy tokens
    tokens = {
        "DatabaseEngine": getDatabaseEngine(),
        "DocumentDatabaseEngine": getDocumentDatabaseEngine(),
        "ApplicationUsername": configger.get("applicationAuthentication.Username", "#UNKNOWN"),
        "ApplicationPassword": configger.get("applicationAuthentication.Password", "#UNKNOWN"),
    }
    configger.set("deploy.tokens", tokens)

    # cleanup any old deploy files in services
    for root, _, filenames in os.walk("./services"):
        for filename in filenames:
            if filename.endswith("-deploy.yml"):
                os.remove(os.path.join(root, filename))

    # orchestrator deploy initialization
    configger.get("orchestrators.deploy").initialize()

    return


def getDatabaseEngine():
    targetRdbms = configger.get("targetRdbms")
    if targetRdbms == "postgres":
        return "PostgreSQL"
    if targetRdbms == "sqlserver":
        return "SQLServer"

    return "#UNKNOWN"


def getDocumentDatabaseEngine():
    targetDocumentDb = configger.get("targetDocumentDb")
    if targetDocumentDb == "arango":
        return "ArangoDB"

    return "#UNKNOWN"
