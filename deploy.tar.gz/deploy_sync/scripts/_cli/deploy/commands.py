import click

import scripts.deploy.deployer as deployer


@click.command()
@click.option("--deploy", "-d", type=str, help="Name of deploy file.")
@click.option("--target", "-t", type=click.Choice(["postgres", "sqlserver"]))
@click.option("--orchestrator", "-o", type=click.Choice(["kube", "docker"]))
def deploy(deploy, target, orchestrator):
    """Deploys components based on a deploy manifest file"""
    deployer.deploy(deploy=deploy, targetRdbms=target, orchestrator=orchestrator)
