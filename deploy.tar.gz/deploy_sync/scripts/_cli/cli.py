# This module is a CLI routing controller.
#
# It provides structured organization of the cli structure for click
# commands and groups for ease or understanding and future maintenance.
#
# Execution of each underlying cli command is handled by core processing scripts
# and not performed in this controller (which is just a router/arg-checker only)
#
# The click library is well documented online at:
# https://click.palletsprojects.com/

import sys
import click

from .utils import alias

from .deploy import commands as deploy
from .clean import commands as clean


def main():
    # check version
    if sys.version_info < (3, 7):
        print(">>> Python Version 3.7 or above is required to run this script!")
        exit(-1)

    # click-cli entry point
    dpm()


@click.group(cls=alias.AliasedGroup)
def dpm():
    pass


dpm.add_command(deploy.deploy)
dpm.add_command(clean.clean)
