import click

# click aliasing class to allow alias of commands to a shorthand
# form.
# 
# for example a command called 'myclicommand' accepts 'mycli' as an 
# alias (as long as the shorthand form is unique). 
# 
# full  --> kis.py gfdl load
# short --> kis.py gf load
#  
# see Command Aliases here for more info:
# https://click.palletsprojects.com/en/8.1.x/advanced/
#
class AliasedGroup(click.Group):
    def get_command(self, ctx, cmd_name):
        # look for command "absolute-match"
        rv = click.Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv

        # look for command "match"
        matches = [x for x in self.list_commands(ctx) if x.startswith(cmd_name)]
        if not matches:
            # no match
            return None
        
        if len(matches) == 1:
            # single match
            return click.Group.get_command(self, ctx, matches[0])
        
        # multiple match; cannot process; error
        ctx.fail(f"Too many alias matches: {', '.join(sorted(matches))}")

    def resolve_command(self, ctx, args):
        # always return the full command name
        _, cmd, args = super().resolve_command(ctx, args)
        return cmd.name, cmd, args