import click

import scripts.clean.cleaner as cleaner


@click.command()
@click.option("--deploy", "-d", type=str, help="Name of deploy file.")
@click.option("--orchestrator", "-o", type=click.Choice(["kube", "docker"]))
def clean(deploy, orchestrator):
    """Cleans components based on a deploy manifest file"""
    cleaner.clean(deploy=deploy, orchestrator=orchestrator)
