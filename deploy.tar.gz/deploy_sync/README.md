# Deployment Manager

Elysian Container Deployment Manager.

## Version History

---

| Version | Release Date | Commit  |
| ------- | ------------ | ------- |
| 11-rev.1 | 28-Apr-2025  | 93e8f25 |

---

Copyright (c) 2025 ElysianNxt Co., Ltd.
