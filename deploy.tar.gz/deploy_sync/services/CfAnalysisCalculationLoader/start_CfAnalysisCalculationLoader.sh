#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.CfAnalysisCalculationLoader.dll --urls https://cfanalysiscalculationloader:5085
