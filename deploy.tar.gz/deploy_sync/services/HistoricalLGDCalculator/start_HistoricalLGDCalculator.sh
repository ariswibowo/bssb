#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.HistoricalLGDCalculator.dll --urls https://historicallgdcalculator:5081
