#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.LiquidityCalculator.dll --urls https://Liquiditycalculator:5025
