#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.HistoricalPDConsolidatedMatrixCalculator.dll --urls https://historicalpdconsolidatedmatrixcalculator:5076
