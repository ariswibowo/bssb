#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.CfAnalysisCalculationApi.dll --urls https://cfanalysiscalculationapi:5084
