#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9MeasurementAnalyzer.dll --urls https://ifrs9measurementanalyzer:5042
