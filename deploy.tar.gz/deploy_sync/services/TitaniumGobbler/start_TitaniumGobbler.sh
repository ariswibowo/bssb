#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.TitaniumGobbler.dll --urls https://titaniumgobbler:5063 