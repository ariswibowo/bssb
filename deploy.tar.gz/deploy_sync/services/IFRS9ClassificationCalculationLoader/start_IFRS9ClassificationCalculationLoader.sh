#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9ClassificationCalculationLoader.dll --urls https://ifrs9classificationcalculationloader:5044
