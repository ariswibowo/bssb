#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9MeasurementCalculationApi.dll --urls https://ifrs9measurementcalculationapi:5037
