#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9ClassificationCalculationApi.dll --urls https://ifrs9classificationcalculationapi:5035
