#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.PociCalculationLoader.dll --urls https://pocicalculationloader:5054
