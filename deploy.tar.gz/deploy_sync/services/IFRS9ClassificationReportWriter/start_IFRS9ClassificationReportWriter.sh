#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9ClassificationReportWriter.dll --urls https://ifrs9classificationreportwriter:5047
