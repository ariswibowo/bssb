#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.PDCurveCalculator.dll --urls https://pdcurvecalculator:5051
