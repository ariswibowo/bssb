#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.PDCurveCalculationApi.dll --urls https://pdcurvecalculationapi:5052
