#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9MeasurementCalculationLoader.dll --urls https://ifrs9measurementcalculationloader:5038
