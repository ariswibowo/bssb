#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9ImpairmentCalculationLoader.dll --urls https://ifrs9impairmentcalculationloader:5014
