#!/usr/bin/env bash

# replace Api routes with environment settings
# note: use pipe delimter on sed as URL will contain '/'
sed -i 's|OPEN_API_URL:.*|OPEN_API_URL: '"'$OpenApiUrl'"',|g' ./build-host/env.js
sed -i 's|GRAPHQL_API_URL:.*|GRAPHQL_API_URL: '"'$GraphqlApiUrl'"',|g' ./build-host/env.js
sed -i 's|GQL_API_URL:.*|GQL_API_URL: '"'$GqlApiUrl'"',|g' ./build-host/env.js
sed -i 's|EDRIVE_API_URL:.*|EDRIVE_API_URL: '"'$EDriveApiUrl'"',|g' ./build-host/env.js
sed -i 's|EDRIVE_PUBLIC_URL:.*|EDRIVE_PUBLIC_URL: '"'$EDrivePublicUrl'"',|g' ./build-host/env.js
sed -i 's|SUBHUB_URL:.*|SUBHUB_URL: '"'$SubHubUrl'"',|g' ./build-host/env.js

sed -i 's|SESSION_IDLE_TIMEOUT_MS:.*|SESSION_IDLE_TIMEOUT_MS: '$SessionIdleTimeoutMs',|g' ./build-host/env.js
sed -i 's|SESSION_IDLE_COUNTDOWN_MS:.*|SESSION_IDLE_COUNTDOWN_MS: '$SessionIdleCountdownMs',|g' ./build-host/env.js
sed -i 's|TOKEN_RENEW_THRESHOLD_PCT:.*|TOKEN_RENEW_THRESHOLD_PCT: '$TokenRenewThresholdPct',|g' ./build-host/env.js

# set node-env (required to avoid serve.js version check error when no internet)
export NODE_ENV=production

# log settings
echo
echo $(date) - Environment settings...
cat ./build-host/env.js

# start the machine
echo
echo $(date) - Starting eStudio microfrontend...
echo $(date) - Starting eStudio host...
serve -s build -l 5701 & serve -s build-host -l 5700