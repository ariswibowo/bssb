var importMap = {
  imports: {
    "@elysiannxt/root-config": "//localhost:5700/elysiannxt-root-config.js",
    "@elysiannxt/studio": "//localhost:5701/elysiannxt-estudio.js",
  },
};

System.addImportMap(importMap);

// define window environment
window.env = {
  IMPORT_MAP: importMap,
  APPLICATIONS: [
    {
      name: "@elysiannxt/studio",
      activeWhen: ["/studio"],
    },
  ],
};
