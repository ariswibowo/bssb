#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.TitaniumTransformer.dll --urls https://titaniumtransformer:5064 