#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.DataQualityAnalyzer.dll --urls https://dataqualityanalyzer:5110