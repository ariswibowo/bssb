#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9ImpairmentResultWriter.dll --urls https://ifrs9impairmentresultwriter:5022
