#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.HistoricalLGDCalculationApi.dll --urls https://historicallgdcalculationapi:5077
