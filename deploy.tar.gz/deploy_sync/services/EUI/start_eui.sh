#!/usr/bin/env bash

# set node-env (required to avoid serve.js version check error when no internet)
export NODE_ENV=production

# start the machine
echo
echo $(date) - Starting EUI Storybook...
npx http-server storybook-static -p 6066

