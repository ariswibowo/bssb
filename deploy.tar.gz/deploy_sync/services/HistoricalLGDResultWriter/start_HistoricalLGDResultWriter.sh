#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.HistoricalLGDResultWriter.dll --urls https://historicallgdresultwriter:5080
