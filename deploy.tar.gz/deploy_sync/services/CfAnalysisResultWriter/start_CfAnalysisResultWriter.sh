#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.CfAnalysisResultWriter.dll --urls https://cfanalysisresultwriter:5087
