#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.HistoricalLGDCalculationLoader.dll --urls https://historicallgdcalculationloader:5078
