#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet Empyrean.SampleExtractor.dll --urls https://sampleextractor:5070