#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.TitaniumQualigator.dll --urls https://titaniumqualigator:5067 