#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.BsmCalculationApi.dll --urls https://bsmcalculationapi:5030
