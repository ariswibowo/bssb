#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.HistoricalPDCalculationLoader.dll --urls https://historicalpdcalculationloader:5072
