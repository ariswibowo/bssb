#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.BsmCalculationLoader.dll --urls https://bsmcalculationloader:5031
