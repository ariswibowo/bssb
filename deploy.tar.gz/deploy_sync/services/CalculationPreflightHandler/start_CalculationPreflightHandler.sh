#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.CalculationPreflightHandler.dll --urls https://calculationpreflighthandler:5013
