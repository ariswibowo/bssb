#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/
update-ca-certificates
dotnet ElysianNxt.ModelApi.dll --urls https://modelapi:5097
