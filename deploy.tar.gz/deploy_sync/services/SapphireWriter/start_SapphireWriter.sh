#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.SapphireWriter.dll --urls https://sapphirewriter:5123 