#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.HistoricalLGDConsolidator.dll --urls https://historicallgdconsolidator:5082
