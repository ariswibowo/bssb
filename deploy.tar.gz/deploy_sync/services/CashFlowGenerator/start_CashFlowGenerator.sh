#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
 dotnet ElysianNxt.CashFlowGenerator.dll --urls https://cashflowgenerator:5016
