#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.BaselCalculationLoader.dll --urls https://baselcalculationloader:5093
