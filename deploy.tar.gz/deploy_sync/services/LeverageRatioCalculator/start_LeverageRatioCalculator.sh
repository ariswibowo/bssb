#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.LeverageRatioCalculator.dll --urls https://leverageratiocalculator:5028
