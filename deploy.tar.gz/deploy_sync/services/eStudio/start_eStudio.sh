#!/usr/bin/env bash

sed -i 's|SESSION_IDLE_TIMEOUT_MS:.*|SESSION_IDLE_TIMEOUT_MS: '$SessionIdleTimeoutMs',|g' ./build/env.js
sed -i 's|SESSION_IDLE_COUNTDOWN_MS:.*|SESSION_IDLE_COUNTDOWN_MS: '$SessionIdleCountdownMs',|g' ./build/env.js
sed -i 's|TOKEN_RENEW_THRESHOLD_PCT:.*|TOKEN_RENEW_THRESHOLD_PCT: '$TokenRenewThresholdPct',|g' ./build/env.js

# set node-env (required to avoid serve.js version check error when no internet)
export NODE_ENV=production

# log settings
echo
echo $(date) - Environment settings...
cat ./build/env.js

# start the machine
echo
echo $(date) - Starting eStudio...
# This will use "/" as base url for the estudio server (express.js)
# Further static file base url need to be done via build time
# ie. "yarn build" script inside package.json -> BASE_URL=/studio (or other)
npm run serve --app-url=/ --app-port=5000
