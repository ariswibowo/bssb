-- !preview conn=conFdr
SELECT
    "OriginSystemId",
    "ContractId",
    "CounterpartyId",
    "Entity",
    "OriginContractId",
    "OriginCounterpartyId",
    "ProductType",
    "ProductSubtype",
    "BusinessUnit",
    "Segment",
    "Currency",
  
    "MaturityDate",
    items."isDefaulted", items."observationDate", items."collectibility", items."daysPastDue",
    CASE 
      WHEN  items."daysPastDue" = 0 THEN 'Bucket_1'
      when items."daysPastDue" >0 and items."daysPastDue"  <=30 then 'Bucket_2'
      when items."daysPastDue" >30 and items."daysPastDue"  <=60 then 'Bucket_3'
      when items."daysPastDue" >60 and items."daysPastDue"  <=90 then 'Bucket_4'
      when items."daysPastDue" >00  then 'Bucket_5'
      else 'Bucket_Settled' 
    end as Bucket_system,
    items."outstandingAmount", items."discountRate"
    
    FROM "HistoricalContractDocs" hcs,
    jsonb_to_recordset("Observations"::jsonb->'observations') as items("observationDate" date, "collectibility" int, "daysPastDue" int, "outstandingAmount" text, "discountRate" text, "isDefaulted" boolean)
WHERE items."observationDate" = '2021-05-31' and "Entity" = 'SSB-KONVEN' and "ProductSubtype" In('BSSB-K681','BSSB-K601')  

