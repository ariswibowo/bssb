

-- !preview conn=conStaging

--SELECT reporting_date, count(*) FROM "psak_dev"."public"."nominative_syariah" group by reporting_date

--SELECT product_type, product_subtype,* FROM "psak_dev"."public"."credit" where reporting_date = '2025-08-31' limit 10

--SELECT * FROM "psak_dev"."public"."historical_contracts_konven" where reporting_date = '2025-08-31' limit 10
--SELECT product_type, product_subtype,* FROM "psak_dev"."public"."credit" where reporting_date = '2025-08-31' limit 10

--SELECT reporting_date, count(*) FROM "psak_dev"."public"."nominative_syariah" group by reporting_date

--select * from delivered_cashflow_konven limit 10

--
select * from historical_recovery_konven where insurance_recovery is not null limit 10


--select count(1) from historical_recovery_konven where insurance_recovery is not null
--limit 10


