-- !preview conn=conHistoricalPd

select * from "CalculationTableRegistry"
##where "CalculationId"='49d922b-b002-402b-8832-1170dab5990c';