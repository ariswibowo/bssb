-- !preview conn=conFdr

--SELECT cp."Data",* FROM "Fdr"."public"."Contracts" c
--left join "ContractProps" cp on c."ContractId" = cp."ContractId"
--where "Entity" = 'SSB-KONVEN'
--and "ReportingDate" = '2025-08-31' limit 10;


select "Entity", "Data", "Data"::jsonb->'additionalProperties'->'isRestructured', "Observations" from "HistoricalContractDocs" 
where "Entity" != 'SSB-SYARIA' limit 10;
--and ("Data"::jsonb->'additionalProperties'->'snapshotDate')::text like '%2017%'
----where ("Data"::jsonb->'additionalProperties'->'isRestructured')::text is not null
--limit 10

--truncate table "HistoricalContractDocs"; 
--select * from "HistoricalContractDocs" limit 10;
