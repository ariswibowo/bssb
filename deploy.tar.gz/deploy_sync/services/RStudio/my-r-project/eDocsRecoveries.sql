-- !preview conn=conFdr

SELECT
    "OriginSystemId",
    "ContractId",
    "CounterpartyId",
    "Entity",
    "OriginContractId",
    "OriginCounterpartyId",
    "ProductType",
    "ProductSubtype",
    "BusinessUnit",
    "Segment",
    "Currency",
    "MaturityDate",
    items."recoveryDate", items."recoveryAmount"
    FROM "HistoricalContractDocs" hcs,
    jsonb_to_recordset("Recoveries"::jsonb->'recoveries') as items("recoveryDate" date, "recoveryAmount" text)
LIMIT 10
--WHERE "OriginContractId" = 'xxx'
--ORDER BY items."recoveryDate" DESC;