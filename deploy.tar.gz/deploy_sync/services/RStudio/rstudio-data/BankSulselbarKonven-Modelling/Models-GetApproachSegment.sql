CREATE OR REPLACE FUNCTION public."GetApproachSegment"()
 RETURNS TABLE("VersionId" text, "ApproachId" text, "SegmentId" text, "MeasurementUnit" text)
 LANGUAGE plpgsql
AS $function$
BEGIN
    RETURN QUERY SELECT
        UPPER(V."VersionId"::text) as "VersionId" ,
        UPPER(approachList."approachId") AS "ApproachId",
        UPPER(segmentList."segmentId") AS "SegmentId",
        cast(approachList."method"::jsonb->'configuration'->'observation'->>'measurementUnit' as text) AS "MeasurementUnit"
    FROM "VersionProps" V,
        jsonb_to_recordset(V."Value"::jsonb->'approaches') AS approachList("approachId" text, "name" text, "description" text, "segments" text, "method" text),
        jsonb_to_recordset(approachList."segments"::jsonb) AS segmentList("segmentId" text)
        --jsonb_to_recordset(approachList."methods"::jsonb) AS configurationList("configuration" text)
    WHERE "Key" = 'Approaches';
END;
$function$
;
