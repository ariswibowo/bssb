-- !preview conn=conHistoricalPd

select * from "CalculationTableRegistry"
where "CalculationId"='c49d922b-b002-402b-8832-1170dab5990c'