
############################################################################################################################
## Install Packages 
############################################################################################################################
packages <- c("odbc","DescTools","base","tidyr","reshape2","xlsx","openxlsx",
              "readxl","plyr","dplyr","rlang","stringr","car","CADFtest","MuMIn",
              "lmtest","jsonlite","magrittr","rjson","zoo","rlist","IDPmisc",
              "caret","glmnet","svDialogs","snow","parallel","rowr","MLmetrics","psych","stringdist")
suppressMessages(invisible(lapply(packages, library, character.only = TRUE)))


#todo check lagi connection db nya 
conFdr <- dbConnect(
  odbc(),
  Driver = "PostgreSQL",
  Server =  "10.126.102.103", 
  Database = "Fdr",
  UID = "Elysian", 
  PWD = "Guava@ENXT55555", 
  Port = 5432
)

# Definisikan SQL yang sama persis dengan query kamu
sql_query <- "
SELECT
items.\"observationDate\",
    \"OriginSystemId\",
    \"ContractId\",
    \"CounterpartyId\",
    \"Entity\",
    \"OriginContractId\",
    \"OriginCounterpartyId\",
    \"ProductType\",
    \"ProductSubtype\",
    \"BusinessUnit\",
    \"Segment\",
    \"Currency\",
    \"MaturityDate\",
    items.\"isDefaulted\",
    items.\"observationDate\",
    items.\"collectibility\",
    items.\"daysPastDue\",
    CASE 
        WHEN items.\"daysPastDue\" = 0 THEN 'Bucket_1'
        WHEN items.\"daysPastDue\" > 0 AND items.\"daysPastDue\" <= 30 THEN 'Bucket_2'
        WHEN items.\"daysPastDue\" > 30 AND items.\"daysPastDue\" <= 60 THEN 'Bucket_3'
        WHEN items.\"daysPastDue\" > 60 AND items.\"daysPastDue\" <= 90 THEN 'Bucket_4'
        WHEN items.\"daysPastDue\" > 90 THEN 'Bucket_5'
        ELSE 'Bucket_Settled'
    END AS \"Bucket_system\",
    items.\"outstandingAmount\",
    items.\"discountRate\"
FROM \"HistoricalContractDocs\" hcs,
     jsonb_to_recordset(\"Observations\"::jsonb->'observations') AS items(
         \"observationDate\" date,
         \"collectibility\" int,
         \"daysPastDue\" int,
         \"outstandingAmount\" text,
         \"discountRate\" text,
         \"isDefaulted\" boolean
     )
WHERE items.\"observationDate\" = '2020-06-30'
  AND \"Entity\" = 'SSB-KONVEN'
  AND \"ProductSubtype\" IN ('BSSB-K681','BSSB-K601')
"


# Jalankan query dan ambil hasil ke data frame
df_result <- dbGetQuery(conFdr, sql_query)

# Path file output Excel (silakan ubah sesuai kebutuhan)
output_file <- "HistoricalContractDocs_SSB_KONVEN_2020-06-30"

# Export ke Excel
#write_xlsx(df_result, path = output_file)

#cat("Export selesai ke file:", output_file, "\n")

directory <- "/home/rstudio/BankSulselbarKonven-Modelling" #--mesti cek ke aris untuk file di server Rstudio untuk menyimpan file output modelling 
setwd(directory)
xlsx::write.xlsx2(df_result, 
                  file = paste0(directory, "_Output_",output_file,".xlsx"), 
                  sheetName= paste0("x-",output_file),
                  col.names=TRUE,
                  row.names=TRUE,
                  append=FALSE)

