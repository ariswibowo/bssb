-- DROP FUNCTION public.GetTransitionMatricesResult(text);

CREATE OR REPLACE FUNCTION public.GetTransitionMatricesResult(table_name text)
 RETURNS TABLE("Id" bigint, "PointId" uuid, "HashCode" character varying, "CalculationId" uuid, "SegmentId" uuid, "SegmentName" character varying, "FromObservationDate" timestamp without time zone, "ToObservationDate" timestamp without time zone, "FromBucketId" uuid, "ToBucketId" uuid, "FromBucketName" character varying, "ToBucketName" character varying, "FromBucketType" character varying, "ToBucketType" character varying, "FromBucketSequence" integer, "ToBucketSequence" integer, "NumContracts" integer, "NumCounterparties" integer, "FromOutstandingAmount" numeric, "ToOutstandingAmount" numeric, "RetentionCopied" boolean)
 LANGUAGE plpgsql
AS $function$


BEGIN
    RETURN QUERY 
	EXECUTE format('SELECT * FROM %I', $1);
END;


$function$
;