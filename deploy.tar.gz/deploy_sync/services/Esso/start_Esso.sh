#!/usr/bin/env bash

# set node-env (required to avoid serve.js version check error when no internet)
export NODE_ENV=production && \

# start the machine
echo && \
echo $(date) - Starting Esso... && \
node --openssl-legacy-provider ./build/server.js
