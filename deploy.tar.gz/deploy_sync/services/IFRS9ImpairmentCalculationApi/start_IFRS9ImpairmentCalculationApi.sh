#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9ImpairmentCalculationApi.dll --urls https://ifrs9impairmentcalculationapi:5050 
