#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.LGDCurveCalculator.dll --urls https://lgdcurvecalculator:5057
