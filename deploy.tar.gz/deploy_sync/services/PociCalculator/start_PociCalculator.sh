#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.PociCalculator.dll --urls https://pocicalculator:5055
