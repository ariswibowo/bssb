#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.BaselCalculationApi.dll --urls https://baselcalculationapi:5090
