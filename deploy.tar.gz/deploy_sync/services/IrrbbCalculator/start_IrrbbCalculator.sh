#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IrrbbCalculator.dll --urls https://irrbbcalculator:5095
