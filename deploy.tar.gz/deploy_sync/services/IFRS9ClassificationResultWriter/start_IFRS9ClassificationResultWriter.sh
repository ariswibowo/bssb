#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.IFRS9ClassificationResultWriter.dll --urls https://ifrs9classificationresultwriter:5046