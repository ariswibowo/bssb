#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
 dotnet ElysianNxt.MeasurementCalculator.dll --urls https://measurementcalculator:5041
