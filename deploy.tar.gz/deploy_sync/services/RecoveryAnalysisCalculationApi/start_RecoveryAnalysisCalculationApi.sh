#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.RecoveryAnalysisCalculationApi.dll --urls https://recoveryanalysiscalculationapi:5058
