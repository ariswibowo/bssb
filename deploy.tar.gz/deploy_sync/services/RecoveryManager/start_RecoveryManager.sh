#!/usr/bin/env bash

sed -i 's|SESSION_IDLE_TIMEOUT_MS.*|SESSION_IDLE_TIMEOUT_MS: '$SessionIdleTimeoutMs',|g' ./build/env.js
sed -i 's|SESSION_IDLE_COUNTDOWN_MS.*|SESSION_IDLE_COUNTDOWN_MS: '$SessionIdleCountdownMs',|g' ./build/env.js
sed -i 's|TOKEN_RENEW_THRESHOLD_PCT.*|TOKEN_RENEW_THRESHOLD_PCT: '$TokenRenewThresholdPct',|g' ./build/env.js

# set node-env (required to avoid serve.js version check error when no internet)
export NODE_ENV=production

# Config buildtime & runtime var
npm run serve:preset recoverymanager

# log settings
echo
echo $(date) - Environment settings...
cat ./build/env.js

# start the machine
echo
echo $(date) - Starting RecoveryManager...
npm run serve --app-url=/ --app-port=5006
