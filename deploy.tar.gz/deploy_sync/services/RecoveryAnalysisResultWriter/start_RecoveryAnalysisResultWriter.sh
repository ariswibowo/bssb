#!/usr/bin/env bash
cp /run/secrets/*.crt /usr/local/share/ca-certificates/ 
update-ca-certificates 
dotnet ElysianNxt.RecoveryAnalysisResultWriter.dll --urls https://recoveryanalysisresultwriter:5061