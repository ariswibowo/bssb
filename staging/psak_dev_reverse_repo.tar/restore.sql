--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE psak_dev;
--
-- Name: psak_dev; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE psak_dev WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE psak_dev OWNER TO postgres;

\unrestrict (null)
\connect psak_dev
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: reverse_repo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reverse_repo (
    reporting_date timestamp without time zone,
    origin_system_id character varying(50),
    entity character varying(50),
    product_subtype character varying(50),
    product_type character varying(50),
    business_unit character varying(50),
    origin_contract_id character varying(50),
    counterparty_type character varying(50),
    origin_counterparty_id character varying(50),
    customer_name character varying(50),
    start_date timestamp without time zone,
    maturity_date timestamp without time zone,
    currency character varying(50),
    outstanding_amount numeric(20,2),
    days_past_due integer,
    collectibility integer,
    credit_rating character varying(50),
    credit_rating_agency character varying(50),
    segment character varying(50),
    is_restructured boolean,
    cash_flow_type character varying(50),
    account_status character varying(50),
    antasena_jenis_pengguna character varying(50),
    antasena_kategori_debitur character varying(50),
    branch_code character varying(50)
);


ALTER TABLE public.reverse_repo OWNER TO postgres;

--
-- Data for Name: reverse_repo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reverse_repo (reporting_date, origin_system_id, entity, product_subtype, product_type, business_unit, origin_contract_id, counterparty_type, origin_counterparty_id, customer_name, start_date, maturity_date, currency, outstanding_amount, days_past_due, collectibility, credit_rating, credit_rating_agency, segment, is_restructured, cash_flow_type, account_status, antasena_jenis_pengguna, antasena_kategori_debitur, branch_code) FROM stdin;
\.
COPY public.reverse_repo (reporting_date, origin_system_id, entity, product_subtype, product_type, business_unit, origin_contract_id, counterparty_type, origin_counterparty_id, customer_name, start_date, maturity_date, currency, outstanding_amount, days_past_due, collectibility, credit_rating, credit_rating_agency, segment, is_restructured, cash_flow_type, account_status, antasena_jenis_pengguna, antasena_kategori_debitur, branch_code) FROM '$$PATH$$/3399.dat';

--
-- Name: TABLE reverse_repo; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.reverse_repo TO psak;


--
-- PostgreSQL database dump complete
--

