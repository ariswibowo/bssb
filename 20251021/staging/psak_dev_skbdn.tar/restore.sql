--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE psak_dev;
--
-- Name: psak_dev; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE psak_dev WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE psak_dev OWNER TO postgres;

\unrestrict (null)
\connect psak_dev
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: skbdn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skbdn (
    reporting_date timestamp without time zone,
    origin_system_id character varying(50),
    entity character varying(50),
    product_type character varying(50),
    product_subtype character varying(50),
    business_unit character varying(50),
    origin_contract_id character varying(50),
    origin_counterparty_id character varying(50),
    customer_name character varying(50),
    start_date timestamp without time zone,
    maturity_date timestamp without time zone,
    currency character varying(50),
    outstanding_amount numeric(20,2),
    accrued_interest numeric(20,2),
    interest_rate numeric(12,9),
    present_value numeric(20,2),
    days_past_due integer,
    is_restructured boolean,
    account_status character varying(50),
    antasena_jenis_pengguna character varying(50),
    antasena_kategori_debitur character varying(50),
    branch_code character varying(50)
);


ALTER TABLE public.skbdn OWNER TO postgres;

--
-- Data for Name: skbdn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skbdn (reporting_date, origin_system_id, entity, product_type, product_subtype, business_unit, origin_contract_id, origin_counterparty_id, customer_name, start_date, maturity_date, currency, outstanding_amount, accrued_interest, interest_rate, present_value, days_past_due, is_restructured, account_status, antasena_jenis_pengguna, antasena_kategori_debitur, branch_code) FROM stdin;
\.
COPY public.skbdn (reporting_date, origin_system_id, entity, product_type, product_subtype, business_unit, origin_contract_id, origin_counterparty_id, customer_name, start_date, maturity_date, currency, outstanding_amount, accrued_interest, interest_rate, present_value, days_past_due, is_restructured, account_status, antasena_jenis_pengguna, antasena_kategori_debitur, branch_code) FROM '$$PATH$$/3399.dat';

--
-- Name: TABLE skbdn; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.skbdn TO psak;


--
-- PostgreSQL database dump complete
--

