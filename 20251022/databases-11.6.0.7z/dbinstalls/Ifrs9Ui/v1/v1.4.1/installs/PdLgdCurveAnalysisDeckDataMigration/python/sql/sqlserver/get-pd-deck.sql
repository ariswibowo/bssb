SELECT d.DeckId, d.Data
FROM Decks d WITH(NOLOCK)
INNER JOIN DeckObjectiveTypes dot WITH(NOLOCK) ON dot.ObjectiveTypeId = d.ObjectiveTypeId
WHERE dot.Code = 'PdCurveAnalysis';