\echo '';
\echo 'Updating Decks...';

UPDATE "Decks"
SET "Data" = '{data}'
WHERE "DeckId" = '{deckId}';