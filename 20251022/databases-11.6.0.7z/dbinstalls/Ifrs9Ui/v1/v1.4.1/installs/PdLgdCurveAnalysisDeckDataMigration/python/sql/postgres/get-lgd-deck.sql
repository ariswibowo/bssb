SELECT d."DeckId", d."Data"
FROM "Decks" d
INNER JOIN "DeckObjectiveTypes" dot ON dot."ObjectiveTypeId" = d."ObjectiveTypeId"
WHERE dot."Code" = 'LgdCurveAnalysis';