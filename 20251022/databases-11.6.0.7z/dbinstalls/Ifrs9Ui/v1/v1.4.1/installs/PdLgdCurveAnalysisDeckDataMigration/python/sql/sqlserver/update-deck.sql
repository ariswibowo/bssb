PRINT N'';
PRINT N'Updating Decks...';

UPDATE Decks
SET Data = '{data}'
WHERE DeckId = '{deckId}';
GO