import dbhelper

def main(config):

    # generate build script file
    build = dbhelper.init_build("migrate-pd-curve-analysis-deck-data", config)

    # get the deck update sql template
    update_sql = dbhelper.get_sql("update-deck", config)

    # get the decks data
    decks = dbhelper.get_data("get-pd-deck", config)

    # add deck updates to build file
    for deck in decks:

        deckData = deck[1]

        # capture model version Ids
        modelVersionIds = deckData[deckData.index('[') + 1:deckData.index(']')]

        # split model version Ids
        modelVersionIds = modelVersionIds.split(',')

        # init new data
        newData = ''

        for modelVersionId in modelVersionIds:

            # build up curve model version
            curveModelVersion = '{"versionId":' + modelVersionId + '}'
            
            # append curve model version into new data
            if not newData:
                newData = curveModelVersion
            else:
                newData = newData + ',' + curveModelVersion

        # build up curveModelVersions
        newData = '{"curveModelVersions":[' + newData + ']}'

        sql = update_sql.format(data=newData, deckId=deck[0])
        dbhelper.write_build(build, sql)

    # run the build script
    dbhelper.run_build(build, config)

    return