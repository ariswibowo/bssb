# README

**Release: Ifrs9 UI V1.4.1**

## Release Features & Fixes

- [Feature: Pd Lgd Curve Deck Data New Structure Elektra)](#feature-pd-lgd-curve-deck-data-new-structure-elektra)

## Feature: Pd Lgd Curve Deck Data New Structure Elektra

Migrates the PD and LGD curve analysis deck data to use the new structure.

Reference: #EMP-1166, #EMP-1170

[top](#readme)