PRINT N'';
PRINT N'Installing AccessLevels Policy...';
GO

DELETE
  FROM [dbo].[DeckPolicies]
 WHERE "PolicyType" IN ('AccessLevels');


PRINT N'';
PRINT N'Adding Policies...';
GO

BULK INSERT [dbo].[DeckPolicies]
FROM '{data}/DeckPolicies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO
