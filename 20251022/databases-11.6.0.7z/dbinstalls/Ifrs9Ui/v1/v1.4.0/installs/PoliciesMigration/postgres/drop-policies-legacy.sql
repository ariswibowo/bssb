\echo '';
\echo 'Terminating locks...';
SELECT pg_terminate_backend(pg_stat_activity.pid)
FROM pg_stat_activity
WHERE query LIKE '%DeckPoliciesLegacy%'
  AND pid <> pg_backend_pid();

\echo '';
\echo 'Dropping table PoliciesLegacy...';
DROP TABLE IF EXISTS "DeckPoliciesLegacy";
