SELECT [PolicyType], [Data]
  FROM [dbo].[DeckPoliciesLegacy]
 WHERE [PolicyType] = 'General'
