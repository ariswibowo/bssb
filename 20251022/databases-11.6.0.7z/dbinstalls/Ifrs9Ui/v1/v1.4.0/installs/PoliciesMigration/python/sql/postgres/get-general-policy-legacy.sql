SELECT "PolicyType", "Data"
  FROM "DeckPoliciesLegacy"
 WHERE "PolicyType" = 'General'
