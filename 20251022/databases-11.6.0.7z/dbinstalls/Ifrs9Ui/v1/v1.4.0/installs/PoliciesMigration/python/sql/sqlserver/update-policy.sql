PRINT N'';
PRINT N'Updating {policyType} Active Policy...';
GO

UPDATE [dbo].[DeckPolicies]
   SET [ActivePolicy] = '{activePolicy}'
 WHERE [PolicyType] = '{policyType}';
GO
