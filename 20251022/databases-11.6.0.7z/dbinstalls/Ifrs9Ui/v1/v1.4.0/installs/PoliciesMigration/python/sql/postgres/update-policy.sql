\echo '';
\echo 'Updating {policyType} Active Policy...';

UPDATE "DeckPolicies"
   SET "ActivePolicy" = '{activePolicy}'
 WHERE "PolicyType" = '{policyType}';
