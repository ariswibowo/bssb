import dbhelper
import logger
import json

def main(config):

    # generate build script file
    build = dbhelper.init_build("migrate-policies", config)

    # check policies legacy table exists
    # if no data assume nothing to migrate (policy already migrated)
    res = dbhelper.get_data("check-policies-legacy", config)
    if res.fetchone() is None:
        logger.warning("No existing legacy policy table found; skipping Policy migration")
        return

    # initialize policies with default settings
    sql = dbhelper.get_sql("init-template-policies", config)
    dbhelper.write_build(build, sql)

    # get default and general policies
    res = dbhelper.get_data("get-general-policy-legacy", config)
    generalPolicy = res.fetchone()

    # if general not found then no need to migrate
    if generalPolicy is None:
        # run the build script
        dbhelper.run_build(build, config)
        logger.warning("No existing legacy general policy found; skipping Policy migration")
        return

    # prepare json Data
    generalPolicy_data = json.loads(generalPolicy[1])

    # get update sql template
    update_sql = dbhelper.get_sql("update-policy", config)

    # migrate access levels
    activePolicy = { 'accessLevels': generalPolicy_data.get('accessLevels', []) }
    sql = update_sql.format(policyType="AccessLevels", activePolicy=json.dumps(activePolicy))
    dbhelper.write_build(build, sql)

    # run the build script
    dbhelper.run_build(build, config)

    return
