PRINT N'';
PRINT N'Dropping table PoliciesLegacy...';
DROP TABLE IF EXISTS [dbo].[DeckPoliciesLegacy];
GO
