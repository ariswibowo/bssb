\echo '';
\echo 'Installing AccessLevels Policies...';

DELETE
  FROM "DeckPolicies"
 WHERE "PolicyType" IN ('AccessLevels');

\echo '';
\echo 'Adding Policies...';

\copy "DeckPolicies" FROM '{data}/DeckPolicies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
