# README

**Release: Ifrs9 UI V1.4.0**

## Release Features & Fixes

- [Feature: Deck Policies](#feature-deck-policies)

## Feature: Deck Policies

Migrates the legacy General policy configuration of "accesslevels" into the micro-policies as in policy types: "AccessLevels".

The legacy policy table is fully deprecated and dropped.

Reference: #EMP-660

[top](#readme)
