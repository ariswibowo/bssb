PRINT N'';
PRINT N'Adding Foreign Key to DeckImpairmentDisclosuresDeltas Table...';
GO

ALTER TABLE [dbo].[DeckImpairmentDisclosureDeltas]
    DROP CONSTRAINT IF EXISTS FK_DeckImpairmentDisclosureDeltas_DeckImpairmentDisclosures_DisclosureId;
GO

ALTER TABLE [dbo].[DeckImpairmentDisclosureDeltas]
    ADD CONSTRAINT FK_DeckImpairmentDisclosureDeltas_DeckImpairmentDisclosures_DisclosureId
        FOREIGN KEY ([DisclosureId])
        REFERENCES [dbo].[DeckImpairmentDisclosures]([DisclosureId]) ON DELETE CASCADE;
GO
