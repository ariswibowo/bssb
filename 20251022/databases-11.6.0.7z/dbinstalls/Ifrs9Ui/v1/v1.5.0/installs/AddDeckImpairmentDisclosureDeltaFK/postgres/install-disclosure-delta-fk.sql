\echo '';
\echo 'Adding Foreign Key to DeckImpairmentDisclosuresDeltas Table...';

ALTER TABLE ONLY "DeckImpairmentDisclosureDeltas"
    DROP CONSTRAINT IF EXISTS "FK_DeckImpairmentDisclosureDeltas_DeckImpairmentDisclosures_DisclosureId";

ALTER TABLE ONLY "DeckImpairmentDisclosureDeltas"
    ADD CONSTRAINT "FK_DeckImpairmentDisclosureDeltas_DeckImpairmentDisclosures_DisclosureId"
        FOREIGN KEY ("DisclosureId")
        REFERENCES "DeckImpairmentDisclosures"("DisclosureId") ON DELETE CASCADE;