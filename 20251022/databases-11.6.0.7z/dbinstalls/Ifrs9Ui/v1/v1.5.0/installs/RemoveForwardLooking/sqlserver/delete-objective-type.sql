PRINT N'';
PRINT N'Deleting Impairment(F) Objective Type...';
GO

DELETE
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [ObjectiveTypeId] = '30B6F7FC-486F-4E5F-A53D-D11A6CA7833C';
GO
