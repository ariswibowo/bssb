import dbhelper
import logger
import json

forward_looking_objective_type_id = "30B6F7FC-486F-4E5F-A53D-D11A6CA7833C"

def main(config):
    update_access_levels_policy(config)
    return

# remove forward-looking from Access Levels policy
def update_access_levels_policy(config):
    # get policy
    policy = get_policy("AccessLevels", config)
    updated = False

    # update policies
    for policy_i in [policy['defaultPolicy'], policy['activePolicy']]:
        if ('accessLevels' in policy_i):
            access_levels = policy_i['accessLevels']

            for i in reversed(range(len(access_levels))):
                # applies to objective_type_ids
                objective_type_ids = access_levels[i]['appliesTo']['objectiveTypeIds']

                if(len(objective_type_ids) == 1): # if access level applies to only one objective types or *
                    if(equalGuid(objective_type_ids[0], forward_looking_objective_type_id)):
                        # remove the access level
                        access_levels.pop(i)
                        updated = True

                else: # if access level applies to more than one objective type
                    for j in reversed(range(len(objective_type_ids))):
                        if(equalGuid(objective_type_ids[j],forward_looking_objective_type_id)):
                            # remove from appliesTo list
                            objective_type_ids.pop(j)
                            updated = True

            # resynch priority
            access_levels.sort(key = prioritySort)
            for i in range(len(access_levels)):
                access_levels[i]['priority'] = i + 1

    # update policy
    update_policy(policy, updated, config)

    return

# returns an active policy
def get_policy(policyType, config):
    # get policy
    policy_sql = dbhelper.get_sql("get-policy", config)
    policy_sql = policy_sql.format(policyType=policyType)
    policy = dbhelper.run_sql(policy_sql, config).fetchone()

    # return policy
    return { "policyType": policy[0], "defaultPolicy": json.loads(policy[1]), "activePolicy": json.loads(policy[2]) }

# updates policy
def update_policy(policy, updated, config):

    # generate build file
    build_name = "update-{policyType}-policy".format(policyType=policy['policyType'].lower())
    build = dbhelper.init_build(build_name, config)

    # add sql depending on whether update required
    if (updated):
        update_sql = dbhelper.get_sql("update-policy", config)
    else:
        update_sql = dbhelper.get_sql("update-policy-none", config)

    update_sql = update_sql.format(policyType=policy['policyType'],
                                   defaultPolicy=json.dumps(policy['defaultPolicy']),
                                   activePolicy=json.dumps(policy['activePolicy']))

    dbhelper.write_build(build, update_sql)

    # run the build
    dbhelper.run_build(build, config)

    return

# compare guids case insensitive
def equalGuid(guid1, guid2):
    return guid1.lower() == guid2.lower()

def prioritySort(val):
    return val['priority']
