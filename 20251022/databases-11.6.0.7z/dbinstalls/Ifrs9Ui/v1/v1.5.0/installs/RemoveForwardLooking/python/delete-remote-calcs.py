import dbhelper
import logger
import json

def main(config):

    # generate build script file
    build = dbhelper.init_build("delete-remote-calcs", config)

    # construct the build
    if dbhelper.checkdb_exists("Ifrs9Impairment", config):
        delete_sql = get_delete_sql(config)
    else:
        delete_sql = dbhelper.get_sql("delete-remote-calcs-none", config)

    dbhelper.write_build(build, delete_sql)

    # run the build
    dbhelper.run_build(build, config)

    return

def get_delete_sql(config):

    # generate the "keep-me" calculations List from local
    local_calcs = dbhelper.get_data("get-local-calcs", config).fetchall()
    calc_list = ""

    for index, calc in enumerate(local_calcs, 1):
        calc_list = calc_list + "'" + calc[0] + "'" + (", \n" if index < len(local_calcs) else "")

    # add build script sql
    if len(calc_list) > 0:
        delete_sql = dbhelper.get_sql("delete-remote-calcs", config)
        delete_sql = delete_sql.format(localCalculationIdList=calc_list)
    else:
        delete_sql = dbhelper.get_sql("delete-remote-calcs-all", config)

    # remove orphans created by calc deletion
    delete_sql = delete_sql + dbhelper.get_sql("delete-remote-calc-orphans", config)

    return delete_sql
