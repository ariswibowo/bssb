
-- delete orphaned main calculation index entries
PRINT N'';
PRINT N'Deleting Orphaned ResultIndex...';
DELETE FROM [dbo].[ResultIndex] WHERE [CalculationId] NOT IN (SELECT [CalculationId] FROM [dbo].[Calculations]);

-- delete all downstream orphans
PRINT N'Deleting Orphaned ReportEcl...';
DELETE FROM [dbo].[ReportEcl] WHERE [CalculationId] NOT IN (SELECT [CalculationId] FROM [dbo].[Calculations]);

PRINT N'Deleting Orphaned ResultContracts...';
DELETE FROM [dbo].[ResultContracts] WHERE [ResultId] NOT IN (SELECT [ResultId] FROM [dbo].[ResultIndex]);

PRINT N'Deleting Orphaned ResultHops...';
DELETE FROM [dbo].[ResultHops] WHERE [ResultId] NOT IN (SELECT [ResultId] FROM [dbo].[ResultIndex]);

PRINT N'Deleting Orphaned ResultProcessed...';
DELETE FROM [dbo].[ResultProcessed] WHERE [CalculationId] NOT IN (SELECT [CalculationId] FROM [dbo].[Calculations]);

PRINT N'Deleting Orphaned ResultRejects...';
DELETE FROM [dbo].[ResultRejects] WHERE [ResultId] NOT IN (SELECT [ResultId] FROM [dbo].[ResultIndex]);

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_NAME = N'ResultSegments' AND TABLE_SCHEMA = N'dbo')
BEGIN
    PRINT N'Deleting Orphaned ResultSegments...';
    DELETE FROM [dbo].[ResultSegments] WHERE [ResultId] NOT IN (SELECT [ResultId] FROM [dbo].[ResultIndex]);
END;

-- cashflow collections
PRINT N'Deleting Orphaned ResultCashFlowCollections...';
DELETE FROM [dbo].[ResultCashFlowCollections] WHERE [ResultId] NOT IN (SELECT [ResultId] FROM [dbo].[ResultIndex]);

PRINT N'Deleting Orphaned CashFlowCollectionIndex...';
DELETE FROM [dbo].[CashFlowCollectionIndex] WHERE [CollectionId] NOT IN (SELECT [CollectionId] FROM [dbo].[ResultCashFlowCollections]);

-- term structures
PRINT N'Deleting Orphaned ResultTermStructures...';
DELETE FROM [dbo].[ResultTermStructures] WHERE [ResultId] NOT IN (SELECT [ResultId] FROM [dbo].[ResultIndex]);

PRINT N'Deleting Orphaned TermStructureIndex...';
DELETE FROM [dbo].[TermStructureIndex] WHERE [StructureId] NOT IN (SELECT [StructureId] FROM [dbo].[ResultTermStructures]);
