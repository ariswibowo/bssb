PRINT N'';
PRINT N'Deleting Impairment(F) Decks...';
GO

DELETE
  FROM [dbo].[Decks]
 WHERE [ObjectiveTypeId] = '30B6F7FC-486F-4E5F-A53D-D11A6CA7833C';
GO
