USE [Ifrs9Impairment]
GO

PRINT N'';
PRINT N'Deleting Orphaned Remote ECL Calculations...';

DELETE
  FROM [dbo].[Calculations]
 WHERE [CalculationId] NOT IN
(
{localCalculationIdList}
);
GO
