SELECT [PolicyType], [DefaultPolicy], [ActivePolicy]
  FROM [dbo].[DeckPolicies]
 WHERE [PolicyType] = '{policyType}';
