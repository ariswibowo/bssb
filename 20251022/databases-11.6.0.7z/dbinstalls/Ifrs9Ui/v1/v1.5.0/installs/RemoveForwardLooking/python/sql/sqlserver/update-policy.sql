PRINT N'';
PRINT N'Updating {policyType} Policy...';
GO

UPDATE [dbo].[DeckPolicies]
   SET [DefaultPolicy] = '{defaultPolicy}',
       [ActivePolicy] = '{activePolicy}'
 WHERE [PolicyType] = '{policyType}';
GO
