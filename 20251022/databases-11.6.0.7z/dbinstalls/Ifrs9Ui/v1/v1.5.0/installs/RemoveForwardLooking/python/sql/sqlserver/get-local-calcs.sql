SELECT [CalculationId] FROM [DeckImpairmentEclCalculations];
