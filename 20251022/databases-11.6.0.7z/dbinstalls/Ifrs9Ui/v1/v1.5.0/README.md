# README

**Release: Ifrs9 UI V1.5.0**

## Release Features & Fixes

- [Feature: Pd Lgd Curve Deck Data New Structure)](#feature-pd-lgd-curve-deck-data-new-structure)
- [Feature: Add Deck Impairment Disclosure Delta ForeignKey](#feature-add-deck-impairment-disclosure-delta-foreignkey)
- [Feature: Remove Forward Looking (See Warning!)](#feature-remove-forward-looking)
- [Feature: Pd Lgd Curve Deck Historical Deck Selection Validation](#feature-pd-lgd-curve-deck-historical-deck-selection-validation)
- [Feature: RemoveDisclaimers](#feature-remove-disclaimers)

## Feature: Pd Lgd Curve Deck Data New Structure

Migrates the PD and LGD curve analysis deck data to use the new structure.

Reference: #EMP-1166, #EMP-1170

[top](#readme)

## Feature: Add Deck Impairment Disclosure Delta ForeignKey

Add missing ForeignKey to DeckImpairmentDisclosureDeltas table

References: #EMP-1216

[top](#readme)

## Feature: Remove Forward Looking

Removes Impairment(forward looking) objective type and related models.

### **WARNING!**

    This will irreversibly remove all data related to the forward looking objective types beyond recoverable.

    If you want to keep your data please make sure you have made a backup before updating to this version.

Affected Tables

- DeckObjectiveTypes
- Decks
- DeckImpairmentEcls
- DeckImpairmentEclCalculations
- DeckImpairmentVariances
- DeckImpairmentVarianceEcls
- DeckImpairmentDisclosures
- DeckImpairmentDisclosureEcls
- DeckImpairmentDisclosureDeltas

Affected Policies

- AccessLevels

References: #EMP-1160

[top](#readme)

## Feature: Pd Lgd Curve Deck Historical Deck Selection Validation

Add new deck validation rules and configurations to validate historical deck selection for Pd and Lgd models in Pd and Lgd curve analysis decks.

References: #EMP-1279

[top](#readme)

## Feature: Remove Disclaimers

Disclaimers are now located in the Security database; this install removes the legacy disclaimer table.

**Note: If you have custom disclaimers they are not migrated to the new location and will need to be recreated in the via Admin Centre.**

References: #EMP-1377

[top](#readme)
