\echo ''
\echo 'Altering DeckObjectiveTypes to support LgdCurve...';

DELETE
  FROM "DeckObjectiveTypes"
 WHERE "Code" IN ('LgdCurveAnalysis');

 \copy "DeckObjectiveTypes" FROM '{data}/LgdCurveAnalysis-DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
