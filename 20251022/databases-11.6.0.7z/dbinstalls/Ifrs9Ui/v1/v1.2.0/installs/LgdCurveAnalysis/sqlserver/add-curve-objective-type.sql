PRINT N''
PRINT N'Altering DeckObjectiveTypes to support Curves...'
GO

DELETE
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] IN ('LgdCurveAnalysis')
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/LgdCurveAnalysis-DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
)
GO
