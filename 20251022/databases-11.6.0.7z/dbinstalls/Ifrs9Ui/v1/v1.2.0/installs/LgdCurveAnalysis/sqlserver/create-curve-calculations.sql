IF EXISTS(select * from sys.tables where name='DeckLgdCurveAnalysisCalculations')
 BEGIN
   PRINT 'Dropping table DeckLgdCurveAnalysisCalculations...'
   DROP TABLE DeckLgdCurveAnalysisCalculations
 END

CREATE TABLE [dbo].DeckLgdCurveAnalysisCalculations (
    [DeckLgdCurveAnalysisCalculationId] uniqueidentifier NOT NULL,
    [DeckId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [Status] nvarchar(50) NOT NULL,
    [Data] nvarchar(max),
    [Sequence] integer NOT NULL,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
);

ALTER TABLE [dbo].DeckLgdCurveAnalysisCalculations
    ADD CONSTRAINT [PK_DeckLgdCurveAnalysisCalculations] PRIMARY KEY (DeckLgdCurveAnalysisCalculationId);

ALTER TABLE [dbo].DeckLgdCurveAnalysisCalculations
    ADD CONSTRAINT FK_DeckLgdCurveAnalysisCalculations_Decks_DeckId
        FOREIGN KEY (DeckId)
        REFERENCES Decks(DeckId) ON DELETE CASCADE;

CREATE INDEX IX_DeckLgdCurveAnalysisCalculations_DeckId ON [dbo].DeckLgdCurveAnalysisCalculations(DeckId);
