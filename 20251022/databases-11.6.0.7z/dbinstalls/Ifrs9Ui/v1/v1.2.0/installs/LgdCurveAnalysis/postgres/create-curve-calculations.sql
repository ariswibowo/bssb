DROP TABLE IF EXISTS "DeckLgdCurveAnalysisCalculations";

CREATE TABLE "DeckLgdCurveAnalysisCalculations" (
    "DeckLgdCurveAnalysisCalculationId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Status" varchar(50) NOT NULL,
    "Data" text,
    "Sequence" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "DeckLgdCurveAnalysisCalculations"
    ADD CONSTRAINT "PK_DeckLgdCurveAnalysisCalculations" PRIMARY KEY ("DeckLgdCurveAnalysisCalculationId");

ALTER TABLE ONLY "DeckLgdCurveAnalysisCalculations"
    ADD CONSTRAINT "FK_DeckLgdCurveAnalysisCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE "DeckLgdCurveAnalysisCalculations" OWNER TO "Empyrean";

CREATE INDEX "IX_DeckLgdCurveAnalysisCalculations_DeckId" ON "DeckLgdCurveAnalysisCalculations" USING btree ("DeckId");
