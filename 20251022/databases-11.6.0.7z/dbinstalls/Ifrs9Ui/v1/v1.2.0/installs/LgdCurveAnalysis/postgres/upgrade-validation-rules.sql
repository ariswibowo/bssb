\echo ''
\echo 'Cleaning up existing validation rules...';

DELETE
  FROM "UiValidationConfigurations";

DELETE
  FROM "UiValidationRules";

\echo ''
\echo 'Adding new validation rules...';

\copy "UiValidationRules" FROM '{data}/LgdCurveAnalysis-UiValidationRules.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;

\copy "UiValidationConfigurations" FROM '{data}/LgdCurveAnalysis-UiValidationConfigurations.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
