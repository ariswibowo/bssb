PRINT N''
PRINT N'Cleaning up existing validation rules...'

GO

DELETE
  FROM [dbo].[UiValidationConfigurations]

GO

DELETE
  FROM [dbo].[UiValidationRules]

GO

PRINT N''
PRINT N'Adding new validation rules...'

GO

BULK INSERT [dbo].[UiValidationRules]
FROM '{data}/LgdCurveAnalysis-UiValidationRules.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);

GO

BULK INSERT [dbo].[UiValidationConfigurations]
FROM '{data}/LgdCurveAnalysis-UiValidationConfigurations.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);

GO
