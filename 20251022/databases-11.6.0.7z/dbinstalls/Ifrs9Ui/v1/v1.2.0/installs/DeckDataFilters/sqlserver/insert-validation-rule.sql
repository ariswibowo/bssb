PRINT N''
PRINT N'Cleaning up existing validation rules...'
GO

DELETE [vc]
  FROM [dbo].[UiValidationConfigurations] [vc]
  JOIN [dbo].[UiValidationRules] [vr]
    ON [vr].[RuleId] = [vc].[RuleId]
 WHERE [vr].[Code] = 'deck-allow-filters'
GO

DELETE
  FROM [dbo].[UiValidationRules]
 WHERE [Code] = 'deck-allow-filters'
GO

PRINT N''
PRINT N'Adding new validation rules...'
GO

BULK INSERT [dbo].[UiValidationRules]
FROM '{data}/DeckDataFilters-UiValidationRules.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO

BULK INSERT [dbo].[UiValidationConfigurations]
FROM '{data}/DeckDataFilters-UiValidationConfigurations.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO
