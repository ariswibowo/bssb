PRINT N''
PRINT N'Preparing policies table...'
GO

DELETE
  FROM [dbo].[DeckPolicies]
 WHERE [PolicyType] = 'DeckFiltersPolicy';

PRINT N''
PRINT N'Adding DeckFiltersPolicy policy...'
GO

BULK INSERT [dbo].[DeckPolicies]
FROM '{data}/DeckDataFilters-DeckPolicies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO
