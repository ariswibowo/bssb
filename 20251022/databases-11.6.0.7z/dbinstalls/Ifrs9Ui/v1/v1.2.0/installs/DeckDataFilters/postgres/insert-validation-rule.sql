\echo ''
\echo 'Cleaning up existing validation rules...';

DELETE
  FROM "UiValidationConfigurations" "vc"
 USING "UiValidationRules" "vr"
 WHERE "vr"."RuleId" = "vc"."RuleId"
   AND "vr"."Code" = 'deck-allow-filters';

DELETE
  FROM "UiValidationRules"
 WHERE "Code" = 'deck-allow-filters';

\echo ''
\echo 'Adding new validation rules...';

\copy "UiValidationRules" FROM '{data}/DeckDataFilters-UiValidationRules.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;

\copy "UiValidationConfigurations" FROM '{data}/DeckDataFilters-UiValidationConfigurations.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
