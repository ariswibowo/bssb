\echo ''
\echo 'Preparing policies table...';

DELETE
  FROM "DeckPolicies"
 WHERE "PolicyType" = 'DeckFiltersPolicy';

\echo '';
\echo 'Adding DeckFiltersPolicy policy...';

\copy "DeckPolicies" FROM '{data}/DeckDataFilters-DeckPolicies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
