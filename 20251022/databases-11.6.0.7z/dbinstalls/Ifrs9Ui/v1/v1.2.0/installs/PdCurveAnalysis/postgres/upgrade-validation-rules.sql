\echo ''
\echo 'Cleaning up existing validation rules...';

DELETE
  FROM "UiValidationConfigurations";

DELETE
  FROM "UiValidationRules";

\echo ''
\echo 'Adding new validation rules...';

\copy "UiValidationRules" FROM '{data}/PdCurveAnalysis-UiValidationRules.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;

\copy "UiValidationConfigurations" FROM '{data}/PdCurveAnalysis-UiValidationConfigurations.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
