\echo ''
\echo 'Installing Impairment Curve-Based Deck Objective Types...';

-- note: scripts uses fixed UUIDs here for safety as we are swapping codes/names

-- update legacy Impairment Objective Type
UPDATE "DeckObjectiveTypes"
   SET "Name"        = 'IFRS9-Impairment(F)',
       "Description" = 'IFRS9-Impairment(F)',
       "Code"        = 'Ifrs9ImpairmentF'
 WHERE "ObjectiveTypeId" = '30b6f7fc-486f-4e5f-a53d-d11a6ca7833c';

-- initialize new impairment Objective Type
DELETE
  FROM "DeckObjectiveTypes"
 WHERE "ObjectiveTypeId" = 'c1cb95d2-3144-45dc-9670-b5719ff4ff5b';

-- add new Impairment Objective Type
\copy "DeckObjectiveTypes" FROM '{data}/ImpairmentCurves-DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
