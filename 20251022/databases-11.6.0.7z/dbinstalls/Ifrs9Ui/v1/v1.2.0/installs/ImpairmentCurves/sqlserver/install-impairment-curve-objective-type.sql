PRINT N''
PRINT N'Installing Impairment Curve-Based Deck Objective Types...';
GO

-- note: scripts uses fixed UUIDs here for safety as we are swapping codes/names

-- update legacy Impairment Objective Type
UPDATE [dbo].[DeckObjectiveTypes]
   SET [Name]        = 'IFRS9-Impairment(F)',
       [Description] = 'IFRS9-Impairment(F)',
       [Code]        = 'Ifrs9ImpairmentF'
 WHERE [ObjectiveTypeId] = '30b6f7fc-486f-4e5f-a53d-d11a6ca7833c';
GO

-- initialize new impairment Objective Type
DELETE
  FROM [dbo].[DeckObjectiveTypes]
  WHERE [ObjectiveTypeId] = 'c1cb95d2-3144-45dc-9670-b5719ff4ff5b';
GO

-- add new Impairment Objective Type
BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/ImpairmentCurves-DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
)
GO
