IF EXISTS(select * from sys.tables where name='DeckRecoveryAnalysisCalculations')
 BEGIN
   PRINT 'Dropping table DeckRecoveryAnalysisCalculations...'
   DROP TABLE [dbo].[DeckRecoveryAnalysisCalculations]
 END

CREATE TABLE [dbo].[DeckRecoveryAnalysisCalculations] (
    [DeckRecoveryAnalysisCalculationId] uniqueidentifier NOT NULL,
    [DeckId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [Status] nvarchar(50) NOT NULL,
    [Data] nvarchar(max),
    [Sequence] integer NOT NULL,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
);

ALTER TABLE [dbo].[DeckRecoveryAnalysisCalculations]
    ADD CONSTRAINT [PK_DeckRecoveryAnalysisCalculations] PRIMARY KEY ([DeckRecoveryAnalysisCalculationId]);

ALTER TABLE [dbo].[DeckRecoveryAnalysisCalculations]
    ADD CONSTRAINT [FK_DeckRecoveryAnalysisCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

CREATE INDEX [IX_DeckRecoveryAnalysisCalculations_DeckId] ON [dbo].[DeckRecoveryAnalysisCalculations]([DeckId]);
