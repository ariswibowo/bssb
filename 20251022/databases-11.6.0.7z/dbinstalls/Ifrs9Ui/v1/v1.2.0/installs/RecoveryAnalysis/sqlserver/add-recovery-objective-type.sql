PRINT N''
PRINT N'Altering DeckObjectiveTypes to support Curves...'
GO

DELETE
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] IN ('RecoveryAnalysis')
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/RecoveryAnalysis-DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
)
GO
