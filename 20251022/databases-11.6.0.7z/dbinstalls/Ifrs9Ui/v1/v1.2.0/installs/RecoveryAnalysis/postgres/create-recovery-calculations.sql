DROP TABLE IF EXISTS "DeckRecoveryAnalysisCalculations";

CREATE TABLE "DeckRecoveryAnalysisCalculations" (
    "DeckRecoveryAnalysisCalculationId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Status" varchar(50) NOT NULL,
    "Data" text,
    "Sequence" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "DeckRecoveryAnalysisCalculations"
    ADD CONSTRAINT "PK_DeckRecoveryAnalysisCalculations" PRIMARY KEY ("DeckRecoveryAnalysisCalculationId");

ALTER TABLE ONLY "DeckRecoveryAnalysisCalculations"
    ADD CONSTRAINT "FK_DeckRecoveryAnalysisCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE "DeckRecoveryAnalysisCalculations" OWNER TO "Empyrean";

CREATE INDEX "IX_DeckRecoveryAnalysisCalculations_DeckId" ON "DeckRecoveryAnalysisCalculations" USING btree ("DeckId");
