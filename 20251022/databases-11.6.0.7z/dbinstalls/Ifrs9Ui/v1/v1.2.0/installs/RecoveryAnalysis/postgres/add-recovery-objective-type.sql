\echo ''
\echo 'Altering DeckObjectiveTypes to support RecoveryAnalysis...';

DELETE
  FROM "DeckObjectiveTypes"
 WHERE "Code" IN ('RecoveryAnalysis');

 \copy "DeckObjectiveTypes" FROM '{data}/RecoveryAnalysis-DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
