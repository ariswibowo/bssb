DROP TABLE IF EXISTS dbo.DeckImpairmentDisclosureChecks;

CREATE TABLE [dbo].DeckImpairmentDisclosureChecks (
    [CheckId] uniqueidentifier NOT NULL,
    [Name] nvarchar(100) NOT NULL,
    [Code] nvarchar(50) NOT NULL,
    [Description] nvarchar(300) NOT NULL,
    [Recommended] bit,
    [Url] nvarchar(300) NOT NULL
);

ALTER TABLE [dbo].DeckImpairmentDisclosureChecks
    ADD CONSTRAINT [PK_DeckImpairmentDisclosureChecks] PRIMARY KEY (CheckId);
go

BULK INSERT [dbo].DeckImpairmentDisclosureChecks
FROM '{data}/ImpairmentDisclosureChecks-DeckImpairmentDisclosureChecks.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
