DROP TABLE IF EXISTS "DeckImpairmentDisclosureChecks";

CREATE TABLE "DeckImpairmentDisclosureChecks" (
    "CheckId" uuid NOT NULL,
    "Name" varchar(100) NOT NULL,
    "Code" varchar(50) NOT NULL,
    "Description" varchar(300) NOT NULL,
    "Recommended" boolean,
    "Url" text
);

ALTER TABLE ONLY "DeckImpairmentDisclosureChecks"
    ADD CONSTRAINT "PK_DeckImpairmentDisclosureChecks" PRIMARY KEY ("CheckId");

ALTER TABLE "DeckImpairmentDisclosureChecks" OWNER TO "Empyrean";

\copy "DeckImpairmentDisclosureChecks" FROM '{data}/ImpairmentDisclosureChecks-DeckImpairmentDisclosureChecks.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
