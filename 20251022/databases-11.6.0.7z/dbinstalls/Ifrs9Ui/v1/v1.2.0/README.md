# README

**Release: Ifrs9 UI V1.2.0**

## Release Features & Fixes

- [Feature: Lgd Curve Analysis](#feature-lgd-curves-analysis)
- [Feature: Pd Curve Analysis](#feature-pd-curve-analysis)
- [Feature: Recovery Analysis](#feature-recovery-analysis)
- [Feature: Impairment Curves](#feature-impairment-curves)
- [Fix: Impairment Disclosure Checks](#hotfix-impairment-disclosure-checks)
- [Feature: Deck Data Filters](#feature-data-filters)

## Feature: Lgd Curves Analysis

Implements support for Lgd Curve Analysis deck type and calculation. This update adds a new objective type and a new LgdCurveAnalysisCalculations table, and deploys new Green Heart validation rules and configurations.

### New Validation Rules

| Rule                         | Type  | Purpose                                                 |
| ---------------------------- | ----- | ------------------------------------------------------- |
| curve-lgd-version-configured | error | The Deck should have a valid Curve LGD model configured |

References: #EMP-475, #EMP-487

[top](#readme)

## Feature: Pd Curve Analysis

Implements additional Green Heart validations for the PD Curve Analysis decks.

### New Validation Rules

| Rule                        | Type  | Purpose                                                |
| --------------------------- | ----- | ------------------------------------------------------ |
| curve-pd-version-configured | error | The Deck should have a valid Curve PD model configured |

Reference: #EMP-487

[top](#readme)

## Feature: Recovery Analysis

Implements support for Recovery Analysis deck type and calculation. This update adds new objective type and new RecoveryAnalysisCalculations table.

Reference: #EMP-554 </br>

[top](#readme)

## Feature: Impairment Curves

Implements a new Deck Impairment Objective type to support curve-based Impairment calculations.
The current Impairment objective type is renamed to IFRS9-Impairment(F) for the existing forward-looking approach. In future this approach will be deprecated.

Reference: #EMP-475

[top](#readme)

## Fix: Impairment Disclosure Checks

Fixes a bug where column Recommended is missing from the DeckImpairmentDisclosureChecks table for SQLServer in V1.0.0.
The fix re-installs the table for both postgres and sqlserver.

Reference: #EMP-486

[top](#readme)

## Feature: Deck Data Filters

Installs the new Deck Data Filters feature that allows filtering of decks to run for specific filter criteria (eg. product type X, product subtype Y).

The install adds a new policy "DeckFiltersPolicy" and a new deck validation rule. By default the policy allow data-filters on all deck types except for Regulatory decks.

### New Validation Rules

| Rule               | Type  | Purpose                                        |
| ------------------ | ----- | ---------------------------------------------- |
| deck-allow-filters | error | Deck Data filters should be allowed per policy |

Reference: #EMP-506 </br>

[top](#readme)
