# README

**Release: Models V5.2.0**

## Release Features & Fixes

- [Feature: Reports Library](#feature-reports-library)

## Feature: Reports Library

Installs the reports library table used for UI standard and custom reports.

[top](#readme)
