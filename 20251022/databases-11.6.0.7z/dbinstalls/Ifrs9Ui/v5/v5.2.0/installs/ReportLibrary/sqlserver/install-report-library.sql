PRINT N'';
PRINT N'Installing ReportLibrary table...';
GO

DROP TABLE IF EXISTS [dbo].[ReportLibrary];
GO

CREATE TABLE [dbo].[ReportLibrary] (
    [ReportLibraryId] uniqueidentifier NOT NULL,
    [ReportLibrary] nvarchar(50) NOT NULL,
    [Description] nvarchar(300) NOT NULL,
    [DefaultReports] nvarchar(max) NOT NULL,
    [ActiveReports] nvarchar(max),
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
)
GO

ALTER TABLE [dbo].[ReportLibrary]
    ADD CONSTRAINT [PK_ReportLibrary] PRIMARY KEY ([ReportLibraryId]);
GO

BULK INSERT [dbo].[ReportLibrary]
FROM '{data}/ReportLibrary.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);