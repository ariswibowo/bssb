\echo '';
\echo 'Installing ReportLibrary table...';

DROP TABLE IF EXISTS "ReportLibrary";

CREATE TABLE "ReportLibrary" (
    "ReportLibraryId" uuid NOT NULL,
    "ReportLibrary" varchar(50) NOT NULL,
    "Description" varchar(300) NOT NULL,
    "DefaultReports" text NOT NULL,
    "ActiveReports" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "ReportLibrary"
    ADD CONSTRAINT "PK_ReportLibrary" PRIMARY KEY ("ReportLibraryId");

ALTER TABLE "ReportLibrary" OWNER TO "Empyrean";

\copy "ReportLibrary" FROM '{data}/ReportLibrary.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
