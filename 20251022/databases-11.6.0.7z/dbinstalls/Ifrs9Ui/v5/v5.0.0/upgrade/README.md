# README

## Release: Ifrs9Ui v5.0.0 (upgrade)

### Release Features & Fixes

- [Feature: Remove Deprecated Tables](#feature-remove-deprecated-tables)

### Feature: Remove Deprecated Tables

Remove/Drop Blueprints and Scehdules related tables; these are no longer used.

[top](#readme)
