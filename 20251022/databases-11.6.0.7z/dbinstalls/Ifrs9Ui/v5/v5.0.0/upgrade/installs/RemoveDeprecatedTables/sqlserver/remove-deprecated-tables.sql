PRINT N'';
PRINT N'Dropping Deck Blueprint Tables...';

DROP TABLE IF EXISTS [dbo].[BlueprintActivities];
DROP TABLE IF EXISTS [dbo].[BlueprintEcls];
DROP TABLE IF EXISTS [dbo].[Blueprints];
GO

PRINT N'';
PRINT N'Dropping Schedules Tables...';

DROP TABLE IF EXISTS [dbo].[ScheduleActivities];
DROP TABLE IF EXISTS [dbo].[Schedules];
GO