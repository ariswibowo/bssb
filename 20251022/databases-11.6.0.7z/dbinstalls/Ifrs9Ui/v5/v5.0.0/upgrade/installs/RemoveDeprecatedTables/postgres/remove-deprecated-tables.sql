\echo '';
\echo 'Dropping Deck Blueprint Tables...';

DROP TABLE IF EXISTS "BlueprintActivities";
DROP TABLE IF EXISTS "BlueprintEcls";
DROP TABLE IF EXISTS "Blueprints";

\echo '';
\echo 'Dropping Schedules Tables...';

DROP TABLE IF EXISTS "ScheduleActivities";
DROP TABLE IF EXISTS "Schedules";
