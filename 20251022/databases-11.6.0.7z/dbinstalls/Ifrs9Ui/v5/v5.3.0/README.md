# README

**Release: Models V5.3.0**

## Release Features & Fixes

- [Feature: Credit Risk Objective](#feature-credit-risk-objective)
- [Feature: Application Log](#feature-application-log)
- [Feature: Deck Props](#feature-deck-props)
- [Feature: Impairment 2](#feature-impairment2)
- [Feature: Accounting](#feature-remove-accounting)
- [Feature: Credit Risk Reports](#feature-credit-risk-reports)
- [Feature: Deck Status Pascal Case](#feature-deck-status-pascal-case)

## Feature: Credit Risk Objective

Add new deck objective type for Credit Risk
Update contract details policy to support the Credit Risk

[top](#readme)

## Feature: Application Log

- Install the ApplicationLogs table.
- Add log retention prop into Garbage Collection policy to support log retention engine.

[top](#readme)

## Feature: Deck Props

- Install the DeckProps table to store metadata related to deck.

[top](#readme)

## Feature: Impairment 2

Add new deck objective type, Ifrs9 Impairment2

[top](#readme)

## Feature: Remove Accounting

Remove deck validation that has reference to accounting models
Remove deck disclosure check that has reference to accounting models

[top](#readme)

## Feature: Credit Risk Reports

Adds IsSecured and CreditConversionFactor to the list of available fields for Credit Risk Calculation Analysis reports.

[top](#readme)

## Feature: Deck Status Pascal Case

Convert deck status to pascal case

[top](#readme)