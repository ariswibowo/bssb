PRINT N''
PRINT N'Removing existing Credit Risk reports...'
GO

DELETE 
  FROM [dbo].[ReportLibrary]
 WHERE [ReportLibrary] = 'CreditRiskCalculationAnalysis';
GO

PRINT N'Installing Credit Risk reports...';
GO

BULK INSERT [dbo].[ReportLibrary]
FROM '{data}/CreditRiskReports-ReportLibrary.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO