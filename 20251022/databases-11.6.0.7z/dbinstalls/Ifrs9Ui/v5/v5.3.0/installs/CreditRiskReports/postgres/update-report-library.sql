\echo ''
\echo 'Removing existing Credit Risk reports...';

DELETE 
  FROM "ReportLibrary"
 WHERE "ReportLibrary" = 'CreditRiskCalculationAnalysis';

\echo 'Installing Credit Risk reports...';

\copy "ReportLibrary" FROM '{data}/CreditRiskReports-ReportLibrary.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;