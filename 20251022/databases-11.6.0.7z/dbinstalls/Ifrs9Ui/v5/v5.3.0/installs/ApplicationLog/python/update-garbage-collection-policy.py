import dbhelper
import dbpolicies

def main(config):

    # add edge features to policy
    dbpolicies.updatePolicy(table="DeckPolicies",
                            type="GarbageCollection",
                            config=config,
                            updatefunc=addLogRetention)
    return

def addLogRetention(policy, context):

    return {**policy, "logRetention": 10}