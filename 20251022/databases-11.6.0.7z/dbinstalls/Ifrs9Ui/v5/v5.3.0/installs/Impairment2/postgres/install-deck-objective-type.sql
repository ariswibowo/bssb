\echo ''
\echo 'Removing existing Impairment2 deck objective type...';

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'Ifrs9Impairment2';

\echo 'Installing Impairment2 deck objective type...';

\copy "DeckObjectiveTypes" FROM '{data}/Impairment2DeckObjectiveType.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;