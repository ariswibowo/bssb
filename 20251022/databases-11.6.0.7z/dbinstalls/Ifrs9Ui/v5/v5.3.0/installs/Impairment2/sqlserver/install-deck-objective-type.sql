PRINT N''
PRINT N'Removing existing Impairment2 deck objective type...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'Ifrs9Impairment2';
GO

PRINT N'Installing Impairment2 deck objective type...';
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/Impairment2DeckObjectiveType.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO