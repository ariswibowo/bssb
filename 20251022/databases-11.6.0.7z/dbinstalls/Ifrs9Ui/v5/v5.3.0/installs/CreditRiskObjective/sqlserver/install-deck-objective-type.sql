PRINT N''
PRINT N'Removing existing Credit Risk deck objective type...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'CreditRisk';
GO

PRINT N'Installing Credit Risk deck objective type...';
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/CreditRiskDeckObjectiveType.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO