import dbhelper
import dbpolicies

def main(config):

    # get the ContractDetails policy
    contract_details_policy = dbpolicies.get_policy(
        "DeckPolicies", "ContractDetails", config)

    # touch only when data present
    if contract_details_policy is not None:
        # update policies
        update_contract_details_policy(contract_details_policy)

        dbpolicies.update_policy(contract_details_policy, config)

    return

def update_contract_details_policy(contract_details_policy):

    default_policy = contract_details_policy['defaultPolicy']
    active_policy = contract_details_policy['activePolicy']

    if default_policy is not None and default_policy != {}:
        update_config(default_policy)

    if active_policy is not None and active_policy != {}:
        update_config(active_policy)

def update_config(policy):
    configs = policy["config"]

    cash_flow_and_risk_config = next((config for config in configs if config['template'] == "cashFlowAndRisk"), None)

    if cash_flow_and_risk_config is not None:
        if "CreditRisk" not in cash_flow_and_risk_config["context"]:
            cash_flow_and_risk_config["context"].append("CreditRisk")
    # cashFlowAndRisk config is not found, add the config.
    else:
        configs.append(0,{"context":["CreditRisk"],"productType":[],"productSubtype":[],"template":"cashFlowAndRisk"})

    check_template(policy)

def check_template(policy):
    templates = policy["templates"]

    cash_flow_and_risk_template = next((template for template in templates if "cashFlowAndRisk" in template), None)

    # cashFlowAndRisk template is not found, add the template.
    if cash_flow_and_risk_template is None:
        templates.append({"cashFlowAndRisk":{"columns":[{"rows":[{"label":"Contract Id","value":"originContractId","type":"string","format":None,"whenEmpty":"show"},{"label":"Counterparty","value":"counterpartyName","type":"string","format":None,"whenEmpty":"show"},{"label":"Maturity Date","value":"maturityDate","type":"date","format":"MMM DD, YYYY","whenEmpty":"show"},{"label":"Days Past Due","value":"daysPastDue","type":"number","format":"0","whenEmpty":"show"},{"label":"Start Date","value":"startDate","type":"date","format":"MMM DD, YYYY","whenEmpty":"show"},{"label":"Outstanding Amount","value":"outstandingAmount","type":"number","format":"0,0.00","whenEmpty":"show"},{"label":"Accrued Interest","value":"accruedInterest","type":"number","format":"0,0.00","whenEmpty":"show"},{"label":"Principal Amount","value":"principalAmount","type":"number","format":"0,0.00","whenEmpty":"show"}]},{"rows":[{"label":"Interest Rate","value":"interestRate","type":"number","format":"0,0.000000000","whenEmpty":"show"},{"label":"Effective Interest Rate","value":"effectiveInterestRate","type":"number","format":"0,0.000000000","whenEmpty":"show"},{"label":"Credit Rating","value":"creditRating","type":"string","format":None,"whenEmpty":"show"},{"label":"Credit Rating Agency","value":"creditRatingAgency","type":"string","format":None,"whenEmpty":"show"},{"label":"Product Type","value":"productType","type":"string","format":None,"whenEmpty":"show"},{"label":"Product Subtype","value":"productSubtype","type":"string","format":None,"whenEmpty":"show"},{"label":"Segment","value":"segment","type":"string","format":None,"whenEmpty":"show"},{"label":"Collectibility","value":"collectibility","type":"string","format":None,"whenEmpty":"show"}]},{"rows":[{"label":"Base Pd","value":"basePd","type":"number","format":"0,0.000000000","whenEmpty":"show"},{"label":"Base Lgd","value":"baseLgd","type":"number","format":"0,0.000000000","whenEmpty":"show"},{"label":"Undrawn Amount","value":"undrawnAmount","type":"number","format":"0,0.00","whenEmpty":"show"},{"label":"Limit Amount","value":"limitAmount","type":"number","format":"0,0.00","whenEmpty":"show"}]}]}})