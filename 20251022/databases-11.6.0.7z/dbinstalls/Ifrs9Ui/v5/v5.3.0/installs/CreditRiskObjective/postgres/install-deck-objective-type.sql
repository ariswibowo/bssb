\echo ''
\echo 'Removing existing Credit Risk deck objective type...';

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'CreditRisk';

\echo 'Installing Credit Risk deck objective type...';

\copy "DeckObjectiveTypes" FROM '{data}/CreditRiskDeckObjectiveType.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;