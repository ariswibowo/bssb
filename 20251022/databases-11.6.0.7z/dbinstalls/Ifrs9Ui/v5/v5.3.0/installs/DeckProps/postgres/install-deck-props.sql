\echo '';
\echo 'Installing DeckProps table...';

\echo '';
\echo 'Dropping DeckProps table...';
DROP TABLE IF EXISTS "DeckProps";
DROP SEQUENCE IF EXISTS "DeckProps_Id_seq";

\echo '';
\echo 'Creating DeckProps table...';
CREATE SEQUENCE "DeckProps_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "DeckProps_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "DeckProps" (
    "Id" bigint DEFAULT nextval('"DeckProps_Id_seq"'::regclass) NOT NULL,
    "DeckPropId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "Key" varchar(100) NOT NULL,
    "Value" text NOT NULL
);

ALTER TABLE ONLY "DeckProps"
    ADD CONSTRAINT "PK_DeckProps" PRIMARY KEY ("DeckPropId");

ALTER TABLE ONLY "DeckProps"
    ADD CONSTRAINT "FK_DeckProps_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE "DeckProps" OWNER TO "Empyrean";
