PRINT N'';
PRINT N'Installing DeckProps table...';
GO

PRINT N'';
PRINT N'Dropping DeckProps table...';
DROP TABLE IF EXISTS [dbo].[DeckProps];
GO

PRINT N'';
PRINT N'Creating DeckProps table...';
CREATE TABLE [dbo].[DeckProps] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [DeckPropId] uniqueidentifier NOT NULL,
    [DeckId] uniqueidentifier NOT NULL,
    [Key] nvarchar(100) NOT NULL,
    [Value] nvarchar(max) NOT NULL
);

ALTER TABLE [dbo].[DeckProps]
    ADD CONSTRAINT [PK_DeckProps] PRIMARY KEY ([DeckPropId]);
GO

ALTER TABLE [dbo].[DeckProps]
    ADD CONSTRAINT [FK_DeckProps_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [dbo].[Decks]([DeckId]) ON DELETE CASCADE;
GO