\echo '';
\echo 'Updating deck status...';

UPDATE "Decks"
  SET "Status" = INITCAP("Status");