PRINT N'';
PRINT N'Updating deck status...';
GO

UPDATE [dbo].[Decks]
  SET [Status] = UPPER(LEFT([Status],1)) + LOWER(SUBSTRING([Status],2,LEN([Status])));
GO