PRINT N''
PRINT N'Removing existing DeckImpairmentDisclosureChecks on accounting...'
GO

DELETE 
  FROM [dbo].[DeckImpairmentDisclosureChecks]
 WHERE [Code] = 'accounting-ruleset-changed'
GO