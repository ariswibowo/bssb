\echo ''
\echo 'Removing existing UiValidationConfigurations on accounting...';

DELETE 
  FROM "UiValidationConfigurations" "c"
 USING "UiValidationRules" "r"
 WHERE "c"."RuleId" = "r"."RuleId"
  AND "r"."Code" = 'acct-version-configured';

\echo ''
\echo 'Removing existing UiValidationRules on accounting...';

DELETE 
  FROM "UiValidationRules"
 WHERE "Code" = 'acct-version-configured';