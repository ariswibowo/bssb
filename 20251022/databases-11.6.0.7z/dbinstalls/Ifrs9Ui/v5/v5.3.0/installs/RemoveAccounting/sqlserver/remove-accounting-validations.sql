PRINT N''
PRINT N'Removing existing UiValidationConfigurations on accounting...'
GO

DELETE [c]
  FROM [dbo].[UiValidationConfigurations] [c]
  JOIN [dbo].[UiValidationRules] [r]
   ON [c].[RuleId] = [r].[RuleId]
 WHERE [r].[Code] = 'acct-version-configured'
GO

PRINT N''
PRINT N'Removing existing UiValidationRules on accounting...'
GO

DELETE 
  FROM [dbo].[UiValidationRules]
 WHERE [Code] = 'acct-version-configured'