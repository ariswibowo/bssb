\echo ''
\echo 'Removing existing DeckImpairmentDisclosureChecks on accounting...';

DELETE 
  FROM "DeckImpairmentDisclosureChecks"
 WHERE "Code" = 'accounting-ruleset-changed';