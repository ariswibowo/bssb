# README

**Release: Models V5.1.0**

## Release Features & Fixes

- [Feature: Irb Base Calculation](#feature-irb-base-calculation)

## Feature: Irb Base Calculation

Add new deck objective type for IRB Base
Update contract details policy to support the IRB Base

[top](#readme)
