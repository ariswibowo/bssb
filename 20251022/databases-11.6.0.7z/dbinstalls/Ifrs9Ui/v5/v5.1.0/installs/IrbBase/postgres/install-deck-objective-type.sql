\echo ''
\echo 'Removing existing IRB Base deck objective type...';

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'IrbBase';

\echo 'Installing IRB Base deck objective type...';

\copy "DeckObjectiveTypes" FROM '{data}/IRBBaseDeckObjectiveType.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;