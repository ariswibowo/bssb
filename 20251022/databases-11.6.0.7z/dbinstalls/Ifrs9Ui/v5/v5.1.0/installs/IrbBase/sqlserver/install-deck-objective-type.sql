PRINT N''
PRINT N'Removing existing IRB Base deck objective type...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'IrbBase';
GO

PRINT N'Installing IRB Base deck objective type...';
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/IRBBaseDeckObjectiveType.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO