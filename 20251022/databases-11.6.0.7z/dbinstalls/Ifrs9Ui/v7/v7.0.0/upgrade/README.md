# README

## Release: Ifrs9UI v7.0.0 (upgrade)

No upgrades required.
