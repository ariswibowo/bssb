PRINT N''
PRINT N'Deleting Workspace deck objective types...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'Workspace';
GO

PRINT N''
PRINT N'Installing Workspace deck objective types...'
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/Workspaces/DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO