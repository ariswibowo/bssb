\echo ''
\echo 'Deleting Workspace deck objective type...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'Workspace';

\echo ''
\echo 'Installing Workspace deck objective type...'

\copy "DeckObjectiveTypes" FROM '{data}/Workspaces/DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;