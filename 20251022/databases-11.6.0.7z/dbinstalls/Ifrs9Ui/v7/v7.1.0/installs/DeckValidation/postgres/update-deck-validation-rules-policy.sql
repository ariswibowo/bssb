\echo ''
\echo 'Deleting existing Deck validation rules policy...';

DELETE
  FROM "DeckPolicies"
 WHERE "PolicyType" = 'DeckValidationRules';

\echo ''
\echo 'Installing new Deck validation rules policy...';

\copy "DeckPolicies" FROM '{data}/DeckValidation/DeckValidationRulesPolicy.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;