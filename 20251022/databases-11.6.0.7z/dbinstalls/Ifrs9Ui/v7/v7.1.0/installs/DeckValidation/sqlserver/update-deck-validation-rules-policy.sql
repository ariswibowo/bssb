PRINT N''
PRINT N'Deleting existing Deck validation rules policy...'
GO

DELETE 
  FROM [dbo].[DeckPolicies] 
  WHERE [PolicyType] = 'DeckValidationRules'
GO

PRINT N''
PRINT N'Installing new Deck validation rules policy...'
GO

BULK INSERT [dbo].[DeckPolicies]
FROM '{data}/DeckValidation/DeckValidationRulesPolicy.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO