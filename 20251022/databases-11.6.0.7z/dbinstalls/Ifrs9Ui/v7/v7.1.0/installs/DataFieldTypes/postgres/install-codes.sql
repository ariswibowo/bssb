\echo ''
\echo 'Deleting existing data field types codes...'

DELETE
FROM "UiCodes"
WHERE "Type" = 'DataFieldTypes'
AND "Category" = 'Deck';

\echo ''
\echo 'Installing new data field types codes...'

\copy "UiCodes" FROM '{data}/DataFieldTypes/UiCodes.dat' DELIMITER E'\t' CSV QUOTE '#' HEADER;