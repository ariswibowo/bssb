PRINT N''
PRINT N'Deleting existing data field types codes...'
GO

DELETE
 FROM [dbo].[UiCodes]
 WHERE [Type] = 'DataFieldTypes'
 AND [Category] = 'Deck'
GO

PRINT N''
PRINT N'Installing new data field types codes...'
GO

BULK INSERT [dbo].[UiCodes]
FROM '{data}/DataFieldTypes/UiCodes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO