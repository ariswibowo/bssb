PRINT N''
PRINT N'Updating legacy deck status...'
GO

UPDATE [dbo].[Decks]
SET [Status] = 'Open'
WHERE [Status] = 'Initiated';
GO
