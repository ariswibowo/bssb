\echo ''
\echo 'Updating legacy deck status...'

UPDATE "Decks"
SET "Status" = 'Open'
WHERE "Status" = 'Initiated';
