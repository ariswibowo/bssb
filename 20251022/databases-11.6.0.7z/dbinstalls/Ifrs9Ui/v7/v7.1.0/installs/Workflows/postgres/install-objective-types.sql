\echo ''
\echo 'Deleting Workflow deck objective type...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'Workflow';

\echo ''
\echo 'Installing Workflow deck objective type...'

\copy "DeckObjectiveTypes" FROM '{data}/Workflows/DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;