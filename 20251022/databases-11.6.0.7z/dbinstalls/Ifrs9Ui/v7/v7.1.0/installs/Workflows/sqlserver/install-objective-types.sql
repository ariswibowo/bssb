PRINT N''
PRINT N'Deleting Workflow deck objective types...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'Workflow';
GO

PRINT N''
PRINT N'Installing Workflow deck objective types...'
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/Workflows/DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO