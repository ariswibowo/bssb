\echo ''
\echo 'Deleting capital ratio deck objective type...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'CapitalRatio';

\echo ''
\echo 'Installing capital ratio deck objective type...'

\copy "DeckObjectiveTypes" FROM '{data}/CapitalRatio/DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;