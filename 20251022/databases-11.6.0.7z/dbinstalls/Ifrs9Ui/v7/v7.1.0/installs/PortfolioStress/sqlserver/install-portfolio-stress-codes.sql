PRINT N''
PRINT N'Deleting portfolio stress Codes...'
GO

DELETE 
  FROM [dbo].[UiCodes]
 WHERE [Category] = 'Deck'
  AND [Type] = 'PortfolioStress';
GO

PRINT N''
PRINT N'Installing portfolio stress Codes...'
GO

BULK INSERT [dbo].[UiCodes]
FROM '{data}/PortfolioStress/UiCodes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO