\echo ''
\echo 'Deleting portfolio stress Codes...'

DELETE 
  FROM "UiCodes"
 WHERE "Category" = 'Deck'
  AND "Type" = 'PortfolioStress';

\echo ''
\echo 'Installing portfolio stress Codes...'

\copy "UiCodes" FROM '{data}/PortfolioStress/UiCodes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;