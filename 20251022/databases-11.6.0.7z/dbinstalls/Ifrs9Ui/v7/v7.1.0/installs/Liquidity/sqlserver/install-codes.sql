PRINT N''
PRINT N'Deleting existing liquidity scope codes...'
GO

DELETE
 FROM [dbo].[UiCodes]
 WHERE [Type] = 'LiquidityScopes'
 AND [Category] = 'Deck'
GO

PRINT N''
PRINT N'Installing new liquidity scope codes...'
GO

BULK INSERT [dbo].[UiCodes]
FROM '{data}/Liquidity/UiCodes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO