\echo ''
\echo 'Deleting existing liquidity scope codes...'

DELETE
FROM "UiCodes"
WHERE "Type" = 'LiquidityScopes'
AND "Category" = 'Deck';

\echo ''
\echo 'Installing new liquidity scope codes...'

\copy "UiCodes" FROM '{data}/Liquidity/UiCodes.dat' DELIMITER E'\t' CSV QUOTE '#' HEADER;