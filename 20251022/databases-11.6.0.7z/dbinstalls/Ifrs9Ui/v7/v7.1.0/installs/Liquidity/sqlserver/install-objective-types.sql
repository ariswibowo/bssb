PRINT N''
PRINT N'Deleting existing deck objective type...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'Liquidity';
GO

PRINT N''
PRINT N'Installing new deck objective type...'
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/Liquidity/DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO