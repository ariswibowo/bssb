\echo ''
\echo 'Deleting existing deck objective type...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'Liquidity';

\echo ''
\echo 'Installing new deck objective type...'

\copy "DeckObjectiveTypes" FROM '{data}/Liquidity/DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;