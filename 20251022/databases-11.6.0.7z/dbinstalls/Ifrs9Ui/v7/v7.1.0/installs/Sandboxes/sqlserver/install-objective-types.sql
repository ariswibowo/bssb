PRINT N''
PRINT N'Deleting sandbox deck objective types...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] IN ('PortfolioSandbox', 'Sandbox');
GO

PRINT N''
PRINT N'Installing sandbox deck objective types...'
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/Sandboxes/DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO