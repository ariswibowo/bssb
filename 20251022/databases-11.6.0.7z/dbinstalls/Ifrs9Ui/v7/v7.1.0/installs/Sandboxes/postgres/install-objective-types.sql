\echo ''
\echo 'Deleting sandbox deck objective type...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" IN ('PortfolioSandbox', 'Sandbox');

\echo ''
\echo 'Installing sandbox deck objective type...'

\copy "DeckObjectiveTypes" FROM '{data}/Sandboxes/DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;