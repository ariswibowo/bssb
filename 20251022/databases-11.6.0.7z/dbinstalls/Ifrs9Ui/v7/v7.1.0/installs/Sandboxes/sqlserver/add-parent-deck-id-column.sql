PRINT N''
PRINT N'Altering Decks to add ParentDeckId column...'
GO

PRINT N'';
PRINT N'Dropping Constraint...';
ALTER TABLE [dbo].[DeckProps] DROP CONSTRAINT IF EXISTS [FK_DeckProps_Decks_DeckId];

ALTER TABLE [dbo].[DeckCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckCalculations_Decks_DeckId];

ALTER TABLE [dbo].[DeckClassificationCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckClassificationCalculations_Decks_DeckId];

ALTER TABLE [dbo].[DeckClassificationVariances] DROP CONSTRAINT IF EXISTS [FK_DeckClassificationVariances_Decks_DeckId];

ALTER TABLE [dbo].[DeckCfAnalysisCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckCfAnalysisCalculations_Decks_DeckId];

ALTER TABLE [dbo].[DeckHistoricalLgdCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckHistoricalLgdCalculations_Decks_DeckId];

ALTER TABLE [dbo].[DeckHistoricalPdCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckHistoricalPdCalculations_Decks_DeckId];

ALTER TABLE [dbo].[DeckImpairmentEcls] DROP CONSTRAINT IF EXISTS [FK_DeckImpairmentEcls_Decks_DeckId];

ALTER TABLE [dbo].[DeckImpairmentVariances] DROP CONSTRAINT IF EXISTS [FK_DeckImpairmentVariances_Decks_DeckId];

ALTER TABLE [dbo].[DeckImpairmentDisclosures] DROP CONSTRAINT IF EXISTS [FK_DeckImpairmentDisclosures_Decks_DeckId];

ALTER TABLE [dbo].[DeckPdCurveAnalysisCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckPdCurveAnalysisCalculations_Decks_DeckId];

ALTER TABLE [dbo].[DeckLgdCurveAnalysisCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckLgdCurveAnalysisCalculations_Decks_DeckId];

ALTER TABLE [dbo].[DeckRecoveryAnalysisCalculations] DROP CONSTRAINT IF EXISTS [FK_DeckRecoveryAnalysisCalculations_Decks_DeckId];
GO

PRINT N''
PRINT N'Creating Install Backup Table...'
EXEC sp_rename '[dbo].[Decks]', 'Decks-INSTALLTMP';
GO

PRINT N''
PRINT N'Creating New Decks Table...'
CREATE TABLE [dbo].[Decks] (
    [DeckId] uniqueidentifier NOT NULL,
    [Name] nvarchar(100) NOT NULL,
    [Description] nvarchar(300) NOT NULL,
    [DeckTypeId] uniqueidentifier NOT NULL,
    [ObjectiveTypeId] uniqueidentifier NOT NULL,
    [ParentDeckId] uniqueidentifier NULL,
    [Data] nvarchar(max),
    [ReportingDate] datetime NOT NULL,
    [ExpiryDate] datetime,
    [EntityId] uniqueidentifier,
    [Currency] nchar(3),
    [IsPrivate] bit NOT NULL,
    [Status] nvarchar(50) NOT NULL,
    [ConcurrencyId] uniqueidentifier NOT NULL,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
);
GO

PRINT N'Repopulating Data from Backup...'
INSERT INTO [dbo].[Decks]
(
  [DeckId],
  [Name],
  [Description],
  [DeckTypeId],
  [ObjectiveTypeId],
  [ParentDeckId],
  [Data],
  [ReportingDate],
  [ExpiryDate],
  [EntityId],
  [Currency],
  [IsPrivate],
  [Status],
  [ConcurrencyId],
  [CreatedBy],
  [CreatedWhen],
  [LastModifiedBy],
  [LastModifiedWhen]
)
SELECT
  [DeckId],
  [Name],
  [Description],
  [DeckTypeId],
  [ObjectiveTypeId],
  NULL AS [ParentDeckId],
  [Data],
  [ReportingDate],
  [ExpiryDate],
  [EntityId],
  [Currency],
  [IsPrivate],
  [Status],
  [ConcurrencyId],
  [CreatedBy],
  [CreatedWhen],
  [LastModifiedBy],
  [LastModifiedWhen]
FROM [dbo].[Decks-INSTALLTMP]
GO

PRINT N''
PRINT N'Dropping Legacy Constraints/Indexes...'
ALTER TABLE [dbo].[Decks-INSTALLTMP] DROP CONSTRAINT [PK_Decks];
GO

PRINT N''
PRINT N'Recreating Constraints...'
ALTER TABLE [dbo].[Decks]
    ADD CONSTRAINT [PK_Decks] PRIMARY KEY ([DeckId]);

ALTER TABLE [dbo].[DeckProps]
    ADD CONSTRAINT [FK_DeckProps_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [dbo].[Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckCalculations]
    ADD CONSTRAINT [FK_DeckCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckClassificationCalculations]
    ADD CONSTRAINT [FK_DeckClassificationCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckClassificationVariances]
    ADD CONSTRAINT [FK_DeckClassificationVariances_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckCfAnalysisCalculations]
    ADD CONSTRAINT [FK_DeckCfAnalysisCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckHistoricalLgdCalculations]
    ADD CONSTRAINT [FK_DeckHistoricalLgdCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckHistoricalPdCalculations]
    ADD CONSTRAINT [FK_DeckHistoricalPdCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckImpairmentEcls]
    ADD CONSTRAINT [FK_DeckImpairmentEcls_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckImpairmentVariances]
    ADD CONSTRAINT [FK_DeckImpairmentVariances_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckImpairmentDisclosures]
    ADD CONSTRAINT [FK_DeckImpairmentDisclosures_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckPdCurveAnalysisCalculations]
    ADD CONSTRAINT [FK_DeckPdCurveAnalysisCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckLgdCurveAnalysisCalculations]
    ADD CONSTRAINT [FK_DeckLgdCurveAnalysisCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;

ALTER TABLE [dbo].[DeckRecoveryAnalysisCalculations]
    ADD CONSTRAINT [FK_DeckRecoveryAnalysisCalculations_Decks_DeckId]
        FOREIGN KEY ([DeckId])
        REFERENCES [Decks]([DeckId]) ON DELETE CASCADE;
GO

PRINT N''
PRINT N'Dropping Work Table...'
DROP TABLE [dbo].[Decks-INSTALLTMP]
GO
