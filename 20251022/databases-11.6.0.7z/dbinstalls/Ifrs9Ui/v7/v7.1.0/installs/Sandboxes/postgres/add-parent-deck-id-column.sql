\echo '';
\echo 'Altering Decks to add ParentDeckId column...';

\echo '';
\echo 'Dropping Constraints...';
ALTER TABLE "DeckProps" DROP CONSTRAINT IF EXISTS "FK_DeckProps_Decks_DeckId";

ALTER TABLE "DeckCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckCalculations_Decks_DeckId";

ALTER TABLE "DeckClassificationCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckClassificationCalculations_Decks_DeckId";

ALTER TABLE "DeckClassificationVariances" DROP CONSTRAINT IF EXISTS "FK_DeckClassificationVariances_Decks_DeckId";

ALTER TABLE "DeckCfAnalysisCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckCfAnalysisCalculations_Decks_DeckId";

ALTER TABLE "DeckHistoricalLgdCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckHistoricalLgdCalculations_Decks_DeckId";

ALTER TABLE "DeckHistoricalPdCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckHistoricalPdCalculations_Decks_DeckId";

ALTER TABLE "DeckImpairmentEcls" DROP CONSTRAINT IF EXISTS "FK_DeckImpairmentEcls_Decks_DeckId";

ALTER TABLE "DeckImpairmentVariances" DROP CONSTRAINT IF EXISTS "FK_DeckImpairmentVariances_Decks_DeckId";

ALTER TABLE "DeckImpairmentDisclosures" DROP CONSTRAINT IF EXISTS "FK_DeckImpairmentDisclosures_Decks_DeckId";

ALTER TABLE "DeckPdCurveAnalysisCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckPdCurveAnalysisCalculations_Decks_DeckId";

ALTER TABLE "DeckLgdCurveAnalysisCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckLgdCurveAnalysisCalculations_Decks_DeckId";

ALTER TABLE "DeckRecoveryAnalysisCalculations" DROP CONSTRAINT IF EXISTS "FK_DeckRecoveryAnalysisCalculations_Decks_DeckId";

\echo '';
\echo 'Creating Install Backup Table...';
ALTER TABLE "Decks" RENAME TO "Decks-INSTALLTMP";

\echo '';
\echo 'Creating New Decks Table...';
CREATE TABLE "Decks" (
    "DeckId" uuid NOT NULL,
    "Name" varchar(100) NOT NULL,
    "Description" varchar(300) NOT NULL,
    "DeckTypeId" uuid NOT NULL,
    "ObjectiveTypeId" uuid NOT NULL,
    "ParentDeckId" uuid NULL,
    "Data" text,
    "ReportingDate" timestamp without time zone NOT NULL,
    "ExpiryDate" timestamp without time zone,
    "EntityId" uuid,
    "Currency" char(3),
    "IsPrivate" boolean NOT NULL,
    "Status" varchar(50) NOT NULL,
    "ConcurrencyId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

\echo 'Repopulating Data from Backup...';
INSERT INTO "Decks"
(
  "DeckId",
  "Name",
  "Description",
  "DeckTypeId",
  "ObjectiveTypeId",
  "ParentDeckId",
  "Data",
  "ReportingDate",
  "ExpiryDate",
  "EntityId",
  "Currency",
  "IsPrivate",
  "Status",
  "ConcurrencyId",
  "CreatedBy",
  "CreatedWhen",
  "LastModifiedBy",
  "LastModifiedWhen"
)
SELECT
  "DeckId",
  "Name",
  "Description",
  "DeckTypeId",
  "ObjectiveTypeId",
  NULL AS "ParentDeckId",
  "Data",
  "ReportingDate",
  "ExpiryDate",
  "EntityId",
  "Currency",
  "IsPrivate",
  "Status",
  "ConcurrencyId",
  "CreatedBy",
  "CreatedWhen",
  "LastModifiedBy",
  "LastModifiedWhen"
FROM "Decks-INSTALLTMP";

\echo '';
\echo 'Dropping Legacy Constraints/Indexes...';
ALTER TABLE "Decks-INSTALLTMP" DROP CONSTRAINT "PK_Decks";

\echo '';
\echo 'Recreating Constraints...';
ALTER TABLE ONLY "Decks"
    ADD CONSTRAINT "PK_Decks" PRIMARY KEY ("DeckId");

ALTER TABLE "Decks" OWNER TO "Elysian";

ALTER TABLE ONLY "DeckProps"
    ADD CONSTRAINT "FK_DeckProps_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckCalculations"
    ADD CONSTRAINT "FK_DeckCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckClassificationCalculations"
    ADD CONSTRAINT "FK_DeckClassificationCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckClassificationVariances"
    ADD CONSTRAINT "FK_DeckClassificationVariances_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckCfAnalysisCalculations"
    ADD CONSTRAINT "FK_DeckCfAnalysisCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckHistoricalLgdCalculations"
    ADD CONSTRAINT "FK_DeckHistoricalLgdCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckHistoricalPdCalculations"
    ADD CONSTRAINT "FK_DeckHistoricalPdCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckImpairmentEcls"
    ADD CONSTRAINT "FK_DeckImpairmentEcls_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckImpairmentVariances"
    ADD CONSTRAINT "FK_DeckImpairmentVariances_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckImpairmentDisclosures"
    ADD CONSTRAINT "FK_DeckImpairmentDisclosures_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckPdCurveAnalysisCalculations"
    ADD CONSTRAINT "FK_DeckPdCurveAnalysisCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckLgdCurveAnalysisCalculations"
    ADD CONSTRAINT "FK_DeckLgdCurveAnalysisCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

ALTER TABLE ONLY "DeckRecoveryAnalysisCalculations"
    ADD CONSTRAINT "FK_DeckRecoveryAnalysisCalculations_Decks_DeckId"
        FOREIGN KEY ("DeckId")
        REFERENCES "Decks"("DeckId") ON DELETE CASCADE;

\echo '';
\echo 'Dropping Work Table...';
DROP TABLE "Decks-INSTALLTMP";
