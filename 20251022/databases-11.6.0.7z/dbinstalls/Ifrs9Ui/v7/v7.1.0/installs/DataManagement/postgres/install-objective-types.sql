\echo ''
\echo 'Deleting data management deck objective type...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'DataManagement';

\echo ''
\echo 'Installing data management deck objective type...'

\copy "DeckObjectiveTypes" FROM '{data}/DataManagement/DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;