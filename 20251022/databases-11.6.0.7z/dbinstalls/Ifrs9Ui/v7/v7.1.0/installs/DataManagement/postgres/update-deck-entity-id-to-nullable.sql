\echo ''
\echo 'Update decks table to make EntityId nullable...'

ALTER TABLE "Decks" ALTER COLUMN "EntityId" DROP NOT NULL