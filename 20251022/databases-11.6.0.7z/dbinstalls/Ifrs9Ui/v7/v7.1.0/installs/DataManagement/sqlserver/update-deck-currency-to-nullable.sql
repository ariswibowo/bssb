PRINT N''
PRINT N'Update decks table to make Currency nullable...'
GO

ALTER TABLE [dbo].[Decks] ALTER COLUMN [Currency] nchar(3) NULL