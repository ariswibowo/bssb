\echo ''
\echo 'Update decks table to make Currency nullable...'

ALTER TABLE "Decks" ALTER COLUMN "Currency" DROP NOT NULL