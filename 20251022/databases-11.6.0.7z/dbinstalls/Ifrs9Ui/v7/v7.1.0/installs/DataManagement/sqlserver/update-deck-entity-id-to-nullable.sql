PRINT N''
PRINT N'Update decks table to make EntityId nullable...'
GO

ALTER TABLE [dbo].[Decks] ALTER COLUMN [EntityId] uniqueidentifier NULL