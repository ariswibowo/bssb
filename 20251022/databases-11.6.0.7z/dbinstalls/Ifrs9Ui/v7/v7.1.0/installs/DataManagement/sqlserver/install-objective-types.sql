PRINT N''
PRINT N'Deleting data management deck objective types...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'DataManagement';
GO

PRINT N''
PRINT N'Installing data management deck objective types...'
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/DataManagement/DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO