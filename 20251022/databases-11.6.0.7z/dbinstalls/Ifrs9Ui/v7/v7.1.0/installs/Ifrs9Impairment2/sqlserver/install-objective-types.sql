PRINT N''
PRINT N'Deleting Ifrs9 impairment2 deck objective types...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] = 'Ifrs9Impairment2';
GO

PRINT N''
PRINT N'Installing Ifrs9 impairment2 deck objective types...'
GO

BULK INSERT [dbo].[DeckObjectiveTypes]
FROM '{data}/Ifrs9Impairment2/DeckObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO