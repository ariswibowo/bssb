PRINT N''
PRINT N'Deleting existing impairment configuration source level, comparison type and overlay type codes...'
GO

DELETE
 FROM [dbo].[UiCodes]
 WHERE [Type] IN ('ImpairmentSourceLevel','ImpairmentConfigurationSourceLevel','ImpairmentComparisonType','ImpairmentComparisonTypes','ImpairmentOverlayTypes')
 AND [Category] = 'Deck'
GO

PRINT N''
PRINT N'Installing new impairment configuration source level, comparison type and overlay type codes...'
GO

BULK INSERT [dbo].[UiCodes]
FROM '{data}/Ifrs9Impairment2/UiCodes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO