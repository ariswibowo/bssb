\echo ''
\echo 'Deleting Ifrs9 impairment2 deck objective types...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" = 'Ifrs9Impairment2';

\echo ''
\echo 'Installing Ifrs9 impairment2 deck objective types...'

\copy "DeckObjectiveTypes" FROM '{data}/Ifrs9Impairment2/DeckObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;