\echo ''
\echo 'Deleting existing impairment configuration source level, comparison type and overlay type codes...'

DELETE
FROM "UiCodes"
WHERE "Type" IN ('ImpairmentSourceLevel','ImpairmentConfigurationSourceLevel','ImpairmentComparisonType','ImpairmentComparisonTypes','ImpairmentOverlayTypes')
AND "Category" = 'Deck';

\echo ''
\echo 'Installing new impairment configuration source level, comparison type  and overlay type codes...'

\copy "UiCodes" FROM '{data}/Ifrs9Impairment2/UiCodes.dat' DELIMITER E'\t' CSV QUOTE '#' HEADER;