import dbpolicies

def main(config):
    # Add Impairment2 to contract details policy
    dbpolicies.updatePolicy(table="DeckPolicies",
                            type="ContractDetails",
                            config=config,
                            updatefunc=updateContractDetailsPolicy)
    return


def updateContractDetailsPolicy(policy, context):
    # loop through config
    for config in policy["config"]:
        # Add impairment2 to where impairment is
        if "Ifrs9Impairment" in config["context"]:
            config["context"] = list(
                filter(lambda a: a not in ["Ifrs9Impairment2"], config["context"]))
            config["context"].append("Ifrs9Impairment2")
            config["context"] = sorted(config["context"])

    return policy