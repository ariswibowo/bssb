# README

**Release: Ifrs9Ui V7.1.0**

## Release Features & Fixes

- [Feature: Capital Ratio](#feature-capital-ratio)
- [Feature: Data Field Types](#feature-data-field-types)
- [Feature: Deck Validation](#feature-deck-validation)
- [Feature: Ifrs9 Impairment2](#feature-ifrs9-impairment2)
- [Feature: Deck Validation](#feature-deck-validation)
- [Feature: Liquidity](#feature-liquidity)
- [Feature: Portfolio Stress](#feature-portfolio-stress)
- [Feature: Data Management](#feature-data-management)
- [Feature: Sandboxes](#feature-sandboxes)
- [Feature: Workflows](#feature-workflows)
- [Feature: Workspaces](#feature-workspaces)
- [Feature: Deck Initialization](#feature-deck-initialization)

## Feature: Capital Ratio

Introduce a new deck, CapitalRatio

The following database updates are required to support this deck:

- Deck Objective type: To install CapitalRatio deck objective type

[top](#readme)

## Feature: Data Field Types

Adds DataFieldTypes codes to support Capital Data, Market Risk Data and Operational Risk Data policy

[top](#readme)

## Feature: Deck Validation

This feature contains database update on deck validation rules policy to enable deck green heart validation on the following decks:

- CapitalRatio
- Ifrs9Impairment2
- ManagementJudgement

[top](#readme)

## Feature: Ifrs9 Impairment2

Introduce a new deck, Ifrs9Impairment2

The following database updates are required to support this deck:

- New Deck Objective type Ifrs9Impairment2
- Adjust Contract Details Policy to configure which contract template Ifrs9Impairment2 uses
- New Impairment UI Codes:
  1.  ImpairmentConfigurationSourceLevel - to support multi-level model and deck configuration
  2.  ImpairmentComparisonTypes - stores supported comparison type for Impairment results
  3.  ImpairmentOVerlayTypes - supported overlay types

[top](#readme)

## Feature: Deck Validation

This feature contains database update on deck validation rules policy to enable deck green heart validation on the following decks:

- CapitalRatio
- Ifrs9Impairment2
- ManagementJudgement
- Nsfr
- Lcr

[top](#readme)

## Feature: Liquidity

Introduces the new Liquidity calculation.

- Installs Liquidity deck objective type
- Installs Liquidity deck codes

[top](#readme)

## Feature: Portfolio Stress

Add codes to support stress-test to be configured in the deck.

Codes:

- StressDataset: apply portfolio stess by using specified Stess Dataset
- DataUpload: apply portfolio stress by uploaded the stress data

[top](#readme)

## Feature: Data Management

Introduce a new Data-Management deck type for the purposes of monitoring system data-feeds.

Database updates:

- Installs new Deck Objective type: Data-Management
- Updates Decks table to make Entity Id and Currency nullable

[top](#readme)

## Feature: Sandboxes

Introduce a new Sandbox deck type for the purposes of allowing users to create isolated sandboxes containing decks, modes, stress-data related to the sandbox needs.

Database updates:

- Installs new Deck Objective type: Sandbox
- Adds new "ParentDeckId" column to the deck table to support parent-child structures

[top](#readme)

## Feature: Workflows

Introduce a new Workflows deck type for the purposes of managing business reporting cycles through a configured workflow

Database updates:

- Installs new Deck Objective type: Workflow

[top](#readme)

## Feature: Workspaces

Introduce a new Workspace deck type for the purposes of allowing users to create workspaces containing decks, models to be able to group together system items

Database updates:

- Installs new Deck Objective type: Workspace

[top](#readme)

## Feature: Deck Initialization

Add deck initialization process in each deck

Database updates:

- Update legacy deck status from "Initiated" to "Open" to standardize deck status

[top](#readme)
