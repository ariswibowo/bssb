PRINT N'';
PRINT N'Updating ReportLibrary {reportLibrary}';
GO

UPDATE [dbo].[ReportLibrary]
SET [DefaultReports] = '{defaultReports}',
    [ActiveReports] = '{activeReports}'
WHERE [ReportLibraryId] = '{reportLibraryId}';
