SELECT [ReportLibraryId], [ReportLibrary], [DefaultReports], [ActiveReports]
FROM [dbo].[ReportLibrary]