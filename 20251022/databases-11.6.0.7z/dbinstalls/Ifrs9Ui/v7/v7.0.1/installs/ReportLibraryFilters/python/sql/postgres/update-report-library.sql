\echo ''
\echo 'Updating ReportLibrary {reportLibrary}'

UPDATE "ReportLibrary"
SET "DefaultReports" = '{defaultReports}',
    "ActiveReports" = '{activeReports}'
WHERE "ReportLibraryId" = '{reportLibraryId}';
