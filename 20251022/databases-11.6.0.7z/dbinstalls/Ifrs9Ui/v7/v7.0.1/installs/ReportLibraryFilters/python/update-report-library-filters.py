import json

import dbhelper


def main(config):

    # get report library
    reportLibraries = getReportLibraries(config)
    
    # flush all report filters and update all reports libraries value in database
    fixReportsLibraries(config, reportLibraries)

    return


def getReportLibraries(config):
    # get reportLibrary query
    sql = dbhelper.get_sql("get-report-library", config)

    # get reportLibrary items
    data = dbhelper.run_sql(sql, config)
    localItemsList = data.fetchall()

    # get col names list
    cols = [column[0] for column in data.description]

    # convert list to a dictionary
    localItems = []
    for item in localItemsList:
        itemDict = dbhelper.get_row_dict(item, cols)
        localItems.append(itemDict)

    dbhelper.dispose(data, config)

    return localItems


def fixReportsLibraries(config,reportLibraries):
    # replace in each reportLibrary
    for reportLibrary in reportLibraries:
        # flush reports filters in DefaultReports and ActiveReports
        defaultReports = flushReportsFilters(reportLibrary["DefaultReports"])
        activeReports = flushReportsFilters(reportLibrary["ActiveReports"])

        # update ReportLibrary
        updateReportLibrary(config=config, reportLibrary=reportLibrary, defaultReports=defaultReports, activeReports=activeReports)


def flushReportsFilters(reportsConfiguration):
    if reportsConfiguration is None:
        return reportsConfiguration

    # parse report text type to object
    parsedReportsConfiguration = json.loads(reportsConfiguration)

    # only flush if the reports existed in reports Configuration
    if "reports" in parsedReportsConfiguration:
        # replace filters in each report
        for reportConfiguration in parsedReportsConfiguration["reports"]:
            for rowField in reportConfiguration["configuration"]["rowFields"]:
                if "filters" in rowField :
                    rowField["filters"] = []

            for columnField in reportConfiguration["configuration"]["columnFields"]:
                if "filters" in columnField :
                    columnField["filters"] = []

            for dimensionValue in reportConfiguration["configuration"]["dimensionValues"]:
                if "filters" in dimensionValue :
                    dimensionValue["filters"] = []

            for reportFilter in reportConfiguration["configuration"]["reportFilters"]:
                if "filters" in reportFilter :
                    reportFilter["filters"] = []
        
        # replace filter in each availableFields
        for availableField in parsedReportsConfiguration.get("availableFields",[]):
            if "filters" in availableField :
                availableField["filters"] = []

    newReportsConfiguration = json.dumps(parsedReportsConfiguration, separators=(',', ':'))
    return newReportsConfiguration


def updateReportLibrary(config, reportLibrary, defaultReports, activeReports):
    # init build script file
    build = dbhelper.init_build("update-report-library-filters", config, "Ifrs9Ui")

    # get update statement
    update_sql = dbhelper.get_sql("update-report-library", config)
    
    # construct update statement
    sql = update_sql.format(
        reportLibraryId = reportLibrary["ReportLibraryId"],
        reportLibrary = reportLibrary["ReportLibrary"],
        defaultReports = defaultReports,
        activeReports = activeReports
    )
    
    # write to build file
    dbhelper.write_build(build, sql)

    # run build to add items on remote
    dbhelper.run_build(build, config)

