import dbpolicies

def main(config):
    dbpolicies.updatePolicy(table="DeckPolicies",
                            type="HistoricalLgdContent",
                            config=config,
                            updatefunc=updatePolicy)
    return


def updatePolicy(policy, context):
    # workout content
    updateDateFormat(policy, "workoutContent", "historicalObservations")
    updateDateFormat(policy, "workoutContent", "historicalRecoveries")

    # chain ladder content
    updateDateFormat(policy, "chainLadderContent", "historicalObservations")
    updateDateFormat(policy, "chainLadderContent", "historicalRecoveries")

    # vintage content
    updateDateFormat(policy, "vintageContent", "historicalObservations")
    updateDateFormat(policy, "vintageContent", "historicalRecoveries")
    
    # collateralized chain ladder content
    updateDateFormat(policy, "collateralizedChainLadderContent", "historicalObservations")
    updateDateFormat(policy, "collateralizedChainLadderContent", "historicalRecoveries")

    return policy


def updateDateFormat(policy, content, contentItem):
    # loop through adjusting all columns
    for column in policy[content][contentItem]["columns"]:
        # Update letter case for a "value" property to be Camel case
        column["value"] = column["value"][0].lower() + column["value"][1:]
        
        # Update the format for a "Date" type item
        if column["type"] == "Date":
            column["format"] = "d-LLL-yyyy"