# README

**Release: Ifrs9Ui V7.0.1**

## Release Fixes

- [Fix: Report Library Filters](#hotfix-report-library-filters)
- [Fix: Historical Lgd Content Policy](#hotfix-historical-lgd-content-policy)

## Hotfix: Report Library Filters

Report library filters erroneously contained the negative/exclude side of the filter; this caused report issues when the values changed.

The issue has been resolved in eStudio to store the actual filters; this also requires the database filters to be "reset" to avoid confusion; the filters will need to be reconfigured by the user to the required values. This is not ideal but is better reporting on the flipside which may leave to more confusion.

[top](#readme)

## Hotfix: Historical Lgd Content Policy

Update the format for a "Date" type item to new default format codes
Update letter case for a "value" property to be Camel case

[top](#readme)
