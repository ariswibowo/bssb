import dbpolicies

def main(config):
    # Remove Impairment2
    dbpolicies.updatePolicy(table="DeckPolicies",
                            type="ContractDetails",
                            config=config,
                            updatefunc=updateContractDetailsPolicy)
    return


def updateContractDetailsPolicy(policy, context):
    # loop through config
    for config in policy["config"]:
        # Remove impairment2
        if "Ifrs9Impairment2" in config["context"]:
            config["context"] = list(
                filter(lambda a: a not in ["Ifrs9Impairment2"], config["context"]))
            config["context"] = sorted(config["context"])

    return policy