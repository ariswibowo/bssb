PRINT N''
PRINT N'Removing existing Deck validation rules policy...'
GO

DELETE 
  FROM [dbo].[DeckPolicies] 
  WHERE [PolicyType] = 'DeckValidationRules'
GO

PRINT N''
PRINT N'Adding new Deck validation rules policy...'
GO

BULK INSERT [dbo].[DeckPolicies]
FROM '{data}/DeckValidationRulesPolicy.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO