PRINT N''
PRINT N'Removing deck objective types that are not released...'
GO

DELETE 
  FROM [dbo].[DeckObjectiveTypes]
 WHERE [Code] IN (
   'Ifrs9Impairment2',
   'ManagementJudgement',
   'CapitalRatio'
);
GO