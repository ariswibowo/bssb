\echo ''
\echo 'Removing deck objective types that are not released...'

DELETE 
  FROM "DeckObjectiveTypes"
 WHERE "Code" IN (
   'Ifrs9Impairment2',
   'ManagementJudgement',
   'CapitalRatio'
);