\echo ''
\echo 'Updating deck data for DeckId: {deckId}...'

UPDATE "Decks"
   SET "Data" = '{data}'
 WHERE "DeckId" = '{deckId}';