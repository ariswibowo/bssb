import os
import json

import dbhelper


def main(config):

    # get migration settings info
    model_domain = getModelDomain()

    # get decks
    decks = getLocalItems(
        config, model_domain["tables"]["decks"])
    # get objective types
    objective_types = getLocalItems(
        config, model_domain["tables"]["objectiveTypes"])

    # do nothing if no decks to migrate
    if len(decks) == 0:
        return

    # convert decks
    converted_decks = convertDecks(decks, objective_types, model_domain["decks"])

    # update deck data
    updateDecks(converted_decks, config)


def convertDecks(decks, objective_types, domain_decks):
    converted_decks = []

    # loop through decks
    for deck in decks:

        # touch only when data present
        if deck['Data'] is not None and 'versions' in deck['Data']:
            # fetch objective type
            objective_type = next(
                filter(lambda o: o["ObjectiveTypeId"] == deck["ObjectiveTypeId"], objective_types), None)

            if objective_type is None:
                continue

            # lookup deck objective type to migrate
            domain_deck = next(
                filter(lambda r: r["deckObjectiveType"] == objective_type["Code"], domain_decks), None)
            
            if domain_deck is not None:
                for version_id_prop in domain_deck["versionIdProps"]:
                    old_prop_name = version_id_prop["oldPropName"]
                    new_prop_name = version_id_prop["newPropName"]

                    if old_prop_name in deck['Data']['versions']:
                        # get version Id
                        version_id = deck['Data']['versions'][old_prop_name]
                        # delete old version Id prop
                        del deck['Data']['versions'][old_prop_name]
                        # add new version Id prop
                        deck['Data']['versions'][new_prop_name] = version_id
                        converted_decks.append(deck)

    return converted_decks


def updateDecks(decks, config):

    # generate build script file
    build = dbhelper.init_build("migrate-deck-data", config)

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-deck", config)

    for deck in decks:
        # construct update statement
        sql = update_sql.format(
            data=json.dumps(deck['Data'],
            separators=(',', ':')),
            deckId=deck['DeckId']
        )

        # write to build file
        dbhelper.write_build(build, sql)

    # run build
    dbhelper.run_build(build, config)


def getLocalItems(config, table):
    # get local query
    sql = dbhelper.get_sql("get-local-items", config)
    sql = sql.format(table=table)

    # get local items
    data = dbhelper.run_sql(sql, config)
    localItemsList = data.fetchall()

    # get col names list
    cols = [column[0] for column in data.description]

    # convert list to a dictionary
    localItems = []
    for item in localItemsList:
        itemDict = dbhelper.get_row_dict(item, cols)
        localItems.append(itemDict)

    dbhelper.dispose(data, config)

    return localItems


def getModelDomain():
    """ returns model domain dict"""

    # expected in current directory
    dmFile = os.path.join(os.path.dirname(
        os.path.realpath(__file__)), "modelDomain.json")

    # check file exists
    if not os.path.exists(dmFile):
        print("")
        print("Fatal: Model Domain file not found!")
        print("File: {file}".format(file=dmFile))
        exit(-1)

    # load domain
    with open(dmFile) as d:
        modelDomain = json.load(d)

    return modelDomain