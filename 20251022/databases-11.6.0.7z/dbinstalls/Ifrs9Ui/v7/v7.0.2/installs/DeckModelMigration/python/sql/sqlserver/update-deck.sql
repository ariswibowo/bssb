PRINT N''
PRINT N'Updating stage version id prop name for DeckId: {deckId}...'
GO

UPDATE [dbo].[Decks]
   SET [Data] = '{data}'
 WHERE [DeckId] = '{deckId}';
GO