# README

**Release: Ifrs9Ui V7.0.2**

## Release Fixes

- [Hotfix: Unreleased Objective Types](#hotfix-unreleased-objective-types)
- [HotFix: Deck Model Migration](#hotfix-deck-model-migration)

## Hotfix: Unreleased Objective Types

- Remove deck objective types of "Ifrs9Impairment2", "ManagementJudgement", and "CapitalRatio" which are still in WIP phase to prevent users from reaching them.
- Update deck validation rules policy and contract details policy to remove references to those deck objective types.

[top](#readme)

## HotFix: Deck Model Migration

- Fix the issue of model migration not applied due to refering to wrong deck objective type code "Ifrs9ImpairmentD" by correcting it to "Ifrs9Impairment".

[top](#readme)