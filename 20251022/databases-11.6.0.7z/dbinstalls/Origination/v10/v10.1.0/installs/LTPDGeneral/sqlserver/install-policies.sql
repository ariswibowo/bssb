PRINT N''
PRINT N'Removing existing General policy...'
GO

DELETE
  FROM [dbo].[Policies]
 WHERE [PolicyType] = 'General';
GO

PRINT N''
PRINT N'Adding new General policy...'
GO

BULK INSERT [dbo].[Policies]
FROM '{data}/LTPDGeneral/Policies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO