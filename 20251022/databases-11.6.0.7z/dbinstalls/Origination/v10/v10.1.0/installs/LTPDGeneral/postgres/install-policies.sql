\echo ''
\echo 'Removing existing General policy...';

DELETE
  FROM "Policies"
 WHERE "PolicyType" = 'General';

\echo ''
\echo 'Adding new General policy...';

\copy "Policies" FROM '{data}/LTPDGeneral/Policies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;