PRINT N''
PRINT N'Removing existing Fixation policy...'
GO

DELETE
  FROM [dbo].[Policies]
 WHERE [PolicyType] = 'Fixation';
GO

PRINT N''
PRINT N'Adding new Fixation policy...'
GO

BULK INSERT [dbo].[Policies]
FROM '{data}/LTPDFixation/Policies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO