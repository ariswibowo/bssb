PRINT N''
PRINT N'Creating CalculationOptions policy install backups...';
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP' )
  BEGIN
    CREATE TABLE [dbo].[CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP] (
        [PolicyId] uniqueidentifier NOT NULL,
        [ObjectiveTypeId] uniqueidentifier NULL,
        [PolicyType] nvarchar(50) NOT NULL,
        [Description] nvarchar(300) NOT NULL,
        [DefaultPolicy] nvarchar(max),
        [ActivePolicy] nvarchar(max),
        [CreatedBy] uniqueidentifier NOT NULL,
        [CreatedWhen] datetime NOT NULL,
        [LastModifiedBy] uniqueidentifier NOT NULL,
        [LastModifiedWhen] datetime NOT NULL
    );
    INSERT INTO [dbo].[CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP]
    (
        [PolicyId],
        [ObjectiveTypeId],
        [PolicyType],
        [Description],
        [DefaultPolicy],
        [ActivePolicy],
        [CreatedBy],
        [CreatedWhen],
        [LastModifiedBy],
        [LastModifiedWhen]
    )
    SELECT
        [PolicyId],
        [ObjectiveTypeId],
        [PolicyType],
        [Description],
        [DefaultPolicy],
        [ActivePolicy],
        [CreatedBy],
        [CreatedWhen],
        [LastModifiedBy],
        [LastModifiedWhen]
    FROM [dbo].[Policies]
    WHERE [PolicyType] = 'CalculationOptions';
  END
ELSE
  BEGIN
    PRINT N'';
    PRINT N'CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP table already exists; no action taken.';
  END
GO