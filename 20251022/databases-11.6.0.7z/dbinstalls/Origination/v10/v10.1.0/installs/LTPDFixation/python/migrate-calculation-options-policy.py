"""
    Update the CalculationOptions policy to have rule props configuration for the Fixation behaviors and rules.
"""

import dbpolicies


def main(config):
    dbpolicies.updatePolicy(table="Policies",
                            type="CalculationOptions",
                            config=config,
                            updatefunc=updatePolicy)
    return


def updatePolicy(policy, _):
    if "behavioralScoring" in policy["calculationOptions"]:
        del policy["calculationOptions"]["behavioralScoring"]

    if "fixation" not in policy["calculationOptions"]:
        policy["calculationOptions"]["fixation"] = {
            "behaviors": {
                "ruleProps": [
                    {
                        "name": "PoolCodeRating",
                        "label": "Pool Code Rating",
                        "type": "string",
                        "length": "20"
                    }
                ]
            },
            "rules": {
                "ruleProps": [
                    {
                        "name": "Ifrs9PdModel",
                        "label": "IFRS9 PD Model",
                        "type": "string",
                        "length": "20"
                    }
                ]
            }
        }
    
    return policy