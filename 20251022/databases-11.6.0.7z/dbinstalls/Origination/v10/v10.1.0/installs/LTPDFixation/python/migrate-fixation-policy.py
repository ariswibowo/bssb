"""
    Migrates the behavioral scoring config from the CalculationOptions policy into the Fixation policy.
"""

import dbpolicies
from benedict import benedict
import dbhelper
import uuid


def main(config):
    calculationOptionsPolicy = dbpolicies.get_policy(table="CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP", type="CalculationOptions", config=config)
    
    migratePolicy(calculationOptionsPolicy, config)

    return


def migratePolicy(calculationOptionsPolicy, config):
    defaultPolicy = benedict(calculationOptionsPolicy["defaultPolicy"])

    activePolicy = calculationOptionsPolicy["activePolicy"]
    if activePolicy != {} and activePolicy is not None:
        activePolicy = benedict(activePolicy)

    # touch only when behavioralScoring exists
    if "behavioralScoring" not in defaultPolicy["calculationOptions"]:
        return

    # default policy
    defaultFixation = {}
    if "ifrs9PdModels" in defaultPolicy["calculationOptions"]["behavioralScoring"] and \
        isinstance(defaultPolicy["calculationOptions"]["behavioralScoring"]["ifrs9PdModels"], list) and \
        len(defaultPolicy["calculationOptions"]["behavioralScoring"]["ifrs9PdModels"]) > 0:
        defaultFixation = buildFixationPolicy(defaultPolicy["calculationOptions"]["behavioralScoring"]["ifrs9PdModels"])

    # active policy
    activeFixation = {}
    if activePolicy != {} and activePolicy is not None:
        activePolicy = benedict(activePolicy)
        if "ifrs9PdModels" in activePolicy["calculationOptions"]["behavioralScoring"] and \
            isinstance(activePolicy["calculationOptions"]["behavioralScoring"]["ifrs9PdModels"], list) and \
            len(activePolicy["calculationOptions"]["behavioralScoring"]["ifrs9PdModels"]) > 0:
            activeFixation = buildFixationPolicy(activePolicy["calculationOptions"]["behavioralScoring"]["ifrs9PdModels"])

    # update policy
    updatePolicy(dbhelper.jsonToStr(defaultFixation), dbhelper.jsonToStr(activeFixation), config)


def buildFixationPolicy(ifrs9PdModels):
    behaviors = []
    rules = []
    # loop through ifrs9PdModels
    for ifrs9PdModel in ifrs9PdModels:
        models = ifrs9PdModel["models"]
        timeUnit = ifrs9PdModel["configuration"]["evaluationWindow"]["timeUnit"]
        timeUnitMultiplicity = ifrs9PdModel["configuration"]["evaluationWindow"]["timeUnitMultiplicity"]

        # create behavior
        behaviorId = str(uuid.uuid4())
        behaviorName = str(timeUnitMultiplicity) + ' ' + getTimeUnitName(timeUnit)
        behavior = {
            "behaviorId": behaviorId,
            "name": behaviorName,
            "description": behaviorName,
            "evaluationType": "TimeBased",
            "configuration": {
                "evaluationWindow": {
                    "timeUnit": timeUnit,
                    "timeUnitMultiplicity": timeUnitMultiplicity
                }
            }
        }
        behaviors.append(behavior)

        # create rule
        rule = {
            "ruleId": str(uuid.uuid4()),
            "name": ' '.join(models),
            "description": 'IFRS9 PD Model is one of [' + ','.join(models) + ']',
            "behaviorId": behaviorId,
            "behaviorName": behaviorName,
            "configuration": {
                "ruleCondition": {
                    "combinator": "And",
                    "conditionId": str(uuid.uuid4()),
                    "conditions": [
                        {
                            "field": "Ifrs9PdModel",
                            "operator": "In",
                            "values": models,
                            "conditionId": str(uuid.uuid4())
                        }
                    ]
                }
            }
        }
        rules.append(rule)

    # create fixation
    fixation = {
        "behaviors": behaviors,
        "rules": rules
    }

    return fixation


def getTimeUnitName(timeUnit):
    if timeUnit == "M": return "Months"
    elif timeUnit == "Q": return "Quarters"
    elif timeUnit == "Y": return "Years"
    else: return timeUnit


def updatePolicy(default, active, config):
    build = dbhelper.init_build("update-policy", config)

    insertSql = dbhelper.get_sql("update-policy", config)

    sql = insertSql.format(
        policyType = "Fixation",
        defaultPolicy = default,
        activePolicy = active
    )

    dbhelper.write_build(build, sql)
    
    dbhelper.run_build(build, config)