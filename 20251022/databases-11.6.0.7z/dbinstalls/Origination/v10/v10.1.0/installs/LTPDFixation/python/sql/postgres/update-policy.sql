UPDATE "Policies"
SET "DefaultPolicy" = '{defaultPolicy}', "ActivePolicy" = '{activePolicy}'
WHERE "PolicyType" = '{policyType}';