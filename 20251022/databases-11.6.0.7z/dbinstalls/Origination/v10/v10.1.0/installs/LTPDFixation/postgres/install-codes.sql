\echo ''
\echo 'Installing codes...'

DELETE
  FROM "Codes"
 WHERE "Category" = 'Options'
 AND "Type" = 'FixationEvaluationTypes';

\copy "Codes" FROM '{data}/LTPDFixation/Codes.dat' DELIMITER E'\t' CSV QUOTE '#' HEADER;