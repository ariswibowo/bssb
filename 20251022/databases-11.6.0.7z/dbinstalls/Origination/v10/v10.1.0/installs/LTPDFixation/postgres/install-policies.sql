\echo ''
\echo 'Removing existing Fixation policy...';

DELETE
  FROM "Policies"
 WHERE "PolicyType" = 'Fixation';

\echo ''
\echo 'Adding new Fixation policy...';

\copy "Policies" FROM '{data}/LTPDFixation/Policies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;