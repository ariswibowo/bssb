\echo '';
\echo 'Creating CalculationOptions policy install backups...';

DO $$
BEGIN
  IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP') THEN
    CREATE TABLE "CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP" (
      "PolicyId" uuid NOT NULL,
      "ObjectiveTypeId" uuid NULL,
      "PolicyType" varchar(50) NOT NULL,
      "Description" varchar(300) NOT NULL,
      "DefaultPolicy" text NOT NULL,
      "ActivePolicy" text NOT NULL,
      "CreatedBy" uuid NOT NULL,
      "CreatedWhen" timestamp without time zone NOT NULL,
      "LastModifiedBy" uuid NOT NULL,
      "LastModifiedWhen" timestamp without time zone NOT NULL
    );
    ALTER TABLE "CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP" OWNER TO "Elysian";

    INSERT INTO "CalculationOptionsPolicy-V10.1.0-INSTALL-BACKUP"
    (
      "PolicyId",
      "ObjectiveTypeId",
      "PolicyType",
      "Description",
      "DefaultPolicy",
      "ActivePolicy",
      "CreatedBy",
      "CreatedWhen",
      "LastModifiedBy",
      "LastModifiedWhen"
    )
    SELECT
      "PolicyId",
      "ObjectiveTypeId",
      "PolicyType",
      "Description",
      "DefaultPolicy",
      "ActivePolicy",
      "CreatedBy",
      "CreatedWhen",
      "LastModifiedBy",
      "LastModifiedWhen"
    FROM "Policies"
    WHERE "PolicyType" = 'CalculationOptions';
  END IF;
END $$;