PRINT N''
PRINT N'Installing codes...'
GO

DELETE
  FROM [dbo].[Codes]
 WHERE [Category] = 'Options'
 AND [Type] = 'FixationEvaluationTypes';
GO

BULK INSERT [dbo].[Codes]
FROM '{data}/LTPDFixation/Codes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO