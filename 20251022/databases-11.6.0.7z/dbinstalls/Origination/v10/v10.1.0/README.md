# README

**Release: Origination V10.1.0**

## Release Features

- [Feature: LTPD Fixation](#feature-ltpd-fixation)
- [Feature: LTPD General](#feature-ltpd-general)

## Feature: LTPD Fixation

Adds the new codes for the fixation evaluation types.
Adds the new policy called "Fixation".
Migrates the behavioral scoring config from the CalculationOptions policy into the Fixation policy.
Update the CalculationOptions policy to have rule props configuration for the Fixation behaviors and rules.

[top](#readme)

## Feature: LTPD General

Adds the new policy called "General".

[top](#readme)