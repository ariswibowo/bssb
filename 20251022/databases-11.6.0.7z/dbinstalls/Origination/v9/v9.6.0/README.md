# README

**Release: Origination V9.6.0**

## Release Features

- [Feature: Lifetime Pd](#feature-lifetime-pd)

## Feature: Lifetime Pd

Initializes the database and installs the initial set of tables to facilitate Lifetime PD calculations:

| Table                   | Description                                                                                              |
| ----------------------- | -------------------------------------------------------------------------------------------------------- |
| ApplicationLogs         | The general logs produced by the application.                                                            |
| CalculationEvents       | The events generated during a calculation.                                                               |
| CalculationLogs         | The logs produced during a calculation.                                                                  |
| CalculationMetrics      | The metrics that are kept during a calculation.                                                          |
| CalculationProps        | The properties table that attached information to a calculation.                                         |
| Calculations            | The base calculation table with meta data about a calculation.                                           |
| Codes                   | The code definitions used to display static information.                                                 |
| DbVersions              | The installed database versions.                                                                         |
| ObjectiveTypes          | The reference table with origination objective types.                                                    |
| Policies                | The origination policies.                                                                                |
| ResultLifetimePd        | The product level Lifetime PD results table.                                                             |
| ResultLifetimePdIndex   | The contract level Lifetime PD results table, holding the relationships between contracts into products. |
| ResultSegmentLifetimePd | The aggregated Lifetime PD results table.                                                                |
| Jobs                    | The base job table with meta data about a job.                                                           |
| JobLogs                 | The logs produced during a job.                                                                          |

[top](#readme)
