\echo '';
\echo 'Installing Jobs table...';

CREATE TABLE "Jobs" (
    "JobId" uuid NOT NULL,
    "Status" varchar(50) NOT NULL,
    "ReportingDate" timestamp without time zone NOT NULL,
    "Entity" varchar(50) NOT NULL,
    "Data" text,
    "StartTimestamp" timestamp without time zone,
    "EndTimestamp" timestamp without time zone,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "Jobs"
    ADD CONSTRAINT "PK_Jobs" PRIMARY KEY ("JobId");

ALTER TABLE "Jobs" OWNER TO "Elysian";