PRINT N'';
PRINT N'Installing DbVersions table...';
GO

CREATE TABLE [dbo].[DbVersions] (
    [DbVersionId] uniqueidentifier NOT NULL,
    [DbVersion] nvarchar(50) NOT NULL,
    [IsInstalledVersion] bit NOT NULL,
    [ReleaseName] nvarchar(100) NOT NULL,
    [ReleaseDescription] nvarchar(300) NOT NULL,
    [InstallAttempt] integer NOT NULL,
    [InstallStatus] nvarchar(50) NOT NULL,
    [InstallStarted] datetime  NOT NULL,
    [InstallEnded] datetime NOT NULL,
    [InstallComments] nvarchar(300) NOT NULL,
    [InstalledBy] nvarchar(100) NOT NULL
);
GO

ALTER TABLE [dbo].[DbVersions] ADD CONSTRAINT [PK_DbVersions] PRIMARY KEY ([DbVersionId]);
GO