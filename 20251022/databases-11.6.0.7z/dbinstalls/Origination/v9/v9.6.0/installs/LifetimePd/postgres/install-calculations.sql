\echo '';
\echo 'Installing Calculations table...';

CREATE TABLE "Calculations" (
    "CalculationId" uuid NOT NULL,
    "Entity" varchar(50) NOT NULL,
    "ReportingDate" timestamp without time zone NOT NULL,
    "Priority" integer NOT NULL,
    "IsCombined" boolean NOT NULL,
    "Status" varchar(50) NOT NULL,
    "Type" varchar(100) NOT NULL,
    "MessagesExpected" integer NOT NULL,
    "MessagesLoaded" integer NOT NULL,
    "MessagesProcessed" integer NOT NULL,
    "MessagesRejected" integer NOT NULL,
    "Data" text,
    "Checks" text,
    "Analytics" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "Calculations" ADD CONSTRAINT "PK_Calculations" PRIMARY KEY ("CalculationId");

ALTER TABLE "Calculations" OWNER TO "Elysian";