PRINT N'';
PRINT N'Installing ResultLifetimePdIndex table...';
GO

CREATE TABLE [dbo].[ResultLifetimePdIndex] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [ItemId] uniqueidentifier NOT NULL,
    [ItemClass] nvarchar(50) NOT NULL,
    [ResultId] uniqueidentifier NOT NULL,
    [SearchText] nvarchar(max) NULL,
    [RetentionCopied]  bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultLifetimePdIndex] ADD CONSTRAINT [PK_ResultLifetimePdIndex] PRIMARY KEY ([Id]);

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultLifetimePdIndex_ItemId_ResultId] ON [dbo].[ResultLifetimePdIndex]([ItemId], [ResultId]);
GO