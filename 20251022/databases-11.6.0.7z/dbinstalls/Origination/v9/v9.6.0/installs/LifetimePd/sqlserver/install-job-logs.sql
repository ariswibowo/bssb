PRINT N'';
PRINT N'Installing JobLogs table...';
GO

CREATE TABLE [dbo].[JobLogs] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [LogId] uniqueidentifier NOT NULL,
    [JobId] uniqueidentifier NOT NULL,
    [Timestamp] datetime NOT NULL,
    [Message] nvarchar(max) NOT NULL,
    [Level] nvarchar(50) NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Data] nvarchar(max) NULL
);
GO

ALTER TABLE [dbo].[JobLogs] ADD CONSTRAINT [PK_JobLogs] PRIMARY KEY ([Id]);
GO

ALTER TABLE [dbo].[JobLogs]
    ADD CONSTRAINT [FK_JobLogs_Jobs_JobId]
        FOREIGN KEY ([JobId])
        REFERENCES [dbo].[Jobs]([JobId]) ON DELETE CASCADE;
GO

CREATE UNIQUE INDEX [IX_JobLogs_LogId] ON [dbo].[JobLogs]([LogId]);
GO

CREATE INDEX [IX_JobLogs_JobId] ON [dbo].[JobLogs]([JobId]);
GO

