PRINT N'';
PRINT N'Installing ObjectiveTypes table...';
GO

CREATE TABLE [dbo].[ObjectiveTypes] (
    [ObjectiveTypeId] uniqueidentifier NOT NULL,
    [Name] nvarchar(100) NOT NULL,
    [Description] nvarchar(300) NOT NULL,
    [Code] nvarchar(50) NOT NULL,
    [IsEnabled] bit NOT NULL,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
);
GO

ALTER TABLE [dbo].[ObjectiveTypes] ADD CONSTRAINT [PK_ObjectiveTypes] PRIMARY KEY ([ObjectiveTypeId]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ObjectiveTypes] ON [dbo].[ObjectiveTypes]([Code]);
GO

BULK INSERT [dbo].[ObjectiveTypes]
FROM '{data}/LifetimePd/ObjectiveTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO