\echo '';
\echo 'Installing CalculationProps table...';

\echo '';
\echo 'Creating sequence CalculationProps_Id_seq...';

CREATE SEQUENCE "CalculationProps_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "CalculationProps_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table CalculationProps...';

CREATE TABLE "CalculationProps" (
    "Id" bigint DEFAULT nextval('"CalculationProps_Id_seq"'::regclass) NOT NULL,
    "CalculationPropId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Key" varchar(100) NOT NULL,
    "Value" text NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "CalculationProps" ADD CONSTRAINT "PK_CalculationProps" PRIMARY KEY ("CalculationPropId");

ALTER TABLE ONLY "CalculationProps"
    ADD CONSTRAINT "FK_CalculationProps_Calculations_CalculationId"
        FOREIGN KEY ("CalculationId")
        REFERENCES "Calculations"("CalculationId") ON DELETE CASCADE;

ALTER TABLE "CalculationProps" OWNER TO "Elysian";