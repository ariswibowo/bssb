PRINT N'';
PRINT N'Installing CalculationMetrics table...';
GO

CREATE TABLE [dbo].[CalculationMetrics] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [Metric] nvarchar(100) NOT NULL,
    [Value] nvarchar(max) NOT NULL,
    [Processed] integer NULL,
    [LastChanged] datetime NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[CalculationMetrics] ADD CONSTRAINT [PK_CalculationMetrics] PRIMARY KEY ([Id]);
GO

ALTER TABLE [dbo].[CalculationMetrics]
    ADD CONSTRAINT [FK_CalculationMetrics_Calculations_CalculationId]
        FOREIGN KEY ([CalculationId])
        REFERENCES [dbo].[Calculations]([CalculationId]) ON DELETE CASCADE;
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_CalculationMetrics_CalculationId_Metric] ON [dbo].[CalculationMetrics]([CalculationId], [Metric]);
GO