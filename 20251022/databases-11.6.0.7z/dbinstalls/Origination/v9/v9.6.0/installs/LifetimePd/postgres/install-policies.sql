\echo '';
\echo 'Installing Policies table...';

CREATE TABLE "Policies" (
    "PolicyId" uuid NOT NULL,
    "ObjectiveTypeId" uuid NULL,
    "PolicyType" varchar(50) NOT NULL,
    "Description" varchar(300) NOT NULL,
    "DefaultPolicy" text NOT NULL,
    "ActivePolicy" text NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "Policies" ADD CONSTRAINT "PK_Policies" PRIMARY KEY ("PolicyId");

ALTER TABLE ONLY "Policies" 
  ADD CONSTRAINT "FK_Policies_ObjectiveTypes_ObjectiveTypeId" 
      FOREIGN KEY ("ObjectiveTypeId")
      REFERENCES "ObjectiveTypes"("ObjectiveTypeId") 
      ON DELETE NO ACTION;

ALTER TABLE "Policies" OWNER TO "Elysian";

\copy "Policies" FROM '{data}/LifetimePd/Policies.dat' DELIMITER E'\t' CSV QUOTE '#' HEADER;