USE master
GO

PRINT N'Initializing database...'
GO

IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = '{database}')
  BEGIN
    CREATE DATABASE [{database}]
    END
    GO

USE [{database}];
GO

PRINT N'';
PRINT N'Dropping tables...';
GO

DROP TABLE IF EXISTS [dbo].[DbVersions];
GO

DROP TABLE IF EXISTS [dbo].[Policies];
GO

DROP TABLE IF EXISTS [dbo].[ObjectiveTypes];
GO

DROP TABLE IF EXISTS [dbo].[ApplicationLogs];
GO

DROP TABLE IF EXISTS [dbo].[CalculationEvents];
GO

DROP TABLE IF EXISTS [dbo].[CalculationLogs];
GO

DROP TABLE IF EXISTS [dbo].[CalculationMetrics];
GO

DROP TABLE IF EXISTS [dbo].[CalculationProps];
GO

DROP TABLE IF EXISTS [dbo].[Calculations];
GO

DROP TABLE IF EXISTS [dbo].[Codes];
GO

DROP TABLE IF EXISTS [dbo].[ResultLifetimePdIndex];
GO

DROP TABLE IF EXISTS [dbo].[ResultLifetimePd];
GO

DROP TABLE IF EXISTS [dbo].[ResultSegmentLifetimePd];
GO

DROP TABLE IF EXISTS [dbo].[JobLogs];
GO

DROP TABLE IF EXISTS [dbo].[Jobs];
GO