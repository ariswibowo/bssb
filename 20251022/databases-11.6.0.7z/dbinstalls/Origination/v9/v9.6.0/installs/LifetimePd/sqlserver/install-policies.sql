PRINT N'';
PRINT N'Installing Policies table...';
GO

CREATE TABLE [dbo].[Policies] (
    [PolicyId] uniqueidentifier NOT NULL,
    [ObjectiveTypeId] uniqueidentifier NULL,
    [PolicyType] nvarchar(50) NOT NULL,
    [Description] nvarchar(300) NOT NULL,
    [DefaultPolicy] nvarchar(max) NOT NULL,
    [ActivePolicy] nvarchar(max) NOT NULL,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
);
GO

ALTER TABLE [dbo].[Policies] ADD CONSTRAINT [PK_Policies] PRIMARY KEY ([PolicyId]);
GO

ALTER TABLE [dbo].[Policies] 
  ADD CONSTRAINT [FK_Policies_ObjectiveTypes_ObjectiveTypeId] 
      FOREIGN KEY ([ObjectiveTypeId])
      REFERENCES [dbo].[ObjectiveTypes]([ObjectiveTypeId]) 
      ON DELETE NO ACTION;
GO

BULK INSERT [dbo].[Policies]
FROM '{data}/LifetimePd/Policies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO