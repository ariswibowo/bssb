\connect "postgres"

SET client_min_messages = error;

\echo 'Initializing database...'

\echo 'Terminating database connections...'
SELECT pg_terminate_backend(pg_stat_activity.pid)
FROM pg_stat_activity
WHERE datname = '{database}'
  AND pid <> pg_backend_pid();

\echo 'Dropping existing database...'
DROP DATABASE IF EXISTS "{database}";

\echo 'Creating database...'
CREATE DATABASE "{database}"  OWNER = "Elysian";

\connect "{database}";

\echo 'Dropping tables...';

DROP TABLE IF EXISTS "DbVersions";

DROP TABLE IF EXISTS "Policies";

DROP TABLE IF EXISTS "ObjectiveTypes";

DROP TABLE IF EXISTS "ApplicationLogs";
DROP SEQUENCE IF EXISTS "ApplicationLogs_Id_seq";

DROP TABLE IF EXISTS "CalculationEvents";

DROP TABLE IF EXISTS "CalculationLogs";

DROP TABLE IF EXISTS "CalculationMetrics";
DROP SEQUENCE IF EXISTS "CalculationMetrics_Id_seq";

DROP TABLE IF EXISTS "CalculationProps";
DROP SEQUENCE IF EXISTS "CalculationProps_Id_seq";

DROP TABLE IF EXISTS "Calculations";

DROP TABLE IF EXISTS "Codes";

DROP TABLE IF EXISTS "ResultLifetimePdIndex";
DROP SEQUENCE IF EXISTS "ResultLifetimePdIndex_Id_seq";

DROP TABLE IF EXISTS "ResultLifetimePd";
DROP SEQUENCE IF EXISTS "ResultLifetimePd_Id_seq";

DROP TABLE IF EXISTS "ResultSegmentLifetimePd";
DROP SEQUENCE IF EXISTS "ResultSegmentLifetimePd_Id_seq";

DROP TABLE IF EXISTS "JobLogs";
DROP SEQUENCE IF EXISTS "JobLogs_Id_seq";

DROP TABLE IF EXISTS "Jobs";