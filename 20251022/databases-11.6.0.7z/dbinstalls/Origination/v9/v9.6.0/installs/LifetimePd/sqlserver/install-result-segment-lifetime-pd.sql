PRINT N'';
PRINT N'Installing ResultSegmentLifetimePd table...';
GO

CREATE TABLE [dbo].[ResultSegmentLifetimePd] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [SummaryId] uniqueidentifier NOT NULL,
    [HashCode]  nvarchar(256) NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [ProductClass] nvarchar(50) NOT NULL,
    [Status] nvarchar(30) NOT NULL,
    [AssaCode] nvarchar(30) NOT NULL,
    [AssaFactor] numeric(12, 9) NOT NULL,
    [Currency] nchar(3) NOT NULL,
    [Curve] nvarchar(max) NOT NULL,
    [Dimensions] nvarchar(max) NOT NULL,
    [OutstandingAmount] numeric(20, 2) NOT NULL,
    [NumContracts] integer NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultSegmentLifetimePd] ADD CONSTRAINT [PK_ResultSegmentLifetimePd] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultSegmentLifetimePd_HashCode] ON [dbo].[ResultSegmentLifetimePd]([HashCode]);
GO

CREATE UNIQUE INDEX [IX_ResultSegmentLifetimePd_SummaryId] ON [dbo].[ResultSegmentLifetimePd]([SummaryId]);
GO