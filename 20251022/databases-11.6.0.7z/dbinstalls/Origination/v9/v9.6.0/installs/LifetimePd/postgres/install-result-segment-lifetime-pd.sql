\echo '';
\echo 'Installing ResultSegmentLifetimePd table...';

\echo '';
\echo 'Creating sequence ResultSegmentLifetimePd_Id_seq...';

CREATE SEQUENCE "ResultSegmentLifetimePd_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultSegmentLifetimePd_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultSegmentLifetimePd...';

CREATE TABLE "ResultSegmentLifetimePd" (
    "Id" bigint DEFAULT nextval('"ResultSegmentLifetimePd_Id_seq"'::regclass) NOT NULL,
    "SummaryId" uuid NOT NULL,
    "HashCode" varchar(256) NOT NULL,
    "CalculationId" uuid NOT NULL,
    "ProductClass" varchar(50) NOT NULL,
    "Status" varchar(30) NOT NULL,
    "AssaCode" varchar(30) NOT NULL,
    "AssaFactor" numeric(12, 9) NOT NULL,
    "Currency" char(3) NOT NULL,
    "Curve" text NOT NULL,
    "Dimensions" text NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "NumContracts" integer NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultSegmentLifetimePd" ADD CONSTRAINT "PK_ResultSegmentLifetimePd" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultSegmentLifetimePd_HashCode" ON "ResultSegmentLifetimePd" USING btree ("HashCode");

CREATE UNIQUE INDEX "IX_ResultSegmentLifetimePd_SummaryId" ON "ResultSegmentLifetimePd" USING btree ("SummaryId");

ALTER TABLE "ResultSegmentLifetimePd" OWNER TO "Elysian";