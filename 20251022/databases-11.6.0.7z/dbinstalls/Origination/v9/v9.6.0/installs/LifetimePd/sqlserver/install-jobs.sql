PRINT N'';
PRINT N'Installing Jobs table...';
GO

CREATE TABLE [dbo].[Jobs] (
    [JobId] uniqueidentifier NOT NULL,
    [Status] nvarchar(50) NOT NULL,
    [ReportingDate] datetime NOT NULL,
    [Entity] nvarchar(50) NOT NULL,
    [Data] nvarchar(max),
    [StartTimestamp] datetime,
    [EndTimestamp] datetime,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL
)
GO

ALTER TABLE [dbo].[Jobs]
    ADD CONSTRAINT [PK_Jobs] PRIMARY KEY ([JobId]);
GO