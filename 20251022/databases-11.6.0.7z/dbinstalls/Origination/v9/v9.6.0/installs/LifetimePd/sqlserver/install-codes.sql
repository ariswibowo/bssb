PRINT N'';
PRINT N'Installing Codes table...';
GO

CREATE TABLE [dbo].[Codes] (
    [CodeId] uniqueidentifier NOT NULL,
    [Category] nvarchar(50) NOT NULL,
    [Type] nvarchar(50) NOT NULL,
    [Data] nvarchar(max) NOT NULL,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
);
GO

ALTER TABLE [dbo].[Codes] ADD CONSTRAINT [PK_Codes] PRIMARY KEY ([CodeId]);
GO

BULK INSERT [dbo].[Codes]
FROM '{data}/LifetimePd/Codes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO