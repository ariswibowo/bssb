PRINT N'';
PRINT N'Installing ApplicationLogs table...';
GO

CREATE TABLE [dbo].[ApplicationLogs] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [LogId] uniqueidentifier NOT NULL,
    [Origin] nvarchar(50) NOT NULL,
    [Logs] nvarchar(max) NOT NULL,
    [StartTimestamp] datetime NOT NULL,
    [EndTimestamp] datetime NULL,
);
GO

ALTER TABLE [dbo].[ApplicationLogs] ADD CONSTRAINT [PK_ApplicationLogs] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ApplicationLogs] ON [dbo].[ApplicationLogs]([LogId]);
GO