\echo '';
\echo 'Installing Codes table...';

CREATE TABLE "Codes" (
    "CodeId" uuid NOT NULL,
    "Category" varchar(50) NOT NULL,
    "Type" varchar(50) NOT NULL,
    "Data" text NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "Codes" ADD CONSTRAINT "PK_Codes" PRIMARY KEY ("CodeId");

ALTER TABLE "Codes" OWNER TO "Elysian";

\copy "Codes" FROM '{data}/LifetimePd/Codes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;