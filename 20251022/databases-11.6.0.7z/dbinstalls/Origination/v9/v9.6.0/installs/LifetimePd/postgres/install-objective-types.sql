\echo '';
\echo 'Installing ObjectiveTypes table...';

CREATE TABLE "ObjectiveTypes" (
    "ObjectiveTypeId" uuid NOT NULL,
    "Name" varchar(100) NOT NULL,
    "Description" varchar(300) NOT NULL,
    "Code" varchar(50) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "ObjectiveTypes" ADD CONSTRAINT "PK_ObjectiveTypes" PRIMARY KEY ("ObjectiveTypeId");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ObjectiveTypes" ON "ObjectiveTypes" USING btree ("Code");

ALTER TABLE "ObjectiveTypes" OWNER TO "Elysian";

\copy "ObjectiveTypes" FROM '{data}/LifetimePd/ObjectiveTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;