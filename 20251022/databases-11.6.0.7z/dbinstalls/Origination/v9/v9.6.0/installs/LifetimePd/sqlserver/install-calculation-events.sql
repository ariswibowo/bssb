PRINT N'';
PRINT N'Installing CalculationEvents table...';
GO

CREATE TABLE [dbo].[CalculationEvents] (
    [EventId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [Event] nvarchar(50) NOT NULL,
    [EventTimestamp] datetime NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[CalculationEvents] ADD CONSTRAINT [PK_CalculationEvents] PRIMARY KEY ([EventId]);
GO

ALTER TABLE [dbo].[CalculationEvents]
    ADD CONSTRAINT [FK_CalculationEvents_Calculations_CalculationId]
        FOREIGN KEY ([CalculationId])
        REFERENCES [dbo].[Calculations]([CalculationId]) ON DELETE CASCADE;
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE INDEX [IX_CalculationEvents_CalculationId] ON [dbo].[CalculationEvents]([CalculationId]);
GO