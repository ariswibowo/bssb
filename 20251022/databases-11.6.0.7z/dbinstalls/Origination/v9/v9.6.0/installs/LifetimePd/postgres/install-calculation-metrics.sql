\echo '';
\echo 'Installing CalculationMetrics table...';

\echo '';
\echo 'Creating sequence CalculationMetrics_Id_seq...';

CREATE SEQUENCE "CalculationMetrics_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "CalculationMetrics_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table CalculationMetrics...';

CREATE TABLE "CalculationMetrics" (
    "Id" bigint DEFAULT nextval('"CalculationMetrics_Id_seq"'::regclass) NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Metric" varchar(100) NOT NULL,
    "Value" text NOT NULL,
    "Processed" integer NULL,
    "LastChanged" timestamp without time zone NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "CalculationMetrics" ADD CONSTRAINT "PK_CalculationMetrics" PRIMARY KEY ("Id");

ALTER TABLE ONLY "CalculationMetrics"
    ADD CONSTRAINT "FK_CalculationMetrics_Calculations_CalculationId"
        FOREIGN KEY ("CalculationId")
        REFERENCES "Calculations"("CalculationId") ON DELETE CASCADE;

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_CalculationMetrics_CalculationId_Metric" ON "CalculationMetrics" USING btree ("CalculationId", "Metric");

ALTER TABLE "CalculationMetrics" OWNER TO "Elysian";