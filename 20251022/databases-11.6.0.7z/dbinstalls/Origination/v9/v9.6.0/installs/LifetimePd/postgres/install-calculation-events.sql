\echo '';
\echo 'Installing CalculationEvents table...';

CREATE TABLE "CalculationEvents" (
    "EventId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Event" varchar(50) NOT NULL,
    "EventTimestamp" timestamp without time zone NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "CalculationEvents" ADD CONSTRAINT "PK_CalculationEvents" PRIMARY KEY ("EventId");

ALTER TABLE ONLY "CalculationEvents"
    ADD CONSTRAINT "FK_CalculationEvents_Calculations_CalculationId"
        FOREIGN KEY ("CalculationId")
        REFERENCES "Calculations"("CalculationId") ON DELETE CASCADE;

\echo '';
\echo 'Creating index...'

CREATE INDEX "IX_CalculationEvents_CalculationId" ON "CalculationEvents" USING btree ("CalculationId");

ALTER TABLE "CalculationEvents" OWNER TO "Elysian";