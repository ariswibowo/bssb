\echo '';
\echo 'Installing CalculationLogs table...';

CREATE TABLE "CalculationLogs" (
    "LogId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL,
    "Message" text NOT NULL,
    "Level" varchar(50) NOT NULL,
    "Source" varchar(50) NOT NULL,
    "Data" text NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "CalculationLogs" ADD CONSTRAINT "PK_CalculationLogs" PRIMARY KEY ("LogId");

ALTER TABLE ONLY "CalculationLogs"
    ADD CONSTRAINT "FK_CalculationLogs_Calculations_CalculationId"
        FOREIGN KEY ("CalculationId")
        REFERENCES "Calculations"("CalculationId") ON DELETE CASCADE;

\echo '';
\echo 'Creating index...'

CREATE INDEX "IX_CalculationLogs_CalculationId" ON "CalculationLogs" USING btree ("CalculationId");

ALTER TABLE "CalculationLogs" OWNER TO "Elysian";