PRINT N'';
PRINT N'Installing Calculations table...';
GO

CREATE TABLE [dbo].[Calculations] (
    [CalculationId] uniqueidentifier NOT NULL,
    [Entity] nvarchar(50) NOT NULL,
    [ReportingDate] datetime NOT NULL,
    [Priority] integer NOT NULL,
    [IsCombined] bit NOT NULL,
    [Status] nvarchar(50) NOT NULL,
    [Type] nvarchar(100) NOT NULL,
    [MessagesExpected] integer NOT NULL,
    [MessagesLoaded] integer NOT NULL,
    [MessagesProcessed] integer NOT NULL,
    [MessagesRejected] integer NOT NULL,
    [Data] nvarchar(max),
    [Checks] nvarchar(max),
    [Analytics] nvarchar(max),
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[Calculations] ADD CONSTRAINT [PK_Calculations] PRIMARY KEY ([CalculationId]);
GO