PRINT N'';
PRINT N'Installing ResultLifetimePd table...';
GO

CREATE TABLE [dbo].[ResultLifetimePd] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ResultId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [ProductId] uniqueidentifier NOT NULL,
    [ProductClass] nvarchar(50) NOT NULL,
    [Status] nvarchar(50) NOT NULL,
    [Result] nvarchar(max) NULL,
    [BData] varbinary(max) NULL,
    [RetentionCopied]  bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultLifetimePd] ADD CONSTRAINT [PK_ResultLifetimePd] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultLifetimePd_ResultId] ON [dbo].[ResultLifetimePd]([ResultId]);
GO

CREATE INDEX [IX_ResultLifetimePd_CalculationId_ProductId] ON [dbo].[ResultLifetimePd]([CalculationId], [ProductId]);
GO