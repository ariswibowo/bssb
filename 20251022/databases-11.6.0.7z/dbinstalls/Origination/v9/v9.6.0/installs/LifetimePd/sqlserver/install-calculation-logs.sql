PRINT N'';
PRINT N'Installing CalculationLogs table...';
GO

CREATE TABLE [dbo].[CalculationLogs] (
    [LogId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [Timestamp] datetime NOT NULL,
    [Message] nvarchar(max) NOT NULL,
    [Level] nvarchar(50) NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Data] nvarchar(max) NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[CalculationLogs] ADD CONSTRAINT [PK_CalculationLogs] PRIMARY KEY ([LogId]);
GO

ALTER TABLE [dbo].[CalculationLogs]
    ADD CONSTRAINT [FK_CalculationLogs_Calculations_CalculationId]
        FOREIGN KEY ([CalculationId])
        REFERENCES [dbo].[Calculations]([CalculationId]) ON DELETE CASCADE;
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE INDEX [IX_CalculationLogs_CalculationId] ON [dbo].[CalculationLogs]([CalculationId]);
GO