\echo '';
\echo 'Installing JobLogs table...';

CREATE SEQUENCE "JobLogs_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "JobLogs_Id_seq" OWNER TO "Elysian";

CREATE TABLE "JobLogs" (
    "Id" bigint DEFAULT nextval('"JobLogs_Id_seq"'::regclass) NOT NULL,
    "LogId" uuid NOT NULL,
    "JobId" uuid NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL,
    "Message" text NOT NULL,
    "Level" varchar(50) NOT NULL,
    "Source" varchar(50) NOT NULL,
    "Data" text NULL
);

ALTER TABLE "JobLogs" OWNER to "Elysian";

ALTER TABLE ONLY "JobLogs"
    ADD CONSTRAINT "PK_JobLogs" PRIMARY KEY ("Id");

ALTER TABLE ONLY "JobLogs"
    ADD CONSTRAINT "FK_JobLogs_Jobs_JobId" FOREIGN KEY ("JobId") REFERENCES "Jobs"("JobId") ON DELETE CASCADE;

CREATE UNIQUE INDEX "IX_JobLogs_LogId" ON "JobLogs" USING btree ("LogId");
CREATE INDEX "IX_JobLogs_JobId" ON "JobLogs" USING btree ("JobId");