\echo '';
\echo 'Installing ResultLifetimePdIndex table...';

\echo '';
\echo 'Creating sequence ResultLifetimePdIndex_Id_seq...';

CREATE SEQUENCE "ResultLifetimePdIndex_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultLifetimePdIndex_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultLifetimePdIndex...';

CREATE TABLE "ResultLifetimePdIndex" (
    "Id" bigint DEFAULT nextval('"ResultLifetimePdIndex_Id_seq"'::regclass) NOT NULL,
    "CalculationId" uuid NOT NULL,
    "ItemId" uuid NOT NULL,
    "ItemClass" varchar(50) NOT NULL,
    "ResultId" uuid NOT NULL,
    "SearchText" text NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultLifetimePdIndex" ADD CONSTRAINT "PK_ResultLifetimePdIndex" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultLifetimePdIndex_ItemId_ResultId" ON "ResultLifetimePdIndex" USING btree ("ItemId", "ResultId");

ALTER TABLE "ResultLifetimePdIndex" OWNER TO "Elysian";