# README

**Release: HistoricalLgd V1.1.0**

## Release Features & Fixes

- [Feature: Analytics Framework](#feature-analytics-framework)
- [Feature: Workout LGD Multiple Consolidation Configurations](#feature-workout-lgd-multiple-consolidation-configurations)

## Feature: Analytics Framework

Implements the new analytics framework for Historical LGD calculations. Initially, the new feature will cater for the pre-calculation of dashboards. This iteration:

- adds a DashboardType table that lists all dashboard type definitions;
- adds an initial list of dashboard types for Workout LGD calculations;
- adds a Dashboards table that will hold the pre-calculation dashboard data.

### Workout LGD Dashboard Types

| Dashboard Type               | Description                                                                                                                    |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| MethodConfiguration          | Shows the method configuration used to calculate the Segment level LGD result.                                                 |
| LgdByConsolidationMethod     | Shows the Segment level LGD result by consolidation method.                                                                    |
| RelevanceByNumContracts      | Shows the importance of the Segment level LGD result within the calculation, based on the number of contracts in that segment. |
| RelevanceByOutstandingAmount | Shows the importance of the Segment level LGD result within the calculation, based on the outstanding amount of that segment.  |

References: #EMP-1296

[top](#readme)

## Feature: Workout LGD Multiple Consolidation Configurations

Updates a UNIQUE INDEX in the ResultConsolidatedWorkoutDefinitions table to cater for models that have multiple approaches, that each have their own Workout LGD configuration with a different consolidation configuration.

Before, a record was created in ResultConsolidatedWorkoutDefinitions for each used consolidation method, regardless of whether it was configured as Primary or Secondary consolidation. In the updated version, one record is created per combination of consolidation method + primary/secondary status.

References: #EMP-1235

[top](#readme)