PRINT N''
PRINT N'Updating table ResultConsolidatedWorkoutDefinitions...'
GO

PRINT N'Dropping existing index IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod...'
GO

DROP INDEX IF EXISTS [IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod]
  ON [dbo].[ResultConsolidatedWorkoutDefinitions]


PRINT N'Adding new existing index IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod_IsPrimary...'
GO

DROP INDEX IF EXISTS [IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod_IsPrimary]
  ON [dbo].[ResultConsolidatedWorkoutDefinitions]

CREATE UNIQUE INDEX IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod_IsPrimary
    ON [dbo].ResultConsolidatedWorkoutDefinitions(CalculationId, ConsolidationMethod, IsPrimary);
