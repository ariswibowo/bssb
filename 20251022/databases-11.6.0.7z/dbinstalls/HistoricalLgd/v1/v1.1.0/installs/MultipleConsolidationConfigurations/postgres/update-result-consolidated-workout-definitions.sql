\echo '';
\echo 'Installing table ResultConsolidatedWorkoutDefinitions...';

\echo 'Dropping existing index IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod...';

DROP INDEX IF EXISTS "IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod";

\echo 'Adding new existing index IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod_IsPrimary...';

DROP INDEX IF EXISTS "IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod_IsPrimary";

CREATE UNIQUE INDEX "IX_ResultConsolidatedWorkoutDefinitions_CalcId_ConsoMethod_IsPrimary" 
    ON "ResultConsolidatedWorkoutDefinitions" USING btree ("CalculationId", "ConsolidationMethod", "IsPrimary");

