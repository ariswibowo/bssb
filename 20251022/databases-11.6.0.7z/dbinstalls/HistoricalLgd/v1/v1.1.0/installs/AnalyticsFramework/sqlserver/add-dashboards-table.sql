PRINT N''
PRINT N'Installing table Dashboards...'
GO

DROP TABLE IF EXISTS [dbo].[Dashboards];

CREATE TABLE [dbo].[Dashboards] (
    [DashboardId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [DashboardTypeId] uniqueidentifier NOT NULL,
    [Context] nvarchar(max) NOT NULL,
    [Data] nvarchar(max) NOT NULL
);

ALTER TABLE [dbo].[Dashboards]
    ADD CONSTRAINT [PK_Dashboards] PRIMARY KEY ([DashboardId]);