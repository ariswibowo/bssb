\echo ''
\echo 'Cleaning up existing dashboard types...';

TRUNCATE TABLE "DashboardTypes";

\echo ''
\echo 'Adding new dashboard types...';

\copy "DashboardTypes" FROM '{data}/AnalyticsFramework-DashboardTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;