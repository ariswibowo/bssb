PRINT N''
PRINT N'Installing table DashboardTypes...'
GO

DROP TABLE IF EXISTS [dbo].[DashboardTypes];

CREATE TABLE [dbo].[DashboardTypes] (
    [DashboardTypeId] uniqueidentifier NOT NULL,
    [DashboardType] nvarchar(50) NOT NULL,
    [Description] nvarchar(300) NOT NULL,
    [IsEnabled] bit NOT NULL,
    [IsRequiredAtCalcCompletion] bit NOT NULL,
    [DimensionName] nvarchar(100) NOT NULL,
    [DimensionKey] nvarchar(100) NOT NULL,
    [DimensionType] nvarchar(100) NOT NULL
);

ALTER TABLE [dbo].[DashboardTypes]
    ADD CONSTRAINT [PK_DashboardTypes] PRIMARY KEY ([DashboardTypeId]);

CREATE UNIQUE INDEX IX_DashboardTypes_DashboardType ON [dbo].DashboardTypes(DashboardType);