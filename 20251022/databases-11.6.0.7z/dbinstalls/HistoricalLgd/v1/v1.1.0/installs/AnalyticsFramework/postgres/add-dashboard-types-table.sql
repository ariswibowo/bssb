\echo '';
\echo 'Installing table DashboardTypes...';

DROP TABLE IF EXISTS "DashboardTypes";

CREATE TABLE "DashboardTypes" (
    "DashboardTypeId" uuid NOT NULL,
    "DashboardType" varchar(50) NOT NULL,
    "Description" varchar(300) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "IsRequiredAtCalcCompletion" boolean NOT NULL,
    "DimensionName" varchar(100) NOT NULL,
    "DimensionKey" varchar(100) NOT NULL,
    "DimensionType" varchar(100) NOT NULL
);

ALTER TABLE ONLY "DashboardTypes"
    ADD CONSTRAINT "PK_DashboardTypes" PRIMARY KEY ("DashboardTypeId");

ALTER TABLE "DashboardTypes" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_DashboardTypes_DashboardType" ON "DashboardTypes" USING btree ("DashboardType");
