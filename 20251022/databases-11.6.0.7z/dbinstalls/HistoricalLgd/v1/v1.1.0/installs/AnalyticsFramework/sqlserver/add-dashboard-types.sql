PRINT N''
PRINT N'Cleaning up existing dashboard types...'
GO

TRUNCATE TABLE [dbo].[DashboardTypes];
GO

PRINT N''
PRINT N'Adding new dashboard types...'
GO

BULK INSERT [dbo].[DashboardTypes]
FROM '{data}/AnalyticsFramework-DashboardTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO