\echo '';
\echo 'Installing table Dashboards...';

DROP TABLE IF EXISTS "Dashboards";

CREATE TABLE "Dashboards" (
    "DashboardId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "DashboardTypeId" uuid NOT NULL,
    "Context" text NOT NULL,
    "Data" text NOT NULL
);

ALTER TABLE ONLY "Dashboards"
    ADD CONSTRAINT "PK_Dashboards" PRIMARY KEY ("DashboardId");

ALTER TABLE "Dashboards" OWNER TO "Empyrean";