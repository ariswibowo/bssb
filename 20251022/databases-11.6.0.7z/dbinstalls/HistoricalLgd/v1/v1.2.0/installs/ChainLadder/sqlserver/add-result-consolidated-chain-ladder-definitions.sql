PRINT N''
PRINT N'Installing table ResultConsolidatedChainLadderDefinitions...'
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedChainLadderDefinitions];

CREATE TABLE [dbo].ResultConsolidatedChainLadderDefinitions (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [SegmentName] nvarchar(100) NOT NULL,
    [Lgd] numeric(12,9) NOT NULL,
    [Data] nvarchar(max) NOT NULL
);

ALTER TABLE [dbo].ResultConsolidatedChainLadderDefinitions
    ADD CONSTRAINT [PK_ResultConsolidatedChainLadderDefinitions] PRIMARY KEY ([Id]);

CREATE UNIQUE INDEX IX_ResultConsolidatedChainLadderDefinitions_CalcId_SegmentId
    ON [dbo].ResultConsolidatedChainLadderDefinitions(CalculationId, SegmentId);