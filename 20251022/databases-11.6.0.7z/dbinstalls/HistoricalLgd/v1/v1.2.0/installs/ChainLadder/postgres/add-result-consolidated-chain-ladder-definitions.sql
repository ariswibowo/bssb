\echo '';
\echo 'Installing table ResultConsolidatedChainLadderDefinitions...';

DROP TABLE IF EXISTS "ResultConsolidatedChainLadderDefinitions";

CREATE SEQUENCE "ResultConsolidatedChainLadderDefinitions_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedChainLadderDefinitions_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultConsolidatedChainLadderDefinitions" (
    "Id" integer DEFAULT nextval('"ResultConsolidatedChainLadderDefinitions_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "SegmentId" uuid NOT NULL,
    "SegmentName" varchar(100) NOT NULL,
    "Lgd"  numeric(12, 9) NOT NULL,
    "Data" text NOT NULL
);      

ALTER TABLE ONLY "ResultConsolidatedChainLadderDefinitions"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadderDefinitions" PRIMARY KEY ("Id");

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadderDefinitions_CalcId_SegmentId" 
    ON "ResultConsolidatedChainLadderDefinitions" USING btree ("CalculationId", "SegmentId");

ALTER TABLE "ResultConsolidatedChainLadderDefinitions" OWNER TO "Empyrean";