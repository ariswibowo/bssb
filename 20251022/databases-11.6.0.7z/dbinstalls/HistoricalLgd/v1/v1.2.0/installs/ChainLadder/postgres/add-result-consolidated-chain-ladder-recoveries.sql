\echo '';
\echo 'Installing table ResultConsolidatedChainLadderRecoveries...';

DROP TABLE IF EXISTS "ResultConsolidatedChainLadderRecoveries";

CREATE SEQUENCE "ResultConsolidatedChainLadderRecoveries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedChainLadderRecoveries_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultConsolidatedChainLadderRecoveries" (
    "Id" integer DEFAULT nextval('"ResultConsolidatedChainLadderRecoveries_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "RecoveryDate" timestamp without time zone NOT NULL,
    "HashCode" varchar(256),
    "RecoveryAmount" numeric(20, 2) NOT NULL,
    "DiscountedRecoveryAmount" numeric(20, 2) NOT NULL,
    "IsProjected" boolean NOT NULL
);

ALTER TABLE ONLY "ResultConsolidatedChainLadderRecoveries"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadderRecoveries" PRIMARY KEY ("Id");

ALTER TABLE "ResultConsolidatedChainLadderRecoveries" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadderRecoveries_HashCode" ON "ResultConsolidatedChainLadderRecoveries" USING btree ("HashCode");
