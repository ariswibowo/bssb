\echo '';
\echo 'Installing table ResultConsolidatedChainLadders...';

DROP TABLE IF EXISTS "ResultConsolidatedChainLadders";

CREATE SEQUENCE "ResultConsolidatedChainLadders_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedChainLadders_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultConsolidatedChainLadders" (
    "Id" integer DEFAULT nextval('"ResultConsolidatedChainLadders_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "HashCode" varchar(256),
    "NumContracts" integer NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "DebtSalesAmount" numeric(20, 2) NOT NULL,
    "DiscountedDebtSalesAmount" numeric(20, 2) NOT NULL,
    "DebtCollectionCost" numeric(20, 2) NOT NULL,
    "DiscountedDebtCollectionCost" numeric(20, 2) NOT NULL,
    "LitigationCost" numeric(20, 2) NOT NULL,
    "DiscountedLitigationCost" numeric(20, 2) NOT NULL,
    "ExpectedRecoveryAmount" numeric(20, 2) NOT NULL,
    "ExpectedRecoveryPercentage" numeric(12, 9) NOT NULL,
    "TimeWeight" numeric(12, 9) NOT NULL,
    "Lgd" numeric(12, 9) NOT NULL
);

ALTER TABLE ONLY "ResultConsolidatedChainLadders"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadders" PRIMARY KEY ("Id");

ALTER TABLE "ResultConsolidatedChainLadders" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadders_HashCode" ON "ResultConsolidatedChainLadders" USING btree ("HashCode");
