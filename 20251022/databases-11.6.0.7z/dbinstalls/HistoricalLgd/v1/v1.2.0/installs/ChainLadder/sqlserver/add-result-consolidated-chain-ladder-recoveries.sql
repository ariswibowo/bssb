PRINT N''
PRINT N'Installing table ResultConsolidatedChainLadderRecoveries...'
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedChainLadderRecoveries];

CREATE TABLE [dbo].ResultConsolidatedChainLadderRecoveries (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [RecoveryDate] datetime NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [RecoveryAmount] numeric(20,2) NOT NULL,
    [DiscountedRecoveryAmount] numeric(20,2) NOT NULL,
    [IsProjected] bit NOT NULL
);

ALTER TABLE [dbo].ResultConsolidatedChainLadderRecoveries
    ADD CONSTRAINT [PK_ResultConsolidatedChainLadderRecoveries] PRIMARY KEY ([Id]);

CREATE UNIQUE INDEX IX_ResultConsolidatedChainLadderRecoveries_HashCode ON [dbo].ResultConsolidatedChainLadderRecoveries(HashCode);