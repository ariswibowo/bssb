\echo '';
\echo 'Installing table ResultChainLadders...';

DROP TABLE IF EXISTS "ResultChainLadders";

CREATE SEQUENCE "ResultChainLadders_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultChainLadders_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultChainLadders" (
    "Id" integer DEFAULT nextval('"ResultChainLadders_Id_seq"'::regclass) NOT NULL,
    "ResultId" uuid NOT NULL,
    "SegmentId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "DebtSalesAmount" numeric(20, 2) NOT NULL,
    "DiscountedDebtSalesAmount" numeric(20, 2) NOT NULL,
    "RecoveryIncrements" text NOT NULL
);

ALTER TABLE ONLY "ResultChainLadders"
    ADD CONSTRAINT "PK_ResultChainLadders" PRIMARY KEY ("Id");

ALTER TABLE "ResultChainLadders" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultChainLadders_ResultId" ON "ResultChainLadders" USING btree ("ResultId");
