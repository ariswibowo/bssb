PRINT N''
PRINT N'Installing table ResultConsolidatedChainLadders...'
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedChainLadders];

CREATE TABLE [dbo].ResultConsolidatedChainLadders (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [NumContracts] int NOT NULL,
    [OutstandingAmount] numeric(20,2) NOT NULL,
    [DebtSalesAmount] numeric(20,2) NOT NULL,
    [DiscountedDebtSalesAmount] numeric(20,2) NOT NULL,
    [DebtCollectionCost] numeric(20,2) NOT NULL,
    [DiscountedDebtCollectionCost] numeric(20,2) NOT NULL,
    [LitigationCost] numeric(20,2) NOT NULL,
    [DiscountedLitigationCost] numeric(20,2) NOT NULL,
    [ExpectedRecoveryAmount] numeric(20, 2) NOT NULL,
    [ExpectedRecoveryPercentage] numeric(12, 9) NOT NULL,
    [TimeWeight] numeric(12, 9) NOT NULL,
    [Lgd] numeric(12, 9) NOT NULL
);

ALTER TABLE [dbo].ResultConsolidatedChainLadders
    ADD CONSTRAINT [PK_ResultConsolidatedChainLadders] PRIMARY KEY ([Id]);

CREATE UNIQUE INDEX IX_ResultConsolidatedChainLadders_HashCode ON [dbo].ResultConsolidatedChainLadders(HashCode);