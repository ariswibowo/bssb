PRINT N''
PRINT N'Installing table ResultChainLadders...'
GO

DROP TABLE IF EXISTS [dbo].[ResultChainLadders];

CREATE TABLE [dbo].ResultChainLadders (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ResultId] uniqueidentifier NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [OutstandingAmount] numeric(20, 2) NOT NULL,
    [DebtSalesAmount] numeric(20, 2) NOT NULL,
    [DiscountedDebtSalesAmount] numeric(20, 2) NOT NULL,
    [RecoveryIncrements] nvarchar(max) NOT NULL
);

ALTER TABLE [dbo].ResultChainLadders
    ADD CONSTRAINT [PK_ResultChainLadders] PRIMARY KEY ([Id]);

CREATE UNIQUE INDEX IX_ResultChainLadders_ResultId ON [dbo].ResultChainLadders(ResultId);