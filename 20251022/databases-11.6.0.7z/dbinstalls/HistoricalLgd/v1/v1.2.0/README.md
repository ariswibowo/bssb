# README

**Release: HistoricalLgd V1.2.0**

## Release Features & Fixes

- [Feature: Chain Ladder LGD](#feature-chain-ladder-lgd)

## Feature: Chain Ladder LGD

The Chain Ladder LGD calculation method requires a set of new tables to store its calculation results:
* ResultChainLadders, which stores one record for each contract level message that is processed during the calculation
* ResultConsolidatedChainLadderDefinitions, which stores the final segment level LGD
* ResultConsolidatedChainLadders, which stores calculation results aggregated by the Defaulting time unit defined in the model (e.g. month, quarter or year) 
* ResultConsolidatedChainLadderRecoveries, which stores the recovery increments by time unit defined in the model (e.g. month, quarter or year)

References: #EMP-1436

[top](#readme)
