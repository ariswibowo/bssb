# README

**Release: HistoricalLgd V1.3.0**

## Release Features & Fixes

- [Feature: Update Result Reject](#feature-update-result-reject)

## Feature: Update Result Reject

Update ResultRejects table, modifed the column length of column "ExceptionMessage"

[top](#readme)