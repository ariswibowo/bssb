PRINT N''
PRINT N'Update ResultRejects table, modified length of column ExceptionMessage from 300 to max...';
GO

ALTER TABLE [dbo].[ResultRejects] ALTER COLUMN [ExceptionMessage] nvarchar(max) NOT NULL;
GO
