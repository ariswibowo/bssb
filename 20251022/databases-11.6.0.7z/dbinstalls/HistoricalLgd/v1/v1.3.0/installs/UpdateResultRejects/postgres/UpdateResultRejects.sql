\echo '';
\echo 'Update ResultRejects table, modified length of column ExceptionMessage from 300 to max...';

ALTER TABLE "ResultRejects" ALTER COLUMN "ExceptionMessage" TYPE text;
ALTER TABLE "ResultRejects" ALTER COLUMN "ExceptionMessage" SET NOT NULL;
