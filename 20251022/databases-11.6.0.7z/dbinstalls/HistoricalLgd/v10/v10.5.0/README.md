# README

**Release: HistoricalLgd V10.5.0**

No upgrades required. This is a v10.5.0 "stub-only" installation delivered as part of the August-2024 10.5 release.
