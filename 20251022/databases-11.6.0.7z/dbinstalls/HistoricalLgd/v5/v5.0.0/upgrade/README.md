# README

## Release: HistoricalLgd v5.0.0 (upgrade)

No new database features or fixes are required to upgrade from the latest v4.x.x to v5.0.0
