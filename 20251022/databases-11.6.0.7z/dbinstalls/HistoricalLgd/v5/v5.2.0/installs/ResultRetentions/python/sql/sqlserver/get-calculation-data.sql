SELECT [CalculationId], [Data]
  FROM [dbo].[Calculations]
