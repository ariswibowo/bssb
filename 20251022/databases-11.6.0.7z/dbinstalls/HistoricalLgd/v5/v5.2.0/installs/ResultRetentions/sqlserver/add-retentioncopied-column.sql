PRINT N''
PRINT N'Altering all calculation result tables, adding RetentionCopied column with false as default value...'

IF COL_LENGTH('CalculationLogs', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[CalculationLogs] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('Calculations', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[Calculations] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('Dashboards', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[Dashboards] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultChainLadders', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultChainLadders] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedChainLadderDefinitions', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedChainLadderDefinitions] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedChainLadderRecoveries', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedChainLadderRecoveries] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedChainLadders', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedChainLadders] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedVintageDefinitions', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedVintageDefinitions] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedVintageRecoveries', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedVintageRecoveries] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedVintages', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedVintages] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedWorkoutDefinitions', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedWorkoutDefinitions] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultConsolidatedWorkouts', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedWorkouts] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultContracts', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultContracts] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultHops', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultHops] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultIndex', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultIndex] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultProcessed', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultProcessed] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultRejects', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultRejects] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultSegmentCollections', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultSegmentCollections] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultVintages', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultVintages] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('ResultWorkouts', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultWorkouts] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO

IF COL_LENGTH('SegmentCollectionIndex', 'RetentionCopied') IS NULL
BEGIN
    ALTER TABLE [dbo].[SegmentCollectionIndex] ADD [RetentionCopied]  bit NOT NULL DEFAULT 0;
END
GO