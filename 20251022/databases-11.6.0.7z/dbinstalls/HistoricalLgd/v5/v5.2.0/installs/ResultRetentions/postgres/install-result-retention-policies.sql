DELETE
  FROM "CalculationPolicies"
 WHERE "PolicyType" = 'ResultRetentions';

\copy "CalculationPolicies" FROM '{data}/ResultRetentionPolicies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;