SELECT "CalculationId", "Data"
  FROM "Calculations"