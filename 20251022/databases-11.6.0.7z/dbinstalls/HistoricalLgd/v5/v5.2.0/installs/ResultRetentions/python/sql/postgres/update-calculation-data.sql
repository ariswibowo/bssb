
\echo '';
\echo 'Updating Storage Calculation Data';

UPDATE "Calculations"
SET "Data" = '{data}'
WHERE "CalculationId" = '{calculationId}';
