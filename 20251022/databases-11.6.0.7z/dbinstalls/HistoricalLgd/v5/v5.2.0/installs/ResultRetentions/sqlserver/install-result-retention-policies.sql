DELETE
  FROM [dbo].[CalculationPolicies]
 WHERE [PolicyType] = 'ResultRetentions'
GO

BULK INSERT [dbo].[CalculationPolicies]
FROM '{data}/ResultRetentionPolicies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);