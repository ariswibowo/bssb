PRINT N''
PRINT N'Remove legacy calculation monitor column MessagesExpected...'
ALTER TABLE [dbo].[Calculations] DROP COLUMN IF EXISTS [MessagesExpected];
GO

PRINT N''
PRINT N'Remove legacy calculation monitor column MessagesLoaded...'
ALTER TABLE [dbo].[Calculations] DROP COLUMN IF EXISTS [MessagesLoaded];
GO

PRINT N''
PRINT N'Remove legacy calculation monitor column MessagesProcessed...'
ALTER TABLE [dbo].[Calculations] DROP COLUMN IF EXISTS [MessagesProcessed];
GO

PRINT N''
PRINT N'Remove legacy calculation monitor column MessagesRejected...'
ALTER TABLE [dbo].[Calculations] DROP COLUMN IF EXISTS [MessagesRejected];
GO

PRINT N''
PRINT N'Remove legacy calculation monitor column RequestTimestamp...'
ALTER TABLE [dbo].[Calculations] DROP COLUMN IF EXISTS [RequestTimestamp];
GO

PRINT N''
PRINT N'Remove legacy calculation monitor column StartTimestamp...'
ALTER TABLE [dbo].[Calculations] DROP COLUMN IF EXISTS [StartTimestamp];
GO

PRINT N''
PRINT N'Remove legacy calculation monitor column EndTimestamp...'
ALTER TABLE [dbo].[Calculations] DROP COLUMN IF EXISTS [EndTimestamp];
GO