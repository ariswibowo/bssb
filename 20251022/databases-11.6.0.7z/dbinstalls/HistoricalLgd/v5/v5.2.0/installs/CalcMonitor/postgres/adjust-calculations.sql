\echo ''
\echo 'Remove legacy calculation monitor column MessagesExpected...'
ALTER TABLE "Calculations" DROP COLUMN IF EXISTS "MessagesExpected";

\echo ''
\echo 'Remove legacy calculation monitor column MessagesLoaded...'
ALTER TABLE "Calculations" DROP COLUMN IF EXISTS "MessagesLoaded";

\echo ''
\echo 'Remove legacy calculation monitor column MessagesProcessed...'
ALTER TABLE "Calculations" DROP COLUMN IF EXISTS "MessagesProcessed";

\echo ''
\echo 'Remove legacy calculation monitor column MessagesRejected...'
ALTER TABLE "Calculations" DROP COLUMN IF EXISTS "MessagesRejected";

\echo ''
\echo 'Remove legacy calculation monitor column RequestTimestamp...'
ALTER TABLE "Calculations" DROP COLUMN IF EXISTS "RequestTimestamp";

\echo ''
\echo 'Remove legacy calculation monitor column StartTimestamp...'
ALTER TABLE "Calculations" DROP COLUMN IF EXISTS "StartTimestamp";

\echo ''
\echo 'Remove legacy calculation monitor column EndTimestamp...'
ALTER TABLE "Calculations" DROP COLUMN IF EXISTS "EndTimestamp";