\echo '';
\echo 'Dropping table CalculationEvents...';

DROP TABLE IF EXISTS "CalculationEvents";