\echo ''
\echo 'Installing Workflow Policy...';

DELETE
  FROM "CalculationPolicies"
 WHERE "PolicyType" = 'Workflow';

\copy "CalculationPolicies" FROM '{data}/CalcMonitor-WorkflowPolicy.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;