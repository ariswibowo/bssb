PRINT N'';
PRINT N'Dropping table CalculationEvents...';

DROP TABLE IF EXISTS [dbo].[CalculationEvents];