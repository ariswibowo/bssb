PRINT N''
PRINT N'Installing Workflow Policy...'
GO

DELETE
  FROM [dbo].[CalculationPolicies]
 WHERE [PolicyType] = 'Workflow'
GO

BULK INSERT [dbo].[CalculationPolicies]
FROM '{data}/CalcMonitor-WorkflowPolicy.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO