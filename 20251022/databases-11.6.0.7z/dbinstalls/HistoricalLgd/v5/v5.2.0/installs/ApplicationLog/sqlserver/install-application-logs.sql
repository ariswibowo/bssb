PRINT N'';
PRINT N'Installing ApplicationLogs table...';
GO

PRINT N'';
PRINT N'Dropping ApplicationLogs table...';
DROP TABLE IF EXISTS [dbo].[ApplicationLogs];
GO

PRINT N'';
PRINT N'Creating ApplicationLogs table...';
CREATE TABLE [dbo].[ApplicationLogs] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [LogId] uniqueidentifier NOT NULL,
    [Origin] nvarchar(50) NOT NULL,
    [Logs] nvarchar(max) NOT NULL,
    [StartTimestamp] datetime NOT NULL,
    [EndTimestamp] datetime NULL,
);

ALTER TABLE [dbo].[ApplicationLogs] ADD CONSTRAINT [PK_ApplicationLogs] PRIMARY KEY ([Id]);

CREATE UNIQUE INDEX [IX_ApplicationLogs] ON [dbo].[ApplicationLogs]([LogId]);
GO