\echo '';
\echo 'Installing ApplicationLogs table...';

\echo '';
\echo 'Dropping ApplicationLogs table...';
DROP TABLE IF EXISTS "ApplicationLogs";
DROP SEQUENCE IF EXISTS "ApplicationLogs_Id_seq";

\echo '';
\echo 'Creating ApplicationLogs table...';

CREATE SEQUENCE "ApplicationLogs_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ApplicationLogs_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ApplicationLogs" (
    "Id" bigint DEFAULT nextval('"ApplicationLogs_Id_seq"'::regclass) NOT NULL,
    "LogId" uuid NOT NULL,
    "Origin" varchar(50) NULL,
    "Logs" text NOT NULL,
    "StartTimestamp" timestamp without time zone NOT NULL,
    "EndTimestamp" timestamp without time zone NULL
);

ALTER TABLE ONLY "ApplicationLogs" ADD CONSTRAINT "PK_ApplicationLogs" PRIMARY KEY ("Id");

CREATE UNIQUE INDEX "IX_ApplicationLogs" ON "ApplicationLogs" USING btree ("LogId");

ALTER TABLE "ApplicationLogs" OWNER TO "Empyrean";