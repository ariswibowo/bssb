# README

**RELEASE: HistoricalLgd V5.2.0**

## Release Features

- [Feature: Calc Monitor](#feature-calc-monitor)
- [Feature: Application Log](#feature-application-log)
- [Feature: Result Retention](#feature-result-retention)

## Feature: Calc Monitor

- Removes the CalculationEvents table
- Removes the MessagesExpected, MessagesLoaded, MessagesProcessed, MessagesRejected, RequestTimestamp, StartTimestamp, EndTimestamp columns from Calculations table
- Updates the Calculation Workflow Policy

[top](#readme)

## Feature: Application Log

- Install the ApplicationLogs table.

[top](#readme)

## Feature: Result Retention

- Add Result Retentions policy. The policy will be used in result retention process. It defines the configuration of result retention.
- Add RetentionCopied boolean column and set false as default value. This column wil be use to indicate whether the result is already copied to the other area.
- Add databaseName property to storage in calculation data to indicate the name of database that results are currently in. The databaseName property will be put initial value as "HistoricalLgd" since it it primary database for result retention.

[top](#readme)
