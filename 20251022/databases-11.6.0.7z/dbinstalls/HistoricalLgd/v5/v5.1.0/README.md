# README

**RELEASE: HistoricalLgd V5.1.0**

## Release Features

- [Feature: Calculation Logs](#feature-calculation-logs)

## Feature: Calculation Logs

Add new "Level" and "Source" column to CalculationLogs table

[top](#readme)