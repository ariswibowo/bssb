\echo '';
\echo 'Inserting data from CalculationLogs-INSTALLTMP to CalculationLogs...';

INSERT INTO "CalculationLogs" (
    "LogId",
    "CalculationId",
    "Timestamp",
    "Message", 
    "Level",
    "Source",
    "Data"
    ) 
    SELECT 
    "LogId",
    "CalculationId",
    "Timestamp",
    "Message",
    'Information',
    'CalculationMonitor',
    "Data"
    FROM "CalculationLogs-INSTALLTMP";