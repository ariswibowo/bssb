\echo '';
\echo 'Creating new CalculationLogs table with Level and Source column added...';

-- DROP INSTALLTMP table if exist to avoid conflict
DO $$
BEGIN 
	IF EXISTS (SELECT column_name FROM information_schema.columns WHERE table_name='CalculationLogs-INSTALLTMP') THEN
        -- Drop constraints and indexes from CalculationLogs-INSTALLTMP
        ALTER TABLE "CalculationLogs-INSTALLTMP" DROP CONSTRAINT "PK_CalculationLogs-INSTALLTMP";

        ALTER TABLE "CalculationLogs-INSTALLTMP" DROP CONSTRAINT "FK_CalculationLogs_Calculations_CalculationId-INSTALLTMP";

        DROP INDEX IF EXISTS "IX_CalculationLogs_CalculationId-INSTALLTMP";

        DROP TABLE "CalculationLogs-INSTALLTMP";
    END IF;
END $$;

-- Rename table
ALTER TABLE "CalculationLogs" RENAME TO "CalculationLogs-INSTALLTMP";

-- Rename constraint and index
ALTER TABLE "CalculationLogs-INSTALLTMP" RENAME CONSTRAINT "PK_CalculationLogs" TO "PK_CalculationLogs-INSTALLTMP";
ALTER TABLE "CalculationLogs-INSTALLTMP" RENAME CONSTRAINT "FK_CalculationLogs_Calculations_CalculationId" TO "FK_CalculationLogs_Calculations_CalculationId-INSTALLTMP";
ALTER INDEX "IX_CalculationLogs_CalculationId" RENAME TO "IX_CalculationLogs_CalculationId-INSTALLTMP";

-- Create new table
CREATE TABLE "CalculationLogs" (
    "LogId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL,
    "Message" text NOT NULL,
    "Level" varchar(50) NOT NULL,
    "Source" varchar(50) NOT NULL,
    "Data" text NULL
);

ALTER TABLE "CalculationLogs" OWNER to "Empyrean";

-- Add constraint and index to CalculationLogs
ALTER TABLE ONLY "CalculationLogs"
    ADD CONSTRAINT "PK_CalculationLogs" PRIMARY KEY ("LogId");

ALTER TABLE ONLY "CalculationLogs"
    ADD CONSTRAINT "FK_CalculationLogs_Calculations_CalculationId" FOREIGN KEY ("CalculationId") REFERENCES "Calculations"("CalculationId") ON DELETE CASCADE;

ALTER TABLE "CalculationLogs" OWNER TO "Empyrean";

CREATE INDEX "IX_CalculationLogs_CalculationId" ON "CalculationLogs" USING btree ("CalculationId");
