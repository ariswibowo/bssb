PRINT N'Dropping CalculationLogs-INSTALLTMP table...'
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'CalculationLogs-INSTALLTMP')
BEGIN
    -- Drop constraints and indexes from CalculationLogs-INSTALLTMP
    ALTER TABLE [dbo].[CalculationLogs-INSTALLTMP] DROP CONSTRAINT [PK_CalculationLogs-INSTALLTMP];
    
    ALTER TABLE [dbo].[CalculationLogs-INSTALLTMP] DROP CONSTRAINT [FK_CalculationLogs_Calculations_CalculationId-INSTALLTMP];

    DROP INDEX IF EXISTS [IX_CalculationLogs_CalculationId-INSTALLTMP] ON [dbo].[CalculationLogs-INSTALLTMP];

    DROP TABLE [dbo].[CalculationLogs-INSTALLTMP];
END
GO