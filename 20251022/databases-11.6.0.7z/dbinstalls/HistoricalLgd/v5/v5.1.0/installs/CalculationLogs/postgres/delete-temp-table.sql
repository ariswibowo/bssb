\echo 'Dropping CalculationLogs-INSTALLTMP table...'

DO $$
BEGIN 
	IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'CalculationLogs-INSTALLTMP') THEN
        -- Drop constraints and indexes from CalculationLogs-INSTALLTMP
        ALTER TABLE "CalculationLogs-INSTALLTMP" DROP CONSTRAINT "PK_CalculationLogs-INSTALLTMP";

        ALTER TABLE "CalculationLogs-INSTALLTMP" DROP CONSTRAINT "FK_CalculationLogs_Calculations_CalculationId-INSTALLTMP";

        DROP INDEX IF EXISTS "IX_CalculationLogs_CalculationId-INSTALLTMP";

        DROP TABLE "CalculationLogs-INSTALLTMP";
    END IF;
END $$;
