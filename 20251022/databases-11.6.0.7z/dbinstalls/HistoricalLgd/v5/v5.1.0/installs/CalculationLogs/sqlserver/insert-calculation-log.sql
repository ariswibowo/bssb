PRINT N'';
PRINT N'Inserting data from CalculationLogs-INSTALLTMP to CalculationLogs...';
GO

INSERT INTO [CalculationLogs] (
    [LogId],
    [CalculationId],
    [Timestamp],
    [Message], 
    [Level],
    [Source],
    [Data]
    ) 
    SELECT 
    [LogId],
    [CalculationId],
    [Timestamp],
    [Message],
    'Information',
    'CalculationMonitor',
    [Data]
    FROM [CalculationLogs-INSTALLTMP];
GO