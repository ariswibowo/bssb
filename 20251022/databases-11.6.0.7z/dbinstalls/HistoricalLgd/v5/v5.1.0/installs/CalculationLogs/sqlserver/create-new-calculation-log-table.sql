PRINT N''
PRINT N'Creating new CalculationLogs table with Level and Source column added...'
GO

-- DROP INSTALLTMP table if exist to avoid conflict
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'CalculationLogs-INSTALLTMP')
BEGIN
    -- Drop constraints and indexes from CalculationLogs-INSTALLTMP
    ALTER TABLE [dbo].[CalculationLogs-INSTALLTMP] DROP CONSTRAINT [PK_CalculationLogs-INSTALLTMP];
    
    ALTER TABLE [dbo].[CalculationLogs-INSTALLTMP] DROP CONSTRAINT [FK_CalculationLogs_Calculations_CalculationId-INSTALLTMP];

    DROP INDEX IF EXISTS [IX_CalculationLogs_CalculationId-INSTALLTMP] ON [dbo].[CalculationLogs-INSTALLTMP];

    DROP TABLE [dbo].[CalculationLogs-INSTALLTMP];
END
GO

-- Rename table
EXEC sp_rename 'CalculationLogs', 'CalculationLogs-INSTALLTMP';

-- Rename index
EXEC sp_rename N'[dbo].[CalculationLogs-INSTALLTMP].[PK_CalculationLogs]', N'PK_CalculationLogs-INSTALLTMP';
EXEC sp_rename N'[FK_CalculationLogs_Calculations_CalculationId]', N'FK_CalculationLogs_Calculations_CalculationId-INSTALLTMP';
EXEC sp_rename N'[dbo].[CalculationLogs-INSTALLTMP].[IX_CalculationLogs_CalculationId]', N'IX_CalculationLogs_CalculationId-INSTALLTMP';

-- Create new table
CREATE TABLE [dbo].[CalculationLogs] (
    [LogId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [Timestamp] datetime NOT NULL,
    [Message] nvarchar(max) NOT NULL,
    [Level] nvarchar(50) NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Data] nvarchar(max) NULL
);
GO

-- Add constraints and indexes to CalculationLogs
ALTER TABLE [dbo].[CalculationLogs] ADD CONSTRAINT [PK_CalculationLogs] PRIMARY KEY ([LogId]);
GO

ALTER TABLE [dbo].[CalculationLogs]
    ADD CONSTRAINT [FK_CalculationLogs_Calculations_CalculationId]
        FOREIGN KEY ([CalculationId])
        REFERENCES [dbo].[Calculations]([CalculationId]) ON DELETE CASCADE;
GO

CREATE INDEX [IX_CalculationLogs_CalculationId] ON [dbo].[CalculationLogs]([CalculationId]);
GO
