# README

**RELEASE: HistoricalLgd V7.1.0**

## Release Features

- [Feature: Model Conversion](#feature-model-conversion)

## Feature: Model Conversion

- Update Preflight Checks Policy to update the name of preflight configuration items.
- Migrate prop name in calculation data and checks from "Ruleset" to "Model".
- Migrate prop name in segment collection index data from SegmentRulesetVersionId to SegmentationVersionId.
- Migrate prop name in dashboard data for the ChainLadderLgdResult and the VintageLgdResult dashboard type.

[top](#readme)