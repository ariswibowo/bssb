import dbhelper
import os
import json


def main(config):

    # get migration settings info
    model_domain = getModelDomain()

    # get indexes
    indexes = getLocalItems(
        config, model_domain["tables"]["segmentCollectionIndex"])

    # do nothing if no indexes to migrate
    if len(indexes) == 0:
        return

    # convert indexes data
    converted_indexes = convertIndexes(indexes)

    # update indexes
    updateIndexes(converted_indexes, config)


def convertIndexes(indexes):
    converted_indexes = []

    # loop through indexes
    for index in indexes:
        has_changed = False

        # touch only when data present
        if index["Data"] is not None:
            # update data
            has_changed = updateIndexData(index["Data"])

        if has_changed:
            index["Data"] = json.dumps(index['Data'], separators=(',', ':')).replace("'", "''")

            converted_indexes.append(index)

    return converted_indexes


def updateIndexData(index_data):
    has_changed = False

    for segment in index_data:
        if "segmentRulesetVersionId" in segment:
            # get version Id
            version_id = segment["segmentRulesetVersionId"]
            # delete old version Id prop
            del segment["segmentRulesetVersionId"]
            # add new version Id prop
            segment["segmentationVersionId"] = version_id
            has_changed = True

    return has_changed


def updateIndexes(indexes, config):

    # generate build script file
    build = dbhelper.init_build("migrate-segment-collection-index-data", config)

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-segment-collection-index", config)

    for index in indexes:
        # construct update statement
        sql = update_sql.format(
            data=index["Data"],
            id=index["Id"]
        )

        # write to build file
        dbhelper.write_build(build, sql)

    # run build
    dbhelper.run_build(build, config)


def getLocalItems(config, table):
    # get local query
    sql = dbhelper.get_sql("get-local-items", config)
    sql = sql.format(table=table)

    # get local items
    data = dbhelper.run_sql(sql, config)
    localItemsList = data.fetchall()

    # get col names list
    cols = [column[0] for column in data.description]

    # convert list to a dictionary
    localItems = []
    for item in localItemsList:
        itemDict = dbhelper.get_row_dict(item, cols, ["Checks"])
        localItems.append(itemDict)

    dbhelper.dispose(data, config)

    return localItems


def getModelDomain():
    """ returns model domain dict"""

    # expected in current directory
    dmFile = os.path.join(os.path.dirname(
        os.path.realpath(__file__)), "modelDomain.json")

    # check file exists
    if not os.path.exists(dmFile):
        print("")
        print("Fatal: Model Domain file not found!")
        print("File: {file}".format(file=dmFile))
        exit(-1)

    # load domain
    with open(dmFile) as d:
        modelDomain = json.load(d)

    return modelDomain