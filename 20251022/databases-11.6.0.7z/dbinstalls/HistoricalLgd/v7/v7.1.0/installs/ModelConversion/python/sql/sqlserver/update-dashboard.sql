PRINT N''
PRINT N'Updating data for Dashboard: {dashboardId}...'
GO

UPDATE [dbo].[Dashboards]
   SET [Data] = '{data}'
 WHERE [DashboardId] = '{dashboardId}';
GO