import dbhelper
import dbpolicies
import os
import json


def main(config):

    dbpolicies.updatePolicy(table="CalculationPolicies",
                            type="PreflightChecks",
                            config=config,
                            updatefunc=updateConfigurationItemName)
    return


def updateConfigurationItemName(policy, context):
    # get migration settings info
    model_domain = getModelDomain()

    preflight_check_items = model_domain["preflightCheckConfigurationItems"]

    if "preflightChecks" in policy and policy["preflightChecks"] is not None:
        # loop through policy preflight checks
        for preflight_check in policy["preflightChecks"]:

            # lookup preflight check item
            preflight_check_item = next(
                filter(lambda r: r["oldCheck"] == preflight_check["check"], preflight_check_items), None)

            if preflight_check_item is not None:
                preflight_check["check"] = preflight_check_item["newCheck"]

    return policy


def getLocalItems(config, table):
    # get local query
    sql = dbhelper.get_sql("get-local-items", config)
    sql = sql.format(table=table)

    # get local items
    data = dbhelper.run_sql(sql, config)
    localItemsList = data.fetchall()

    # get col names list
    cols = [column[0] for column in data.description]

    # convert list to a dictionary
    localItems = []
    for item in localItemsList:
        itemDict = dbhelper.get_row_dict(item, cols)
        localItems.append(itemDict)

    dbhelper.dispose(data, config)

    return localItems


def getModelDomain():
    """ returns model domain dict"""

    # expected in current directory
    dmFile = os.path.join(os.path.dirname(
        os.path.realpath(__file__)), "modelDomain.json")

    # check file exists
    if not os.path.exists(dmFile):
        print("")
        print("Fatal: Model Domain file not found!")
        print("File: {file}".format(file=dmFile))
        exit(-1)

    # load domain
    with open(dmFile) as d:
        modelDomain = json.load(d)

    return modelDomain