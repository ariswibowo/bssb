PRINT N''
PRINT N'Updating data for SegmentCollectionIndex: {id}...'
GO

UPDATE [dbo].[SegmentCollectionIndex]
   SET [Data] = '{data}'
 WHERE [Id] = '{id}';
GO