\echo ''
\echo 'Updating data and checks for CalculationId: {calculationId}...'

UPDATE "Calculations"
   SET "Data" = '{data}',
       "Checks" = '{checks}'
 WHERE "CalculationId" = '{calculationId}';