import dbhelper
import os
import json


def main(config):

    # get migration settings info
    model_domain = getModelDomain()

    # get dashboards
    dashboards = getLocalItems(
        config, model_domain["tables"]["dashboards"], model_domain)

    # do nothing if no dashboards to migrate
    if len(dashboards) == 0:
        return

    # convert dashboards
    converted_dashboards = convertDashboards(dashboards, model_domain)

    # update dashboards data
    updateDashboards(converted_dashboards, config)


def convertDashboards(dashboards, model_domain):
    converted_dashboards = []

    # loop through dashboards
    for dashboard in dashboards:
        has_changed = False

        # touch only when data present
        if dashboard["Data"] is not None:
            dashboardDataStr = json.dumps(dashboard["Data"], separators=(',', ':')).replace("'", "''")

            if "chainLadderParameters" in dashboardDataStr: 
                # replace word
                dashboard["Data"] = dashboardDataStr.replace("chainLadderParameters","observation")
                has_changed = True

            if "vintageParameters" in dashboardDataStr: 
                # replace word
                dashboard["Data"] = dashboardDataStr.replace("vintageParameters","observation")
                has_changed = True

        if has_changed:
            converted_dashboards.append(dashboard)

    return converted_dashboards


def updateDashboards(dashboards, config):

    # generate build script file
    build = dbhelper.init_build("migrate-dashboards-data", config)

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-dashboard", config)

    for dashboard in dashboards:
        # construct update statement
        sql = update_sql.format(
            data=dashboard["Data"],
            dashboardId=dashboard["DashboardId"]
        )

        # write to build file
        dbhelper.write_build(build, sql)

    # run build
    dbhelper.run_build(build, config)


def getLocalItems(config, table, model_domain):
    # get local query
    sql = dbhelper.get_sql("get-local-items", config)
    sql = sql.format(table=table)

    # get local items
    data = dbhelper.run_sql(sql, config)
    localItemsList = data.fetchall()

    # get col names list
    cols = [column[0] for column in data.description]

    # convert list to a dictionary
    localItems = []
    for item in localItemsList:
        itemDict = dbhelper.get_row_dict(item, cols)
        localItems.append(itemDict)

    dbhelper.dispose(data, config)

    # filter dashboards for relevant dashboard type
    localItems = list(filter(lambda o: uuidStr(o["DashboardTypeId"]) == model_domain["dashboardTypes"]["chainLadderLgdResult"]
        or uuidStr(o["DashboardTypeId"]) == model_domain["dashboardTypes"]["vintageLgdResult"], localItems))

    return localItems


def getModelDomain():
    """ returns model domain dict"""

    # expected in current directory
    dmFile = os.path.join(os.path.dirname(
        os.path.realpath(__file__)), "modelDomain.json")

    # check file exists
    if not os.path.exists(dmFile):
        print("")
        print("Fatal: Model Domain file not found!")
        print("File: {file}".format(file=dmFile))
        exit(-1)

    # load domain
    with open(dmFile) as d:
        modelDomain = json.load(d)

    return modelDomain


def uuidStr(uuid):
    return str(uuid).lower()