\echo ''
\echo 'Updating data for SegmentCollectionIndex: {id}...'

UPDATE "SegmentCollectionIndex"
   SET "Data" = '{data}'
 WHERE "Id" = '{id}';