PRINT N''
PRINT N'Updating data and checks for CalculationId: {calculationId}...'
GO

UPDATE [dbo].[Calculations]
   SET [Data] = '{data}',
       [Checks] = '{checks}'
 WHERE [CalculationId] = '{calculationId}';
GO