import dbhelper
import os
import json


def main(config):

    # get migration settings info
    model_domain = getModelDomain()

    # get calculations
    calculations = getLocalItems(
        config, model_domain["tables"]["calculations"])

    # do nothing if no calculations to migrate
    if len(calculations) == 0:
        return

    # convert calculations
    converted_calculations = convertCalculations(calculations, model_domain)

    # update calculation data and checks
    updateCalculations(converted_calculations, config)


def convertCalculations(calculations, model_domain):
    converted_calculations = []

    # loop through calculations
    for calculation in calculations:
        has_changed = False

        # touch only when data present
        if calculation["Data"] is not None:
            # update data versions
            has_changed = updateCalculationData(calculation["Data"], "versions", model_domain)
            # update data segmentationRulesets
            has_changed = updateCalculationData(calculation["Data"], "segmentationRulesets", model_domain) or has_changed

        # touch only when data present
        if calculation["Checks"] is not None:
            # update checks
            has_changed = updateCalculationChecks(calculation['Checks'], model_domain["preflightCheckConfigurationItems"]) or has_changed

        if has_changed:
            calculation["Data"] = json.dumps(calculation['Data'], separators=(',', ':')).replace("'", "''")
            calculation["Checks"] = json.dumps(calculation['Checks'], separators=(',', ':')).replace("'", "''")

            converted_calculations.append(calculation)

    return converted_calculations


def updateCalculationData(calculation_data, section, model_domain):
    has_changed = False

    if section in calculation_data:
        for version_id_prop in model_domain["versionIdProps"]:
            old_prop_name = version_id_prop["oldPropName"]
            new_prop_name = version_id_prop["newPropName"]

            if old_prop_name in calculation_data[section]:
                # get version Id
                version_id = calculation_data[section][old_prop_name]
                # delete old version Id prop
                del calculation_data[section][old_prop_name]
                # add new version Id prop
                calculation_data[section][new_prop_name] = version_id
                has_changed = True

        if section == "segmentationRulesets":
            calculation_data["segmentationModels"] = calculation_data["segmentationRulesets"]
            calculation_data.pop("segmentationRulesets", None)
            has_changed = True

    return has_changed


def updateCalculationChecks(calculation_checks, preflight_check_items):
    has_changed = False
    
    if 'preflightCheckResults' in calculation_checks and calculation_checks['preflightCheckResults'] is not None:
        # loop through preflight check results
        for preflight_check_result in calculation_checks['preflightCheckResults']:
            # lookup preflight check item
            preflight_check_item = next(
                filter(lambda r: r["oldCheck"] == preflight_check_result["check"], preflight_check_items), None)

            if preflight_check_item is not None:
                preflight_check_result["check"] = preflight_check_item["newCheck"]
                has_changed = True

    return has_changed


def updateCalculations(calculations, config):

    # generate build script file
    build = dbhelper.init_build("migrate-calc-data-and-checks", config)

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-calculation", config)

    for calculation in calculations:
        # construct update statement
        sql = update_sql.format(
            data=calculation["Data"],
            checks=calculation["Checks"],
            calculationId=calculation["CalculationId"]
        )

        # write to build file
        dbhelper.write_build(build, sql)

    # run build
    dbhelper.run_build(build, config)


def getLocalItems(config, table):
    # get local query
    sql = dbhelper.get_sql("get-local-items", config)
    sql = sql.format(table=table)

    # get local items
    data = dbhelper.run_sql(sql, config)
    localItemsList = data.fetchall()

    # get col names list
    cols = [column[0] for column in data.description]

    # convert list to a dictionary
    localItems = []
    for item in localItemsList:
        itemDict = dbhelper.get_row_dict(item, cols, ["Checks"])
        localItems.append(itemDict)

    dbhelper.dispose(data, config)

    return localItems


def getModelDomain():
    """ returns model domain dict"""

    # expected in current directory
    dmFile = os.path.join(os.path.dirname(
        os.path.realpath(__file__)), "modelDomain.json")

    # check file exists
    if not os.path.exists(dmFile):
        print("")
        print("Fatal: Model Domain file not found!")
        print("File: {file}".format(file=dmFile))
        exit(-1)

    # load domain
    with open(dmFile) as d:
        modelDomain = json.load(d)

    return modelDomain