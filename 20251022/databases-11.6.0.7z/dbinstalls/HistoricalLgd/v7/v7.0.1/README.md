# README

**RELEASE: HistoricalLgd V7.0.1**

## Release Fixes

- [Hotfix: Collateralized Chain Ladder](#hotfix-collateralized-chain-ladder)

## Hotfix: Collateralized Chain Ladder

- Separate dashboard-type deeper by delete 2 old dashboard types and add 24 new dashboard types

[top](#readme)