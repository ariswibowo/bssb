\echo ''
\echo 'Installing new DashboardTypes...';

DELETE
  FROM "DashboardTypes"
 WHERE "DashboardType" IN (
     'CollateralizedChainLadderLgdResult',
     'CollateralizedChainLadderLgdExtract',
     'CCLSummary',
     'CCLLgd',
     'CCLConsolidationDetails',
     'CCLUnsecuredRate',
     'CCLUnsecuredRecoveries',
     'CCLUnsecuredDiscountedRecoveries',
     'CCLUnsecuredCumulativeDiscountedRecoveries',
     'CCLUnsecuredCappedCumulativeDiscountedRecoveries',
     'CCLUnsecuredPercentRecoveries',
     'CCLUnsecuredDevelopmentFactors',
     'CCLUnsecuredOutlierAnalysis',
     'CCLUnsecuredDevelopmentFactorOutliers',
     'CCLUnsecuredAverageDevelopmentFactors',
     'CCLUnsecuredProjectPercentRecoveries',
     'CCLUnsecuredDiscountRates',
     'CCLSecuredRate',
     'CCLSecuredRecoveries',
     'CCLSecuredDiscountRates',
     'CCLDirectCostRate',
     'CCLDirectCosts',
     'CCLDirectCostDiscountRates'
 );

\copy "DashboardTypes" FROM '{data}/CollateralizedChainLadder/DashboardTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;