# README

## Release: HistoricalLgd v7.0.0 (upgrade)

No upgrades required.
