# README

**RELEASE: HistoricalLgd V6.2.0**

## Release Features

- [Feature: Chain Ladder LGD Discounting Rounding](#feature-chain-ladder-lgd-discounting-rounding)

## Feature: Chain Ladder LGD Discounting Rounding

The consolidator no longer calculates averaged discount rate increments before applying these results to the database. Instead, the averaging solely happens on database level, thereby avoiding potential rounding differences. For this to work, a new TotalDiscountRate column is added to ResultConsolidatedChainLadderDiscountRates.

[top](#readme)
