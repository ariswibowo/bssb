PRINT N''
PRINT N'Altering ResultConsolidatedChainLadderDiscountRates...'
GO

PRINT N''
PRINT N'Creating install backup table...'
EXEC sp_rename '[dbo].[ResultConsolidatedChainLadderDiscountRates]', 'ResultConsolidatedChainLadderDiscountRates-INSTALLTMP';
GO

PRINT N''
PRINT N'Creating new table with TotalDiscountRate column...'
CREATE TABLE [dbo].[ResultConsolidatedChainLadderDiscountRates] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [CalculationMethod] nvarchar(100) NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [Base] numeric(20,2) NOT NULL,
    [DiscountRate] numeric(12,9) NOT NULL,
    [TotalDiscountRate] numeric(32,9) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

PRINT N'Repopulating data from backup...'
SET IDENTITY_INSERT [dbo].[ResultConsolidatedChainLadderDiscountRates] ON;
GO

INSERT INTO [dbo].[ResultConsolidatedChainLadderDiscountRates]
(
    [Id],
    [ConsolidatedChainLadderId],
    [DefaultDate],
    [CalculationMethod],
    [HashCode],
    [Base],
    [DiscountRate],
    [TotalDiscountRate],
    [RetentionCopied]
)
SELECT
    [Id],
    [ConsolidatedChainLadderId],
    [DefaultDate],
    [CalculationMethod],
    [HashCode],
    [Base],
    [DiscountRate],
    [Base] * [DiscountRate] AS [TotalDiscountRate],
    [RetentionCopied]
FROM [dbo].[ResultConsolidatedChainLadderDiscountRates-INSTALLTMP];
GO

SET IDENTITY_INSERT [dbo].[ResultConsolidatedChainLadderDiscountRates] OFF ;
GO

PRINT N''
PRINT N'Reseeding Identity column...'
DECLARE @maxId bigint;
SELECT @maxId = ISNULL(max([Id]),1) FROM [dbo].[ResultConsolidatedChainLadderDiscountRates];
DBCC CHECKIDENT('[dbo].[ResultConsolidatedChainLadderDiscountRates]', RESEED, @maxId);
GO

PRINT N''
PRINT N'Dropping legacy constraints/indexes...'
ALTER TABLE [dbo].[ResultConsolidatedChainLadderDiscountRates-INSTALLTMP] DROP CONSTRAINT IF EXISTS [PK_ResultConsolidatedChainLadderDiscountRates];
GO
DROP INDEX IF EXISTS [IX_ResultConsolidatedChainLadderDiscountRates_HashCode] ON [dbo].[ResultConsolidatedChainLadderDiscountRates-INSTALLTMP];
GO

PRINT N''
PRINT N'Recreating constraints/indexes...'
ALTER TABLE [dbo].[ResultConsolidatedChainLadderDiscountRates]
    ADD CONSTRAINT [PK_ResultConsolidatedChainLadderDiscountRates] PRIMARY KEY ([Id]);
GO
CREATE UNIQUE INDEX [IX_ResultConsolidatedChainLadderDiscountRates_HashCode] ON [dbo].[ResultConsolidatedChainLadderDiscountRates]([HashCode]);
GO

PRINT N''
PRINT N'Dropping work table...'
DROP TABLE [dbo].[ResultConsolidatedChainLadderDiscountRates-INSTALLTMP];
GO
