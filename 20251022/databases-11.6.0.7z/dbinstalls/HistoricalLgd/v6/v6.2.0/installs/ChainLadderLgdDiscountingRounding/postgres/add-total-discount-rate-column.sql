\echo '';
\echo 'Altering ResultConsolidatedChainLadderDiscountRates...';

\echo '';
\echo 'Creating install backup table...';
ALTER TABLE "ResultConsolidatedChainLadderDiscountRates" RENAME TO "ResultConsolidatedChainLadderDiscountRates-INSTALLTMP";

\echo '';
\echo 'Creating new table with TotalDiscountRate column...';
CREATE TABLE "ResultConsolidatedChainLadderDiscountRates" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedChainLadderDiscountRates_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "CalculationMethod" varchar(100),
    "HashCode" varchar(256),
    "Base" numeric(20, 2) NOT NULL,
    "DiscountRate" numeric(12, 9) NOT NULL,
    "TotalDiscountRate" numeric(32, 9) NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

\echo 'Repopulating data from backup...';
INSERT INTO "ResultConsolidatedChainLadderDiscountRates"
(
    "Id",
    "ConsolidatedChainLadderId",
    "DefaultDate",
    "CalculationMethod",
    "HashCode",
    "Base", 
    "DiscountRate",
    "TotalDiscountRate",
    "RetentionCopied"
)
SELECT
    "Id",
    "ConsolidatedChainLadderId",
    "DefaultDate",
    "CalculationMethod",
    "HashCode",
    "Base", 
    "DiscountRate",
    "Base" * "DiscountRate" AS "TotalDiscountRate",
    "RetentionCopied"
FROM "ResultConsolidatedChainLadderDiscountRates-INSTALLTMP";

\echo '';
\echo 'Dropping legacy constraints/indexes...';
ALTER TABLE "ResultConsolidatedChainLadderDiscountRates-INSTALLTMP" DROP CONSTRAINT IF EXISTS "PK_ResultConsolidatedChainLadderDiscountRates";
DROP INDEX IF EXISTS "IX_ResultConsolidatedChainLadderDiscountRates_HashCode";

\echo '';
\echo 'Recreating constraints/indexes...';
ALTER TABLE ONLY "ResultConsolidatedChainLadderDiscountRates"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadderDiscountRates" PRIMARY KEY ("Id");

ALTER TABLE "ResultConsolidatedChainLadderDiscountRates" OWNER TO "Elysian";

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadderDiscountRates_HashCode" ON "ResultConsolidatedChainLadderDiscountRates" USING btree ("HashCode");

\echo '';
\echo 'Dropping work table...';
DROP TABLE "ResultConsolidatedChainLadderDiscountRates-INSTALLTMP";
