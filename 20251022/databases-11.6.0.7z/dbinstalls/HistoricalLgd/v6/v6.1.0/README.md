# README

**RELEASE: HistoricalLgd V6.1.0**

## Release Features

- [Feature: Chain Ladder LGD Discounting](#feature-chain-ladder-lgd-discounting)
- [Feature: General Policy](#feature-general-policy)

## Feature: Chain Ladder LGD Discounting

The new discounting feature in the Chain Ladder LGD calculation requires the following changes:

- a new ResultConsolidatedChainLadderDiscountRates table stores the discount rates by segment and first default date
- the DiscountedDebtSales column in the ResultChainLadders table is no longer relevant and is replaced by DiscountRate

[top](#readme)

## Feature: General Policy

Adds an initial version of the General calculation policy.

[top](#readme)
