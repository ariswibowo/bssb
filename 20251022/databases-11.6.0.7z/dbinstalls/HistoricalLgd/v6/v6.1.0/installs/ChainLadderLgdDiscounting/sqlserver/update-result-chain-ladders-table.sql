PRINT N''
PRINT N'Setting all discounted Debt Sales values to 0...'
GO

UPDATE [dbo].[ResultChainLadders]
   SET [DiscountedDebtSalesAmount] = 0.0;
GO

PRINT N''
PRINT N'Renaming column DiscountedDebtSalesAmount to DicountRate...'
GO

EXEC sp_rename '[dbo].[ResultChainLadders].[DiscountedDebtSalesAmount]', 'DiscountRate', 'COLUMN';
GO

PRINT N''
PRINT N'Updating DiscountRate column data type...'
GO

ALTER TABLE [dbo].[ResultChainLadders]
ALTER COLUMN [DiscountRate] numeric(12,9) NULL;