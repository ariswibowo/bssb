\echo ''
\echo 'Setting all discounted Debt Sales values to 0...';

UPDATE "ResultChainLadders"
SET "DiscountedDebtSalesAmount" = 0.0;

\echo ''
\echo 'Renaming column DiscountedDebtSalesAmount to DicountRate...';

ALTER TABLE "ResultChainLadders"
RENAME COLUMN "DiscountedDebtSalesAmount" TO "DiscountRate";

\echo ''
\echo 'Updating DiscountRate column data type...';

ALTER TABLE "ResultChainLadders"
ALTER COLUMN "DiscountRate" TYPE numeric(12,9);

\echo ''
\echo 'Make DiscountRate column nullable...';

ALTER TABLE "ResultChainLadders"
ALTER COLUMN "DiscountRate" DROP NOT NULL;