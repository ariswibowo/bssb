DROP TABLE IF EXISTS [dbo].[ResultConsolidatedChainLadderDiscountRates];

CREATE TABLE [dbo].[ResultConsolidatedChainLadderDiscountRates] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [CalculationMethod] nvarchar(100) NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [Base] numeric(20,2) NOT NULL,
    [DiscountRate] numeric(12,9) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedChainLadderDiscountRates] ADD CONSTRAINT [PK_ResultConsolidatedChainLadderDiscountRates] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedChainLadderDiscountRates_HashCode] ON [dbo].[ResultConsolidatedChainLadderDiscountRates]([HashCode]);
GO