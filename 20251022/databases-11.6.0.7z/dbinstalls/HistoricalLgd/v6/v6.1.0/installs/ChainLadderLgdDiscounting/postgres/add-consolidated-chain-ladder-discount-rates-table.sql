DROP TABLE IF EXISTS "ResultConsolidatedChainLadderDiscountRates";
DROP SEQUENCE IF EXISTS "ResultConsolidatedChainLadderDiscountRates_Id_seq";

CREATE SEQUENCE "ResultConsolidatedChainLadderDiscountRates_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedChainLadderDiscountRates_Id_seq" OWNER TO "Elysian";

CREATE TABLE "ResultConsolidatedChainLadderDiscountRates" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedChainLadderDiscountRates_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "CalculationMethod" varchar(100),
    "HashCode" varchar(256),
    "Base" numeric(20, 2) NOT NULL,
    "DiscountRate" numeric(12, 9) NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultConsolidatedChainLadderDiscountRates"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadderDiscountRates" PRIMARY KEY ("Id");

ALTER TABLE "ResultConsolidatedChainLadderDiscountRates" OWNER TO "Elysian";

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadderDiscountRates_HashCode" ON "ResultConsolidatedChainLadderDiscountRates" USING btree ("HashCode");