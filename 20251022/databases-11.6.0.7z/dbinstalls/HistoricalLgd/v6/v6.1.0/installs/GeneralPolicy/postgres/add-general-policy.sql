\echo ''
\echo 'Installing General Policy...';

DELETE
  FROM "CalculationPolicies"
 WHERE "PolicyType" = 'General';

\copy "CalculationPolicies" FROM '{data}/GeneralPolicy-CalculationPolicies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;