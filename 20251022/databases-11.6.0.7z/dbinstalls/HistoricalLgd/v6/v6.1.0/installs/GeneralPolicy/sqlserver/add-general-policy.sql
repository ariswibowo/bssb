PRINT N''
PRINT N'Installing General Policy...'
GO

DELETE
  FROM [dbo].[CalculationPolicies]
 WHERE [PolicyType] = 'General'
GO

BULK INSERT [dbo].[CalculationPolicies]
FROM '{data}/GeneralPolicy-CalculationPolicies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO