# README

**RELEASE: HistoricalLgd V6.3.0**

## Release Features

- [Feature: Compression](#feature-compression)
- [Feature: Collateralized Chain Ladder](#feature-collateralized-chain-ladder)
- [Feature: Calculation Props](#feature-calculation-props)
- [Feature: CalculationMonitoring](#feature-calculation-monitoring)

## Feature: Compression

The system now supports the compression of calculation results for all Basel calculation objective types, through the configuration of the Storage policy.

For this, table ResultContracts is extended with a BData binary column and the Result column is made nullable.

[top](#readme)

## Feature: Collateralized Chain Ladder

- Add new 2 dashboard types, CollateralizedChainLadderLgdResult and CollateralizedChainLadderLgdExtract
- Add new 5 tables for the CollateralizedChainLadder method calculation results
  - ResultConsolidatedCollateralizedChainLadderDefinitions
  - ResultConsolidatedCollateralizedChainLadders
  - ResultConsolidatedCollateralizedChainLadderDiscountRates
  - ResultConsolidatedCollateralizedChainLadderRecoveries
  - ResultCollateralizedChainLadder

[top](#readme)

## Feature: Calculation Props

Adds a new table called CalculationProps which will hold calculation related data through key-based properties.

[top](#readme)

## Feature: Calculation Monitoring

Update the Calculation workflow policy to include new configuration on monitoring the calculation
- added "StallMonitoring" configuration on salculation state level
- added "TaskProgress" stall monitoring behavior to DataLoading task

[top](#readme)