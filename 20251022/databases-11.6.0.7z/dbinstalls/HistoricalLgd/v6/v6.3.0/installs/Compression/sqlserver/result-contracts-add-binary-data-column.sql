PRINT N''
PRINT N'Altering table ResultContracts...'
GO

PRINT N''
PRINT N'Checking if binary Data column already exists...'
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'ResultContracts' AND COLUMN_NAME = 'BData')
BEGIN

    PRINT N''
    PRINT N'Making Result column nullable...'

    ALTER TABLE [dbo].[ResultContracts] ALTER COLUMN [Result] nvarchar(max) NULL;

    PRINT N''
    PRINT N'Adding binary Data column...'

    ALTER TABLE [dbo].[ResultContracts] ADD [BData] varbinary(max) NULL;

END

PRINT N''
PRINT N'Table ResultContracts up-to-date...'
GO