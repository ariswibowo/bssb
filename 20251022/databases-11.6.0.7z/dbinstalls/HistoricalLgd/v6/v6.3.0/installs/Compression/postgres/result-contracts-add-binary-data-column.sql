\echo '';
\echo 'Altering table ResultContracts...';

\echo '';
\echo 'Making Result column nullable...';

ALTER TABLE "ResultContracts" ALTER COLUMN "Result" DROP NOT NULL;

\echo '';
\echo 'Adding binary Data column...';

ALTER TABLE "ResultContracts" ADD COLUMN IF NOT EXISTS "BData" bytea NULL;
