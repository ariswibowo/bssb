\echo '';
\echo 'Installing Result Consolidated Collateralized Chain Ladder Definitions...';

DROP TABLE IF EXISTS "ResultConsolidatedCollateralizedChainLadderDefinitions";
DROP SEQUENCE IF EXISTS "ResultConsolidatedCollateralizedChainLadderDefinitions_Id_seq";

\echo '';
\echo 'Creating sequence ResultConsolidatedCollateralizedChainLadderDefinitions_Id_seq...';

CREATE SEQUENCE "ResultConsolidatedCollateralizedChainLadderDefinitions_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedCollateralizedChainLadderDefinitions_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultConsolidatedCollateralizedChainLadderDefinitions...';

CREATE TABLE "ResultConsolidatedCollateralizedChainLadderDefinitions" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedCollateralizedChainLadderDefinitions_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedCollateralizedChainLadderId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "SegmentId" uuid NOT NULL,
    "SegmentName" varchar(100) NOT NULL,
    "Unsecured"  numeric(12, 9) NOT NULL,
    "Secured"  numeric(12, 9) NOT NULL,
    "DirectCost"  numeric(12, 9) NOT NULL,
    "Lgd"  numeric(12, 9) NOT NULL,
    "Data" text NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);      

ALTER TABLE ONLY "ResultConsolidatedCollateralizedChainLadderDefinitions"
    ADD CONSTRAINT "PK_ResultConsolidatedCollateralizedChainLadderDefinitions" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultConsolidatedCollateralizedChainLadderDefinitions_CalcId_SegmentId" 
    ON "ResultConsolidatedCollateralizedChainLadderDefinitions" USING btree ("CalculationId", "SegmentId");

ALTER TABLE "ResultConsolidatedCollateralizedChainLadderDefinitions" OWNER TO "Elysian";