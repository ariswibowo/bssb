PRINT N'';
PRINT N'Installing Result Consolidated Collateralized Chain Ladder DiscountRates...';
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedCollateralizedChainLadderDiscountRates];
GO

PRINT N'';
PRINT N'Creating table ResultConsolidatedCollateralizedChainLadderDiscountRates...';
GO

CREATE TABLE [dbo].[ResultConsolidatedCollateralizedChainLadderDiscountRates] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedCollateralizedChainLadderId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [DiscountType] nvarchar(100) NOT NULL,
    [CalculationMethod] nvarchar(100) NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [Base] numeric(20, 2) NOT NULL,
    [DiscountRate] numeric(12, 9) NOT NULL,
    [TotalDiscountRate] numeric(32, 9) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedCollateralizedChainLadderDiscountRates]
    ADD CONSTRAINT [PK_ResultConsolidatedCollateralizedChainLadderDiscountRates] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedCollateralizedChainLadderDiscountRates_HashCode]
    ON [dbo].[ResultConsolidatedCollateralizedChainLadderDiscountRates]([HashCode]);
GO