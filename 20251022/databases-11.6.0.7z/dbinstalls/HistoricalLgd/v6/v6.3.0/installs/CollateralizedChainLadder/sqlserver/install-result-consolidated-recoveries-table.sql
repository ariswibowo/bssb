PRINT N'';
PRINT N'Installing Result Consolidated Collateralized Chain Ladder Recoveries...';
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedCollateralizedChainLadderRecoveries];
GO

PRINT N'';
PRINT N'Creating table ResultConsolidatedCollateralizedChainLadderRecoveries...';
GO

CREATE TABLE [dbo].[ResultConsolidatedCollateralizedChainLadderRecoveries] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedCollateralizedChainLadderId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [RecoveryDate] datetime NOT NULL,
    [RecoveryType] nvarchar(50) NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [RecoveryAmount] numeric(20, 2) NOT NULL,
    [DiscountedRecoveryAmount] numeric(20, 2) NOT NULL,
    [CumulativeDiscountedRecoveryAmount] numeric(20, 2) NOT NULL,
    [CappedCumulativeDiscountedRecoveryAmount] numeric(20, 2) NOT NULL,
    [PercentRecovery] numeric(12, 9),
    [IsProjected] bit NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedCollateralizedChainLadderRecoveries]
    ADD CONSTRAINT [PK_ResultConsolidatedCollateralizedChainLadderRecoveries] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedCollateralizedChainLadderRecoveries_HashCode]
    ON [dbo].[ResultConsolidatedCollateralizedChainLadderRecoveries]([HashCode]);
GO