\echo '';
\echo 'Installing Result Consolidated Collateralized Chain Ladders...';

DROP TABLE IF EXISTS "ResultConsolidatedCollateralizedChainLadders";
DROP SEQUENCE IF EXISTS "ResultConsolidatedCollateralizedChainLadders_Id_seq";

\echo '';
\echo 'Creating sequence ResultConsolidatedCollateralizedChainLadders_Id_seq...';

CREATE SEQUENCE "ResultConsolidatedCollateralizedChainLadders_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedCollateralizedChainLadders_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultConsolidatedCollateralizedChainLadders...';

CREATE TABLE "ResultConsolidatedCollateralizedChainLadders" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedCollateralizedChainLadders_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedCollateralizedChainLadderId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "HashCode" varchar(256) NOT NULL,
    "NumContracts" integer NOT NULL,
    "UnsecuredNumContracts" integer NOT NULL,
    "SecuredNumContracts" integer NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "UnsecuredOutstandingAmount" numeric(20, 2) NOT NULL,
    "SecuredOutstandingAmount" numeric(20, 2) NOT NULL,
    "UnsecuredDiscountRate" numeric(12, 9),
    "SecuredPVActualRecovery" numeric(20, 2) NOT NULL,
    "SecuredOutstandingAfterPVActualRecovery" numeric(20, 2) NOT NULL,
    "SecuredCollateralSaleValue" numeric(20, 2) NOT NULL,
    "SecuredDiscountRate" numeric(12, 9),
    "SecuredPVCollateralSale" numeric(20, 2) NOT NULL,
    "SecuredCappedPVCollateral" numeric(20, 2) NOT NULL,
    "Data" text NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultConsolidatedCollateralizedChainLadders"
    ADD CONSTRAINT "PK_ResultConsolidatedCollateralizedChainLadders" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultConsolidatedCollateralizedChainLadders_HashCode"
    ON "ResultConsolidatedCollateralizedChainLadders" USING btree ("HashCode");

ALTER TABLE "ResultConsolidatedCollateralizedChainLadders" OWNER TO "Elysian";