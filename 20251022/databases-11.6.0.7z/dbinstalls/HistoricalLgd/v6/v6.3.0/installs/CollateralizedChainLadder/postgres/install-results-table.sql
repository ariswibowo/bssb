\echo '';
\echo 'Installing Result Collateralized Chain Ladders...';

DROP TABLE IF EXISTS "ResultCollateralizedChainLadders";
DROP SEQUENCE IF EXISTS "ResultCollateralizedChainLadders_Id_seq";

\echo '';
\echo 'Creating sequence ResultCollateralizedChainLadders_Id_seq...';

CREATE SEQUENCE "ResultCollateralizedChainLadders_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultCollateralizedChainLadders_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultCollateralizedChainLadders...';

CREATE TABLE "ResultCollateralizedChainLadders" (
    "Id" bigint DEFAULT nextval('"ResultCollateralizedChainLadders_Id_seq"'::regclass) NOT NULL,
    "ResultId" uuid NOT NULL,
    "HashCode" varchar(256) NOT NULL,
    "SegmentId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "UnsecuredOutstandingAmount" numeric(20, 2) NOT NULL,
    "SecuredOutstandingAmount" numeric(20, 2) NOT NULL,
    "DiscountRate" numeric(12, 9) NULL,
    "RecoveryIncrements" text NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultCollateralizedChainLadders"
    ADD CONSTRAINT "PK_ResultCollateralizedChainLadders" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultCollateralizedChainLadders_ResultId"
    ON "ResultCollateralizedChainLadders" USING btree ("ResultId");

ALTER TABLE "ResultCollateralizedChainLadders" OWNER TO "Elysian";