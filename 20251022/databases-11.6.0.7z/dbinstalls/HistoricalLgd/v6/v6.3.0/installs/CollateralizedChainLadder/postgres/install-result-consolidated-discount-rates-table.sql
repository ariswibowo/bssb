\echo '';
\echo 'Installing Result Consolidated Collateralized Chain Ladder Discount Rates...';

DROP TABLE IF EXISTS "ResultConsolidatedCollateralizedChainLadderDiscountRates";
DROP SEQUENCE IF EXISTS "ResultConsolidatedCollateralizedChainLadderDiscountRates_Id_seq";

\echo '';
\echo 'Creating sequence ResultConsolidatedCollateralizedChainLadderDiscountRates_Id_seq...';

CREATE SEQUENCE "ResultConsolidatedCollateralizedChainLadderDiscountRates_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedCollateralizedChainLadderDiscountRates_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultConsolidatedCollateralizedChainLadderDiscountRates...';

CREATE TABLE "ResultConsolidatedCollateralizedChainLadderDiscountRates" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedCollateralizedChainLadderDiscountRates_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedCollateralizedChainLadderId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "DiscountType" varchar(100) NOT NULL,
    "CalculationMethod" varchar(100) NOT NULL,
    "HashCode" varchar(256) NOT NULL,
    "Base" numeric(20, 2) NOT NULL,
    "DiscountRate" numeric(12, 9) NOT NULL,
    "TotalDiscountRate" numeric(32, 9) NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultConsolidatedCollateralizedChainLadderDiscountRates"
    ADD CONSTRAINT "PK_ResultConsolidatedCollateralizedChainLadderDiscountRates" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultConsolidatedCollateralizedChainLadderDiscountRates_HashCode"
    ON "ResultConsolidatedCollateralizedChainLadderDiscountRates" USING btree ("HashCode");

ALTER TABLE "ResultConsolidatedCollateralizedChainLadderDiscountRates" OWNER TO "Elysian";