PRINT N'';
PRINT N'Installing Result Consolidated Collateralized Chain Ladders...';
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedCollateralizedChainLadders];
GO

PRINT N'';
PRINT N'Creating table ResultConsolidatedCollateralizedChainLadders...';
GO

CREATE TABLE [dbo].[ResultConsolidatedCollateralizedChainLadders] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedCollateralizedChainLadderId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [NumContracts] int NOT NULL,
    [UnsecuredNumContracts] int NOT NULL,
    [SecuredNumContracts] int NOT NULL,
    [OutstandingAmount] numeric(20, 2) NOT NULL,
    [UnsecuredOutstandingAmount] numeric(20, 2) NOT NULL,
    [SecuredOutstandingAmount] numeric(20, 2) NOT NULL,
    [UnsecuredDiscountRate] numeric(12, 9),
    [SecuredPVActualRecovery] numeric(20, 2) NOT NULL,
    [SecuredOutstandingAfterPVActualRecovery] numeric(20, 2) NOT NULL,
    [SecuredCollateralSaleValue] numeric(20, 2) NOT NULL,
    [SecuredDiscountRate] numeric(12, 9),
    [SecuredPVCollateralSale] numeric(20, 2) NOT NULL,
    [SecuredCappedPVCollateral] numeric(20, 2) NOT NULL,
    [Data] nvarchar(max) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedCollateralizedChainLadders]
    ADD CONSTRAINT [PK_ResultConsolidatedCollateralizedChainLadders] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedCollateralizedChainLadders_HashCode]
    ON [dbo].[ResultConsolidatedCollateralizedChainLadders]([HashCode]);
GO