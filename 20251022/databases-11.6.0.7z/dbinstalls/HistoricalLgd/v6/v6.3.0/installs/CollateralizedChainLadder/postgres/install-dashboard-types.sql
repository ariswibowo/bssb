\echo ''
\echo 'Installing new DashboardTypes...';

DELETE
  FROM "DashboardTypes"
 WHERE "DashboardType" IN (
     'CollateralizedChainLadderLgdResult',
     'CollateralizedChainLadderLgdExtract'
 );

\copy "DashboardTypes" FROM '{data}/CollateralizedChainLadderDashboardTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;