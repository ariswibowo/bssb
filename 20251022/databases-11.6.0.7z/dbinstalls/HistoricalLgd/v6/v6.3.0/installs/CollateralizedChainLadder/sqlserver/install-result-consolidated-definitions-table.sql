PRINT N'';
PRINT N'Installing Result Consolidated Collateralized Chain Ladder Definitions...';
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedCollateralizedChainLadderDefinitions];
GO

PRINT N'';
PRINT N'Creating table ResultConsolidatedCollateralizedChainLadderDefinitions...';
GO

CREATE TABLE [dbo].[ResultConsolidatedCollateralizedChainLadderDefinitions] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedCollateralizedChainLadderId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [SegmentName] nvarchar(100) NOT NULL,
    [Unsecured] numeric(12, 9) NOT NULL,
    [Secured] numeric(12, 9) NOT NULL,
    [DirectCost] numeric(12, 9) NOT NULL,
    [Lgd] numeric(12, 9) NOT NULL,
    [Data] nvarchar(max) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedCollateralizedChainLadderDefinitions]
    ADD CONSTRAINT [PK_ResultConsolidatedCollateralizedChainLadderDefinitions] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedCollateralizedChainLadderDefinitions_CalcId_SegmentId]
    ON [dbo].[ResultConsolidatedCollateralizedChainLadderDefinitions]([CalculationId], [SegmentId]);
GO