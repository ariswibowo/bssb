PRINT N'';
PRINT N'Installing Result Collateralized Chain Ladders...';
GO

DROP TABLE IF EXISTS [dbo].[ResultCollateralizedChainLadders];
GO

PRINT N'';
PRINT N'Creating table ResultCollateralizedChainLadders...';
GO

CREATE TABLE [dbo].[ResultCollateralizedChainLadders] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ResultId] uniqueidentifier NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [OutstandingAmount] numeric(20, 2) NOT NULL,
    [UnsecuredOutstandingAmount] numeric(20, 2) NOT NULL,
    [SecuredOutstandingAmount] numeric(20, 2) NOT NULL,
    [DiscountRate] numeric(12, 9) NULL,
    [RecoveryIncrements] nvarchar(max) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultCollateralizedChainLadders]
    ADD CONSTRAINT [PK_ResultCollateralizedChainLadders] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultCollateralizedChainLadders_ResultId]
    ON [dbo].[ResultCollateralizedChainLadders]([ResultId]);
GO