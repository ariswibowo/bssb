PRINT N'';
PRINT N'Installing CalculationProps table...';
GO

PRINT N'';
PRINT N'Dropping CalculationProps table...';
DROP TABLE IF EXISTS [dbo].[CalculationProps];
GO

PRINT N'';
PRINT N'Creating CalculationProps table...';
CREATE TABLE [dbo].[CalculationProps] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [CalculationPropId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [Key] nvarchar(100) NOT NULL,
    [Value] nvarchar(max) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);

ALTER TABLE [dbo].[CalculationProps]
    ADD CONSTRAINT [PK_CalculationProps] PRIMARY KEY ([CalculationPropId]);
GO

ALTER TABLE [dbo].[CalculationProps]
    ADD CONSTRAINT [FK_CalculationProps_Calculations_CalculationId]
        FOREIGN KEY ([CalculationId])
        REFERENCES [dbo].[Calculations]([CalculationId]) ON DELETE CASCADE;
GO