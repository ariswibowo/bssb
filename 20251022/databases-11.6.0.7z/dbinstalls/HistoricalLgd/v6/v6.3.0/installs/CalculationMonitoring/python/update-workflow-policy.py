import dbhelper
import dbpolicies
import logger
import json
import uuid

def main(config):
    # update to add new stall monitoring configuration on calculation state level
    # and add new taskProgress stall monitoring on dataloading task
    dbpolicies.updatePolicy(table="CalculationPolicies",
                            type="Workflow",
                            config=config,
                            updatefunc=update_policy)
    return


def update_policy(policy, context):
    # add stall monitoring configuration on calculation state level
    policy["stallMonitoring"] = buildStateStallMonitoring()

    # build default taskProgressBehavior
    taskProgressBehavior = buildTaskProgressBehavior()

    # Set DataLoading task stall monitoring behaviors
    for stage in policy["stages"]:
        for task in stage["tasks"]:
            if task["task"] == "DataLoading":
                task["stallMonitoring"]["behaviors"] = [ taskProgressBehavior ]

    # Construct a new object to make the data be in the desireable order
    newPolicy = {
      "estimationSampleSize": policy["estimationSampleSize"],
      "estimatedDurationSecs": policy["estimatedDurationSecs"],
      "stallMonitoring": policy["stallMonitoring"],
      "stages": policy["stages"]
    }

    return newPolicy


def buildStateStallMonitoring():
    return  { "thresholdMins": 10, "timeoutMins":10 }


def buildTaskProgressBehavior():
    return { "behavior": "TaskProgress", "thresholdMins": 10 }