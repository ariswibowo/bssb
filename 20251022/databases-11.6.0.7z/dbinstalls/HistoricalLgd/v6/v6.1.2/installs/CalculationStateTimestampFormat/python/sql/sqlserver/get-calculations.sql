SELECT [CalculationId], [Data], [Status], [CreatedWhen], [LastModifiedWhen]
  FROM [dbo].[Calculations]