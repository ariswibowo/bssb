SELECT "CalculationId", "Data", "Status", "CreatedWhen", "LastModifiedWhen"
  FROM "Calculations"