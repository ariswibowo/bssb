\echo '';
\echo 'Updating Calculation Data';

UPDATE "Calculations"
SET "Data" = '{data}'
WHERE "CalculationId" = '{calculationId}';