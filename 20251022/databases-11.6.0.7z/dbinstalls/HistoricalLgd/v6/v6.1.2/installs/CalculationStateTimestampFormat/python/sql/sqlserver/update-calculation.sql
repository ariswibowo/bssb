PRINT N'';
PRINT N'Updating Calculation Data';

UPDATE [dbo].[Calculations]
   SET [Data] = '{data}'
 WHERE [CalculationId] = '{calculationId}';
GO