import dbhelper
import json

def main(config):

    # generate build script file
    build = dbhelper.init_build("update-calculation-data", config)

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-calculation", config)

    # get CalculationId and Data for all calculations 
    cursor = dbhelper.get_data("get-calculations", config)
    cols = [column[0] for column in cursor.description]
    rows = cursor.fetchall()

    for row in rows:
        calculation = dbhelper.get_row_dict(row, cols)
        data = calculation['Data']

        # do in case data exist and the "State" object exists in data
        if data is not None and data != {} and 'state' in data:

            correctTimestampFormat(data, "startTimestamp", calculation['CreatedWhen'])
            correctTimestampFormat(data, "endTimestamp", calculation['LastModifiedWhen'])

            sql = update_sql.format(data=json.dumps(data, separators=(',', ':')).replace("'", "''"), calculationId=calculation['CalculationId'])
            dbhelper.write_build(build, sql)

    # run the build script
    dbhelper.run_build(build, config)

    # dispose
    dbhelper.dispose(cursor, config)

    return

def correctTimestampFormat(data, timestampKey, timestampValue):

    if timestampKey in data["state"] and data["state"][timestampKey] is not None:
        try: 
            data["state"][timestampKey].strftime("%Y-%m-%dT%H:%M:%S.%f")
        except:
            # strftime to correct format 
            data["state"][timestampKey] = timestampValue.strftime("%Y-%m-%dT%H:%M:%S.%f")