# README

**RELEASE: HistoricalLgd V6.1.2**

## Release Fixes

- [Hotfix: Calculation State Timestamp Format](#hotfix-timestamp-format)

## Hotfix: Calculation State Timestamp Format

Correct calculation state timestamp format

[top](#readme)