# README

## Release: HistoricalLgd v6.0.0 (upgrade)

## Release Features

- [Feature: Change DB Owner](#feature-change-db-owner)

## Feature: Change DB Owner

For postgres ONLY: The database owner and all objects within it are change in this release from Empyrean to Elysian.

[top](#readme)
