SELECT 'TABLE' as "objectType",
       tablename as "objectName" 
    FROM pg_tables
    WHERE tableowner = 'Empyrean'

UNION ALL

SELECT 'SEQUENCE' as "objectType",
       sequencename as "objectName" 
  FROM pg_sequences
 WHERE sequenceowner = 'Empyrean'