from termcolor import colored

import dbhelper


def main(config):

    # only run this install on postgres
    if config["targetRdbms"] != "postgres":
        return

    # check Elysian role exists, aborts if not found
    checkElysianRole(config)

    # generate build script file
    build = dbhelper.init_build("update-owner", config)

    buildUpdateDbOwner(build, config)
    buildUpdateObjectOwner(build, config)

    # run the build script
    dbhelper.run_build(build, config)

    return


def buildUpdateDbOwner(build, config):
    # get database sql
    update_sql = dbhelper.get_sql("update-database-owner", config)

    sql = update_sql.format(databaseName=config["installdb"]["name"])
    dbhelper.write_build(build, sql)


def buildUpdateObjectOwner(build, config):

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-object-owner", config)

    # get CalculationId and Data for all calculations
    cursor = dbhelper.get_data("get-empyrean-objects", config)
    cols = [column[0] for column in cursor.description]
    rows = cursor.fetchall()

    for row in rows:
        object = dbhelper.get_row_dict(row, cols)

        sql = update_sql.format(
            objectType=object["objectType"], objectName=object["objectName"])
        dbhelper.write_build(build, sql)

    # dispose
    dbhelper.dispose(cursor, config)


def checkElysianRole(config):
    roleCursor = dbhelper.get_data("get-elysian-role", config)
    rows = roleCursor.fetchall()

    dbhelper.dispose(roleCursor, config)

    if len(rows) == 0:
        print("")
        print(colored("ERROR: Elysian role does not exist; unable to run upgrade!", 'red'))

        print("")
        print(colored("Action required >>>", 'yellow', attrs=['bold']))
        print(colored(
            "  To enable owner transfer from Empyrean->Elysian (postgres)", 'yellow', attrs=['bold']))
        print(colored(
            "  create an Elysian Role with the equal permissions as the existing Empyrean Role", 'yellow', attrs=['bold']))

        print("")
        print(colored("Note:", 'cyan', attrs=['bold']))
        print(colored(
            "  The Empyrean Role may be deleted once all databases are upgraded to R6", 'cyan', attrs=['bold']))
        print(colored("  and it no longer has dependants or component connection usage!",
                      'cyan', attrs=['bold']))
        exit(-1)
