# README

**RELEASE: HistoricalLgd V6.1.1**

## Release Fixes

- [Hotfix: Old Calculation State](#hotfix-old-calculation-state-6-rev.2)

## Hotfix: Old Calculation State

Populate the "State" object in data for the old calculation

[top](#readme)