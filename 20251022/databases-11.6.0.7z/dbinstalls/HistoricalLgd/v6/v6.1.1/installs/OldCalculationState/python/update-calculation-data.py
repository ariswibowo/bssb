import dbhelper
import json

def main(config):

    # generate build script file
    build = dbhelper.init_build("update-calculation-data", config)

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-calculation-data", config)

    # get CalculationId and Data for all calculations 
    cursor = dbhelper.get_data("get-calculation-data", config)
    cols = [column[0] for column in cursor.description]
    rows = cursor.fetchall()

    for row in rows:
        calculation = dbhelper.get_row_dict(row, cols)
        data = calculation['Data']

        # do in case data exist and the "State" object not exists in data
        if data is not None and data != {} and 'state' not in data:
            data = {**data, "state": {
                "startTimestamp": calculation['CreatedWhen'].strftime("%Y-%m-%d %H:%M:%S.%f"),
                "endTimestamp": calculation['LastModifiedWhen'].strftime("%Y-%m-%d %H:%M:%S.%f"),
                "status": calculation['Status']
            }}

            sql = update_sql.format(data=json.dumps(data, separators=(',', ':')), calculationId=calculation['CalculationId'])
            dbhelper.write_build(build, sql)

    # run the build script
    dbhelper.run_build(build, config)

    # dispose
    dbhelper.dispose(cursor, config)

    return