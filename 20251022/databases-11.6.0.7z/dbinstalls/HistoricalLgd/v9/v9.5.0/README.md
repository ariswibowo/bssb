# README

**RELEASE: HistoricalLgd V9.5.0**

No upgrades required. This is a v9.5.0 "stub-only" installation delivered as part of the June-2023 9.5 release.
