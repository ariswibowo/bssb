PRINT N'';
PRINT N'Installing Result Consolidated ChainLadder With Regressions...';
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedChainLadderWithRegressions];
GO

PRINT N'';
PRINT N'Creating table ResultConsolidatedChainLadderWithRegressions...';
GO

CREATE TABLE [dbo].[ResultConsolidatedChainLadderWithRegressions] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderWithRegressionId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [NumContracts] int NOT NULL,
    [OutstandingAmount] numeric(20, 2) NOT NULL,
    [TotalRecovery] numeric(20, 2) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedChainLadderWithRegressions]
    ADD CONSTRAINT [PK_ResultConsolidatedChainLadderWithRegressions] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedChainLadderWithRegressions_HashCode]
    ON [dbo].[ResultConsolidatedChainLadderWithRegressions]([HashCode]);
GO