PRINT N''
PRINT N'Installing new DashboardTypes...'
GO

DELETE
  FROM [dbo].[DashboardTypes]
 WHERE [DashboardType] IN (
     'CLRSummary',
     'CLRBucketSummary',
     'CLRLinearRegression',
     'CLRDiscountMarginalRecoveries',
     'CLRMarginalAndCumulativePercentRecoveries',
     'CLRMarginalRecoveries',
     'CLRDevelopmentCumulativeRecoveries',
     'CLRAverageDevelopmentFactors',
     'CLRDevelopmentFactors',
     'CLRCumulativeRecoveries',
     'CLRRecoveries',
     'CLRConsolidationDetails'
 );
GO

BULK INSERT [dbo].[DashboardTypes]
FROM '{data}/ChainLadderWithRegression/DashboardTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO