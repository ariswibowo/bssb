\echo '';
\echo 'Installing Result Consolidated ChainLadder With Regression Definitions...';

DROP TABLE IF EXISTS "ResultConsolidatedChainLadderWithRegressionDefinitions";
DROP SEQUENCE IF EXISTS "ResultConsolidatedChainLadderWithRegressionDefinitions_Id_seq";

\echo '';
\echo 'Creating sequence ResultConsolidatedChainLadderWithRegressionDefinitions_Id_seq...';

CREATE SEQUENCE "ResultConsolidatedChainLadderWithRegressionDefinitions_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedChainLadderWithRegressionDefinitions_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultConsolidatedChainLadderWithRegressionDefinitions...';

CREATE TABLE "ResultConsolidatedChainLadderWithRegressionDefinitions" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedChainLadderWithRegressionDefinitions_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderWithRegressionId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "SegmentId" uuid NOT NULL,
    "SegmentName" varchar(100) NOT NULL,
    "BucketId" uuid NOT NULL,
    "BucketName" varchar(100) NOT NULL,
    "BucketDirectCost"  numeric(12, 9) NOT NULL,
    "Alpha"  numeric(12, 9) NULL,
    "Beta"  numeric(12, 9) NULL,
    "Data" text NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);      

ALTER TABLE ONLY "ResultConsolidatedChainLadderWithRegressionDefinitions"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadderWithRegressionDefinitions" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadderWithRegressionDefinitions_CalcId_SegmentId" 
    ON "ResultConsolidatedChainLadderWithRegressionDefinitions" USING btree ("CalculationId", "SegmentId", "BucketId");

ALTER TABLE "ResultConsolidatedChainLadderWithRegressionDefinitions" OWNER TO "Elysian";