\echo '';
\echo 'Installing Result ChainLadder With Regressions...';

DROP TABLE IF EXISTS "ResultChainLadderWithRegressions";
DROP SEQUENCE IF EXISTS "ResultChainLadderWithRegressions_Id_seq";

\echo '';
\echo 'Creating sequence ResultChainLadderWithRegressions_Id_seq...';

CREATE SEQUENCE "ResultChainLadderWithRegressions_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultChainLadderWithRegressions_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultChainLadderWithRegressions...';

CREATE TABLE "ResultChainLadderWithRegressions" (
    "Id" bigint DEFAULT nextval('"ResultChainLadderWithRegressions_Id_seq"'::regclass) NOT NULL,
    "ResultId" uuid NOT NULL,
    "HashCode" varchar(256) NOT NULL,
    "SegmentId" uuid NOT NULL,
    "BucketId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "DiscountRate" numeric(12, 9) NULL,
    "TotalRecovery" numeric(20, 2) NOT NULL,
    "RecoveryIncrements" text NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultChainLadderWithRegressions"
    ADD CONSTRAINT "PK_ResultChainLadderWithRegressions" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultChainLadderWithRegressions_ResultId"
    ON "ResultChainLadderWithRegressions" USING btree ("ResultId");

ALTER TABLE "ResultChainLadderWithRegressions" OWNER TO "Elysian";