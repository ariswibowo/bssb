PRINT N'';
PRINT N'Installing Result Consolidated ChainLadder With Regression Definitions...';
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedChainLadderWithRegressionDefinitions];
GO

PRINT N'';
PRINT N'Creating table ResultConsolidatedChainLadderWithRegressionDefinitions...';
GO

CREATE TABLE [dbo].[ResultConsolidatedChainLadderWithRegressionDefinitions] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderWithRegressionId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [SegmentName] nvarchar(100) NOT NULL,
    [BucketId] uniqueidentifier NOT NULL,
    [BucketName] nvarchar(100) NOT NULL,
    [BucketDirectCost] numeric(12, 9) NOT NULL,
    [Alpha] numeric(12, 9) NULL,
    [Beta] numeric(12, 9) NULL,
    [Data] nvarchar(max) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedChainLadderWithRegressionDefinitions]
    ADD CONSTRAINT [PK_ResultConsolidatedChainLadderWithRegressionDefinitions] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedChainLadderWithRegressionDefinitions_CalcId_SegmentId]
    ON [dbo].[ResultConsolidatedChainLadderWithRegressionDefinitions]([CalculationId], [SegmentId], [BucketId]);
GO