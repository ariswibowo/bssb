PRINT N'';
PRINT N'Installing Result ChainLadder With Regressions...';
GO

DROP TABLE IF EXISTS [dbo].[ResultChainLadderWithRegressions];
GO

PRINT N'';
PRINT N'Creating table ResultChainLadderWithRegressions...';
GO

CREATE TABLE [dbo].[ResultChainLadderWithRegressions] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ResultId] uniqueidentifier NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [BucketId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [OutstandingAmount] numeric(20, 2) NOT NULL,
    [DiscountRate] numeric(12, 9) NULL,
    [TotalRecovery] numeric(20, 2) NOT NULL,
    [RecoveryIncrements] nvarchar(max) NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultChainLadderWithRegressions]
    ADD CONSTRAINT [PK_ResultChainLadderWithRegressions] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultChainLadderWithRegressions_ResultId]
    ON [dbo].[ResultChainLadderWithRegressions]([ResultId]);
GO