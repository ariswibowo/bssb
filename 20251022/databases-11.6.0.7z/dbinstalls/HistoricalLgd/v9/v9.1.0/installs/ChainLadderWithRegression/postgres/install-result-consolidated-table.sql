\echo '';
\echo 'Installing Result Consolidated ChainLadder With Regressions...';

DROP TABLE IF EXISTS "ResultConsolidatedChainLadderWithRegressions";
DROP SEQUENCE IF EXISTS "ResultConsolidatedChainLadderWithRegressions_Id_seq";

\echo '';
\echo 'Creating sequence ResultConsolidatedChainLadderWithRegressions_Id_seq...';

CREATE SEQUENCE "ResultConsolidatedChainLadderWithRegressions_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedChainLadderWithRegressions_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultConsolidatedChainLadderWithRegressions...';

CREATE TABLE "ResultConsolidatedChainLadderWithRegressions" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedChainLadderWithRegressions_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderWithRegressionId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "HashCode" varchar(256) NOT NULL,
    "NumContracts" integer NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "TotalRecovery" numeric(20, 2) NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultConsolidatedChainLadderWithRegressions"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadderWithRegressions" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadderWithRegressions_HashCode"
    ON "ResultConsolidatedChainLadderWithRegressions" USING btree ("HashCode");

ALTER TABLE "ResultConsolidatedChainLadderWithRegressions" OWNER TO "Elysian";