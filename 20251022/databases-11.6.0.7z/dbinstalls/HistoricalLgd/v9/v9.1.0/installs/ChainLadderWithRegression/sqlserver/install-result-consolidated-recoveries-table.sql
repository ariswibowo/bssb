PRINT N'';
PRINT N'Installing Result Consolidated ChainLadder With Regression Recoveries...';
GO

DROP TABLE IF EXISTS [dbo].[ResultConsolidatedChainLadderWithRegressionRecoveries];
GO

PRINT N'';
PRINT N'Creating table ResultConsolidatedChainLadderWithRegressionRecoveries...';
GO

CREATE TABLE [dbo].[ResultConsolidatedChainLadderWithRegressionRecoveries] (
    [Id] bigint IDENTITY(1, 1) NOT NULL,
    [ConsolidatedChainLadderWithRegressionId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [RecoveryDate] datetime NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [RecoveryAmount] numeric(20, 2) NOT NULL,
    [IsProjected] bit NOT NULL,
    [RetentionCopied] bit NOT NULL DEFAULT 0
);
GO

ALTER TABLE [dbo].[ResultConsolidatedChainLadderWithRegressionRecoveries]
    ADD CONSTRAINT [PK_ResultConsolidatedChainLadderWithRegressionRecoveries] PRIMARY KEY ([Id]);
GO

PRINT N'';
PRINT N'Creating index...';
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedChainLadderWithRegressionRecoveries_HashCode]
    ON [dbo].[ResultConsolidatedChainLadderWithRegressionRecoveries]([HashCode]);
GO