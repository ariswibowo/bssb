\echo ''
\echo 'Installing new DashboardTypes...';

DELETE
  FROM "DashboardTypes"
 WHERE "DashboardType" IN (
     'CLRSummary',
     'CLRBucketSummary',
     'CLRLinearRegression',
     'CLRDiscountMarginalRecoveries',
     'CLRMarginalAndCumulativePercentRecoveries',
     'CLRMarginalRecoveries',
     'CLRDevelopmentCumulativeRecoveries',
     'CLRAverageDevelopmentFactors',
     'CLRDevelopmentFactors',
     'CLRCumulativeRecoveries',
     'CLRRecoveries',
     'CLRConsolidationDetails'
 );

\copy "DashboardTypes" FROM '{data}/ChainLadderWithRegression/DashboardTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;