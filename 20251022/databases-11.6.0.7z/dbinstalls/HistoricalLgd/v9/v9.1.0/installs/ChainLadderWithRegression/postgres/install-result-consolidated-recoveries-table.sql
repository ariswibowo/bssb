\echo '';
\echo 'Installing Result Consolidated ChainLadder With Regression Recoveries...';

DROP TABLE IF EXISTS "ResultConsolidatedChainLadderWithRegressionRecoveries";
DROP SEQUENCE IF EXISTS "ResultConsolidatedChainLadderWithRegressionRecoveries_Id_seq";

\echo '';
\echo 'Creating sequence ResultConsolidatedChainLadderWithRegressionRecoveries_Id_seq...';

CREATE SEQUENCE "ResultConsolidatedChainLadderWithRegressionRecoveries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedChainLadderWithRegressionRecoveries_Id_seq" OWNER TO "Elysian";

\echo '';
\echo 'Creating table ResultConsolidatedChainLadderWithRegressionRecoveries...';

CREATE TABLE "ResultConsolidatedChainLadderWithRegressionRecoveries" (
    "Id" bigint DEFAULT nextval('"ResultConsolidatedChainLadderWithRegressionRecoveries_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedChainLadderWithRegressionId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "RecoveryDate" timestamp without time zone NOT NULL,
    "HashCode" varchar(256) NOT NULL,
    "RecoveryAmount" numeric(20, 2) NOT NULL,
    "IsProjected" boolean NOT NULL,
    "RetentionCopied" boolean NOT NULL DEFAULT false
);

ALTER TABLE ONLY "ResultConsolidatedChainLadderWithRegressionRecoveries"
    ADD CONSTRAINT "PK_ResultConsolidatedChainLadderWithRegressionRecoveries" PRIMARY KEY ("Id");

\echo '';
\echo 'Creating index...'

CREATE UNIQUE INDEX "IX_ResultConsolidatedChainLadderWithRegressionRecoveries_HashCode"
    ON "ResultConsolidatedChainLadderWithRegressionRecoveries" USING btree ("HashCode");

ALTER TABLE "ResultConsolidatedChainLadderWithRegressionRecoveries" OWNER TO "Elysian";