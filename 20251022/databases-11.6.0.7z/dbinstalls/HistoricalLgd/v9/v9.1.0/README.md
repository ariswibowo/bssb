# README

**RELEASE: HistoricalLgd V9.1.0**

## Release Features

- [Feature: Chain Ladder With Regression](#feature-chain-ladder-with-regression)

## Feature: Chain Ladder With Regression

- Add new 12 dashboard types for the ChainLadderWithRegression calculation results
- Add new 4 tables for the ChainLadderWithRegression calculation results
  - ResultConsolidatedChainLadderWithRegressionDefinitions
  - ResultConsolidatedChainLadderWithRegressions
  - ResultConsolidatedChainLadderWithRegressionRecoveries
  - ResultChainLadderWithRegressions

[top](#readme)