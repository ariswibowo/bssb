PRINT N''
PRINT N'Updating Data for CalculationId: {calculationId}...'
GO

UPDATE [dbo].[Calculations]
   SET [Data] = NULL
 WHERE [CalculationId] = '{calculationId}';
GO