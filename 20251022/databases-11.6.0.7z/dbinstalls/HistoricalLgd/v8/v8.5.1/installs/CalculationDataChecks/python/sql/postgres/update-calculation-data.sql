\echo ''
\echo 'Updating Data for CalculationId: {calculationId}...'

UPDATE "Calculations"
   SET "Data" = NULL
 WHERE "CalculationId" = '{calculationId}';