PRINT N''
PRINT N'Updating Checks for CalculationId: {calculationId}...'
GO

UPDATE [dbo].[Calculations]
   SET [Checks] = NULL
 WHERE [CalculationId] = '{calculationId}';
GO