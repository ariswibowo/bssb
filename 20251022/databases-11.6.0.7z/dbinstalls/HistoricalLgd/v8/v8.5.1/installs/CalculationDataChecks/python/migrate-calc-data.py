import dbhelper


def main(config):
    # get calculations
    calculations = getCalculations(config)

    # do nothing if no calculations to migrate
    if len(calculations) == 0:
        return

    # convert calculations
    converted_calculations = convertCalculations(calculations)

    # update calculation data and checks
    updateCalculations(converted_calculations, config)


def convertCalculations(calculations):
    converted_calculations = []

    # loop through calculations
    for calculation in calculations:
        # Find string null that needs to be replaced to NULL value
        if calculation["Data"] is not None and (calculation["Data"].lower() == "null" or calculation["Data"].lower() == "none"):
            converted_calculations.append(calculation)

    return converted_calculations


def updateCalculations(calculations, config):

    # generate build script file
    build = dbhelper.init_build("migrate-calc-data", config)

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-calculation-data", config)

    for calculation in calculations:
        # construct update statement
        sql = update_sql.format(
            calculationId=calculation["CalculationId"]
        )

        # write to build file
        dbhelper.write_build(build, sql)

    # run build
    dbhelper.run_build(build, config)


def getCalculations(config):
    # get local query
    sql = dbhelper.get_sql("get-calculations", config)

    # get local items
    data = dbhelper.run_sql(sql, config)
    localItemsList = data.fetchall()

    # get col names list
    cols = [column[0] for column in data.description]

    # convert list to a dictionary
    localItems = []
    for item in localItemsList:
        itemDict = {}
        
        # extract column values without loading json to prevent null sring converted to None
        for idx, col in enumerate(cols, 0):
            itemDict[col] = item[idx]

        localItems.append(itemDict)

    dbhelper.dispose(data, config)

    return localItems
