\echo ''
\echo 'Updating Checks for CalculationId: {calculationId}...'

UPDATE "Calculations"
   SET "Checks" = NULL
 WHERE "CalculationId" = '{calculationId}';