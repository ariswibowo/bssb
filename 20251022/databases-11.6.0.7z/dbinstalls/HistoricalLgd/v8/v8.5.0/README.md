# README

**RELEASE: HistoricalLgd V8.5.0**

No upgrades required. This is a v8.5.0 "stub-only" installation delivered as part of the March-2022 8.5 release.
