# README

## Release: HistoricalLgd v8.0.0 (upgrade)

No upgrades required.
