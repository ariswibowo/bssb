PRINT N''
PRINT N'Updating ApplicationLogs table...'
GO

ALTER TABLE [dbo].[ApplicationLogs] ALTER COLUMN [Origin] nvarchar(50) NOT NULL;
GO