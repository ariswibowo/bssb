\echo ''
\echo 'Updating ApplicationLogs table...';

ALTER TABLE "ApplicationLogs" ALTER COLUMN "Origin" SET NOT NULL;