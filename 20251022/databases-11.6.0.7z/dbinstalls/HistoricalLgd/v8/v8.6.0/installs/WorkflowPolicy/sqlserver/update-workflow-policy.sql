PRINT N''
PRINT N'Updating Workflow policy';
GO

DELETE FROM [dbo].[CalculationPolicies] WHERE [PolicyType] IN ('Workflow');
GO

BULK INSERT [dbo].[CalculationPolicies]
FROM '{data}/WorkflowPolicy/WorkflowPolicy.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO