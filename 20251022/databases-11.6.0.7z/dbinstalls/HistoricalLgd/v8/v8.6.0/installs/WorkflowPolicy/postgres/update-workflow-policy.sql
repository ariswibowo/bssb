\echo '';
\echo 'Updating Workflow policy';

DELETE FROM "CalculationPolicies" WHERE "PolicyType" IN ('Workflow');

\copy "CalculationPolicies" FROM '{data}/WorkflowPolicy/WorkflowPolicy.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;