# README

**RELEASE: HistoricalLgd V8.6.0**

## Release Fixes

- [Feature: Workflow Policy](#feature-workflow-policy)
- [Bugfix: Application Logs Origin Not Null](#bugfix-application-logs-origin-not-null)

## Feature: Workflow Policy

Updating Workflow policy in CalculationPolicies table to support a new way to calculate the estimated duration time of the calculation. 

Previously, there is only one approach which is Historical - Estimate using the past completed calculations as reference, this sometime can cause a confusion when the calculations can have diffirent size/volume of data being loaded into the pipeline. 

This update is for fixing that confusion and adjust the estimate duration time to be precise and base of the actual size/volume of the data.

Currently there are 3 approaches of the estimator type

- Historical - Estimate the duration by using past completed calculations as reference
- DataLoad - Estimate the duration by using the data that being loaded into the calculation pipeline
- Calculation - Estimate the duration by using the predicted expected amount of data based of the data loading task

[top](#readme)

## Bugfix: Application Logs Origin Not Null

Adding NOT NULL Constraint to "Origin" column of "ApplicationLogs" table

[top](#readme)