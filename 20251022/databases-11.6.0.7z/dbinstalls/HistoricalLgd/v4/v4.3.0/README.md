# README

**Release: HistoricalLgd V4.3.0**

## Release Features & Fixes

- [Feature: Staged Calculations](#feature-staged-calculations)
- [Feature: Preflight Check Policies](#feature-preflight-check-policies)
- [Feature: Adjust Id Datatype](#feature-adjust-id-datatype)

## Feature: Staged Calculations

Using the Staged Calculation feature, it is possible to define the various calculation stages and tasks for the Historical LGD calculation type, through a policy. It also introduces a new way of logging significant events during the course of a calculation. 

This setup requires a few new database objects:
* CalculationPolicies table, initially holding only the new Workflow policy;
* CalculationLogs table, which will hold calculation log information

[top](#readme)

## Feature: Preflight Check Policies

- Added Preflight Checks policy by copying from Configurations table.
- Dropped Configurations table.

[top](#readme)

## Feature: Adjust Id DataType

- Change Id Column of results table to BigInteger type instead of Integer

References: #EMP-2001

[top](#readme)