PRINT N'';
PRINT N'Removing ResultConsolidatedChainLadderRecoveries Primary Key...';
ALTER TABLE [ResultConsolidatedChainLadderRecoveries] DROP CONSTRAINT [PK_ResultConsolidatedChainLadderRecoveries];

PRINT N'';
PRINT N'Updating ResultConsolidatedChainLadderRecoveries Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedChainLadderRecoveries] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedChainLadderRecoveries Primary Key...';
ALTER TABLE [ResultConsolidatedChainLadderRecoveries] ADD CONSTRAINT [PK_ResultConsolidatedChainLadderRecoveries] PRIMARY KEY ([Id]);