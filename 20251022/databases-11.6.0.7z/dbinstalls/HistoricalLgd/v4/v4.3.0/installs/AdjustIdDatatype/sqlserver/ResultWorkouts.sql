PRINT N'';
PRINT N'Removing ResultWorkouts Primary Key...';
ALTER TABLE [ResultWorkouts] DROP CONSTRAINT [PK_ResultWorkouts];

PRINT N'';
PRINT N'Updating ResultWorkouts Id column data type to BIGINT...';
ALTER TABLE [ResultWorkouts] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultWorkouts Primary Key...';
ALTER TABLE [ResultWorkouts] ADD CONSTRAINT [PK_ResultWorkouts] PRIMARY KEY ([Id]);