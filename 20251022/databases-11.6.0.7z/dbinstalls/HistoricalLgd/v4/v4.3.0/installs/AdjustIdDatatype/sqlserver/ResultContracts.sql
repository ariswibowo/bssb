PRINT N'';
PRINT N'Removing ResultContracts Primary Key...';
ALTER TABLE [ResultContracts] DROP CONSTRAINT [PK_ResultContracts];

PRINT N'';
PRINT N'Updating ResultContracts Id column data type to BIGINT...';
ALTER TABLE [ResultContracts] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultContracts Primary Key...';
ALTER TABLE [ResultContracts] ADD CONSTRAINT [PK_ResultContracts] PRIMARY KEY ([Id]);