PRINT N'';
PRINT N'Removing ResultIndex Primary Key...';
ALTER TABLE [ResultIndex] DROP CONSTRAINT [PK_ResultIndex];

PRINT N'';
PRINT N'Updating ResultIndex Id column data type to BIGINT...';
ALTER TABLE [ResultIndex] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultIndex Primary Key...';
ALTER TABLE [ResultIndex] ADD CONSTRAINT [PK_ResultIndex] PRIMARY KEY ([Id]);