\echo '';
\echo 'Removing ResultConsolidatedChainLadderRecoveries Primary Key...';
ALTER TABLE "ResultConsolidatedChainLadderRecoveries" DROP CONSTRAINT "PK_ResultConsolidatedChainLadderRecoveries";

\echo '';
\echo 'Updating ResultConsolidatedChainLadderRecoveries Id column data type to BIGINT...';
ALTER TABLE "ResultConsolidatedChainLadderRecoveries" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultConsolidatedChainLadderRecoveries Primary Key...';
ALTER TABLE "ResultConsolidatedChainLadderRecoveries" ADD CONSTRAINT "PK_ResultConsolidatedChainLadderRecoveries" PRIMARY KEY ("Id");