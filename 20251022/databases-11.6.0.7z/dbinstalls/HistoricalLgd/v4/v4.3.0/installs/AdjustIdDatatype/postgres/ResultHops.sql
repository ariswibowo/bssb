\echo '';
\echo 'Removing ResultHops Primary Key...';
ALTER TABLE "ResultHops" DROP CONSTRAINT "PK_ResultHops";

\echo '';
\echo 'Updating ResultHops Id column data type to BIGINT...';
ALTER TABLE "ResultHops" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultHops Primary Key...';
ALTER TABLE "ResultHops" ADD CONSTRAINT "PK_ResultHops" PRIMARY KEY ("Id");