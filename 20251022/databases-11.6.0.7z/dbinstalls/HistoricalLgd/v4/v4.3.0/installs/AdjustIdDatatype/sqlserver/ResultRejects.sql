PRINT N'';
PRINT N'Removing ResultRejects Primary Key...';
ALTER TABLE [ResultRejects] DROP CONSTRAINT [PK_ResultRejects];

PRINT N'';
PRINT N'Updating ResultRejects Id column data type to BIGINT...';
ALTER TABLE [ResultRejects] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultRejects Primary Key...';
ALTER TABLE [ResultRejects] ADD CONSTRAINT [PK_ResultRejects] PRIMARY KEY ([Id]);