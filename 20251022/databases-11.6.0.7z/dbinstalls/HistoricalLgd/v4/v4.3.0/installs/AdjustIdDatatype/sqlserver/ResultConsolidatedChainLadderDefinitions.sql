PRINT N'';
PRINT N'Removing ResultConsolidatedChainLadderDefinitions Primary Key...';
ALTER TABLE [ResultConsolidatedChainLadderDefinitions] DROP CONSTRAINT [PK_ResultConsolidatedChainLadderDefinitions];

PRINT N'';
PRINT N'Updating ResultConsolidatedChainLadderDefinitions Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedChainLadderDefinitions] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedChainLadderDefinitions Primary Key...';
ALTER TABLE [ResultConsolidatedChainLadderDefinitions] ADD CONSTRAINT [PK_ResultConsolidatedChainLadderDefinitions] PRIMARY KEY ([Id]);