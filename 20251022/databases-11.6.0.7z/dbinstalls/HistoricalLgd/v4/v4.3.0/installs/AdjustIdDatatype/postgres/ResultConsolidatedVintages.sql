\echo '';
\echo 'Removing ResultConsolidatedVintages Primary Key...';
ALTER TABLE "ResultConsolidatedVintages" DROP CONSTRAINT "PK_ResultConsolidatedVintages";

\echo '';
\echo 'Updating ResultConsolidatedVintages Id column data type to BIGINT...';
ALTER TABLE "ResultConsolidatedVintages" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultConsolidatedVintages Primary Key...';
ALTER TABLE "ResultConsolidatedVintages" ADD CONSTRAINT "PK_ResultConsolidatedVintages" PRIMARY KEY ("Id");