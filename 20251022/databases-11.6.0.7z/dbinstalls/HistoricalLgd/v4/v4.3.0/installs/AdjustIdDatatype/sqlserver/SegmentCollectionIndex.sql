PRINT N'';
PRINT N'Removing SegmentCollectionIndex Primary Key...';
ALTER TABLE [SegmentCollectionIndex] DROP CONSTRAINT [PK_SegmentCollectionIndex];

PRINT N'';
PRINT N'Updating SegmentCollectionIndex Id column data type to BIGINT...';
ALTER TABLE [SegmentCollectionIndex] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding SegmentCollectionIndex Primary Key...';
ALTER TABLE [SegmentCollectionIndex] ADD CONSTRAINT [PK_SegmentCollectionIndex] PRIMARY KEY ([Id]);