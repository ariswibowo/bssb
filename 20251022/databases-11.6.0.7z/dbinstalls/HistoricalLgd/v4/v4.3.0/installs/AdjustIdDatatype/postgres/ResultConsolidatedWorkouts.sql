\echo '';
\echo 'Removing ResultConsolidatedWorkouts Primary Key...';
ALTER TABLE "ResultConsolidatedWorkouts" DROP CONSTRAINT "PK_ResultConsolidatedWorkouts";

\echo '';
\echo 'Updating ResultConsolidatedWorkouts Id column data type to BIGINT...';
ALTER TABLE "ResultConsolidatedWorkouts" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultConsolidatedWorkouts Primary Key...';
ALTER TABLE "ResultConsolidatedWorkouts" ADD CONSTRAINT "PK_ResultConsolidatedWorkouts" PRIMARY KEY ("Id");