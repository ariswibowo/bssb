PRINT N'';
PRINT N'Removing ResultSegmentCollections Primary Key...';
ALTER TABLE [ResultSegmentCollections] DROP CONSTRAINT [PK_ResultSegmentCollections];

PRINT N'';
PRINT N'Updating ResultSegmentCollections Id column data type to BIGINT...';
ALTER TABLE [ResultSegmentCollections] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultSegmentCollections Primary Key...';
ALTER TABLE [ResultSegmentCollections] ADD CONSTRAINT [PK_ResultSegmentCollections] PRIMARY KEY ([Id]);