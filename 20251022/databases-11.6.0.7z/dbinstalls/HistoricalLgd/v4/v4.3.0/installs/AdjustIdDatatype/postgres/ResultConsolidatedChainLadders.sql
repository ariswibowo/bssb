\echo '';
\echo 'Removing ResultConsolidatedChainLadders Primary Key...';
ALTER TABLE "ResultConsolidatedChainLadders" DROP CONSTRAINT "PK_ResultConsolidatedChainLadders";

\echo '';
\echo 'Updating ResultConsolidatedChainLadders Id column data type to BIGINT...';
ALTER TABLE "ResultConsolidatedChainLadders" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultConsolidatedChainLadders Primary Key...';
ALTER TABLE "ResultConsolidatedChainLadders" ADD CONSTRAINT "PK_ResultConsolidatedChainLadders" PRIMARY KEY ("Id");