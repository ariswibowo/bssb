PRINT N'';
PRINT N'Removing ResultHops Primary Key...';
ALTER TABLE [ResultHops] DROP CONSTRAINT [PK_ResultHops];

PRINT N'';
PRINT N'Updating ResultHops Id column data type to BIGINT...';
ALTER TABLE [ResultHops] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultHops Primary Key...';
ALTER TABLE [ResultHops] ADD CONSTRAINT [PK_ResultHops] PRIMARY KEY ([Id]);