\echo '';
\echo 'Removing ResultConsolidatedWorkoutDefinitions Primary Key...';
ALTER TABLE "ResultConsolidatedWorkoutDefinitions" DROP CONSTRAINT "PK_ResultConsolidatedWorkoutDefinitions";

\echo '';
\echo 'Updating ResultConsolidatedWorkoutDefinitions Id column data type to BIGINT...';
ALTER TABLE "ResultConsolidatedWorkoutDefinitions" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultConsolidatedWorkoutDefinitions Primary Key...';
ALTER TABLE "ResultConsolidatedWorkoutDefinitions" ADD CONSTRAINT "PK_ResultConsolidatedWorkoutDefinitions" PRIMARY KEY ("Id");