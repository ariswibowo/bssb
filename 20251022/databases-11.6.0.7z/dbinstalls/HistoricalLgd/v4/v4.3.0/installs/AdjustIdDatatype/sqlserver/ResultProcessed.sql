PRINT N'';
PRINT N'Removing ResultProcessed Primary Key...';
ALTER TABLE [ResultProcessed] DROP CONSTRAINT [PK_ResultProcessed];

PRINT N'';
PRINT N'Updating ResultProcessed Id column data type to BIGINT...';
ALTER TABLE [ResultProcessed] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultProcessed Primary Key...';
ALTER TABLE [ResultProcessed] ADD CONSTRAINT [PK_ResultProcessed] PRIMARY KEY ([Id]);