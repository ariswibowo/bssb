\echo '';
\echo 'Removing ResultSegmentCollections Primary Key...';
ALTER TABLE "ResultSegmentCollections" DROP CONSTRAINT "PK_ResultSegmentCollections";

\echo '';
\echo 'Updating ResultSegmentCollections Id column data type to BIGINT...';
ALTER TABLE "ResultSegmentCollections" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultSegmentCollections Primary Key...';
ALTER TABLE "ResultSegmentCollections" ADD CONSTRAINT "PK_ResultSegmentCollections" PRIMARY KEY ("Id");