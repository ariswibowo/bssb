PRINT N'';
PRINT N'Removing ResultConsolidatedWorkouts Primary Key...';
ALTER TABLE [ResultConsolidatedWorkouts] DROP CONSTRAINT [PK_ResultConsolidatedWorkouts];

PRINT N'';
PRINT N'Updating ResultConsolidatedWorkouts Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedWorkouts] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedWorkouts Primary Key...';
ALTER TABLE [ResultConsolidatedWorkouts] ADD CONSTRAINT [PK_ResultConsolidatedWorkouts] PRIMARY KEY ([Id]);