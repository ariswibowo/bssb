\echo '';
\echo 'Removing SegmentCollectionIndex Primary Key...';
ALTER TABLE "SegmentCollectionIndex" DROP CONSTRAINT "PK_SegmentCollectionIndex";

\echo '';
\echo 'Updating SegmentCollectionIndex Id column data type to BIGINT...';
ALTER TABLE "SegmentCollectionIndex" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding SegmentCollectionIndex Primary Key...';
ALTER TABLE "SegmentCollectionIndex" ADD CONSTRAINT "PK_SegmentCollectionIndex" PRIMARY KEY ("Id");