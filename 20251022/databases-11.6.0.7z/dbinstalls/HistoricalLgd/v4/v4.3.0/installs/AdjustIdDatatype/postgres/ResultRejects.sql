\echo '';
\echo 'Removing ResultRejects Primary Key...';
ALTER TABLE "ResultRejects" DROP CONSTRAINT "PK_ResultRejects";

\echo '';
\echo 'Updating ResultRejects Id column data type to BIGINT...';
ALTER TABLE "ResultRejects" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultRejects Primary Key...';
ALTER TABLE "ResultRejects" ADD CONSTRAINT "PK_ResultRejects" PRIMARY KEY ("Id");