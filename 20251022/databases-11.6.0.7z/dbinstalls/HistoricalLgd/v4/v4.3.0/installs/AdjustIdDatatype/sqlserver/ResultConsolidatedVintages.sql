PRINT N'';
PRINT N'Removing ResultConsolidatedVintages Primary Key...';
ALTER TABLE [ResultConsolidatedVintages] DROP CONSTRAINT [PK_ResultConsolidatedVintages];

PRINT N'';
PRINT N'Updating ResultConsolidatedVintages Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedVintages] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedVintages Primary Key...';
ALTER TABLE [ResultConsolidatedVintages] ADD CONSTRAINT [PK_ResultConsolidatedVintages] PRIMARY KEY ([Id]);