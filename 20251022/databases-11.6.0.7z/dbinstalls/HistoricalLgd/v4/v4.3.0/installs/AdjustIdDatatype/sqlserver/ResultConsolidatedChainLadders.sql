PRINT N'';
PRINT N'Removing ResultConsolidatedChainLadders Primary Key...';
ALTER TABLE [ResultConsolidatedChainLadders] DROP CONSTRAINT [PK_ResultConsolidatedChainLadders];

PRINT N'';
PRINT N'Updating ResultConsolidatedChainLadders Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedChainLadders] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedChainLadders Primary Key...';
ALTER TABLE [ResultConsolidatedChainLadders] ADD CONSTRAINT [PK_ResultConsolidatedChainLadders] PRIMARY KEY ([Id]);