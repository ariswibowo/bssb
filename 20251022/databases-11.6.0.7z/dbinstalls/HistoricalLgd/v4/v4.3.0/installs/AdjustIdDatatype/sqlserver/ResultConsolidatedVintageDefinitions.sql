PRINT N'';
PRINT N'Removing ResultConsolidatedVintageDefinitions Primary Key...';
ALTER TABLE [ResultConsolidatedVintageDefinitions] DROP CONSTRAINT [PK_ResultConsolidatedVintageDefinitions];

PRINT N'';
PRINT N'Updating ResultConsolidatedVintageDefinitions Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedVintageDefinitions] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedVintageDefinitions Primary Key...';
ALTER TABLE [ResultConsolidatedVintageDefinitions] ADD CONSTRAINT [PK_ResultConsolidatedVintageDefinitions] PRIMARY KEY ([Id]);