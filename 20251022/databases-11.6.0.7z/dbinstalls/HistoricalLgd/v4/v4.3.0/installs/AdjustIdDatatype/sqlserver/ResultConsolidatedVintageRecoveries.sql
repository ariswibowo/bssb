PRINT N'';
PRINT N'Removing ResultConsolidatedVintageRecoveries Primary Key...';
ALTER TABLE [ResultConsolidatedVintageRecoveries] DROP CONSTRAINT [PK_ResultConsolidatedVintageRecoveries];

PRINT N'';
PRINT N'Updating ResultConsolidatedVintageRecoveries Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedVintageRecoveries] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedVintageRecoveries Primary Key...';
ALTER TABLE [ResultConsolidatedVintageRecoveries] ADD CONSTRAINT [PK_ResultConsolidatedVintageRecoveries] PRIMARY KEY ([Id]);