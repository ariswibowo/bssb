\echo '';
\echo 'Removing ResultIndex Primary Key...';
ALTER TABLE "ResultIndex" DROP CONSTRAINT "PK_ResultIndex";

\echo '';
\echo 'Updating ResultIndex Id column data type to BIGINT...';
ALTER TABLE "ResultIndex" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultIndex Primary Key...';
ALTER TABLE "ResultIndex" ADD CONSTRAINT "PK_ResultIndex" PRIMARY KEY ("Id");