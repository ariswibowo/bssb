\echo '';
\echo 'Removing ResultChainLadders Primary Key...';
ALTER TABLE "ResultChainLadders" DROP CONSTRAINT "PK_ResultChainLadders";

\echo '';
\echo 'Updating ResultChainLadders Id column data type to BIGINT...';
ALTER TABLE "ResultChainLadders" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultChainLadders Primary Key...';
ALTER TABLE "ResultChainLadders" ADD CONSTRAINT "PK_ResultChainLadders" PRIMARY KEY ("Id");