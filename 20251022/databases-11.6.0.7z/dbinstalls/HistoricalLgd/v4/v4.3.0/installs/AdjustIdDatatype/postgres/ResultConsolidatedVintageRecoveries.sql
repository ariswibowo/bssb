\echo '';
\echo 'Removing ResultConsolidatedVintageRecoveries Primary Key...';
ALTER TABLE "ResultConsolidatedVintageRecoveries" DROP CONSTRAINT "PK_ResultConsolidatedVintageRecoveries";

\echo '';
\echo 'Updating ResultConsolidatedVintageRecoveries Id column data type to BIGINT...';
ALTER TABLE "ResultConsolidatedVintageRecoveries" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultConsolidatedVintageRecoveries Primary Key...';
ALTER TABLE "ResultConsolidatedVintageRecoveries" ADD CONSTRAINT "PK_ResultConsolidatedVintageRecoveries" PRIMARY KEY ("Id");