PRINT N'';
PRINT N'Removing ResultVintages Primary Key...';
ALTER TABLE [ResultVintages] DROP CONSTRAINT [PK_ResultVintages];

PRINT N'';
PRINT N'Updating ResultVintages Id column data type to BIGINT...';
ALTER TABLE [ResultVintages] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultVintages Primary Key...';
ALTER TABLE [ResultVintages] ADD CONSTRAINT [PK_ResultVintages] PRIMARY KEY ([Id]);