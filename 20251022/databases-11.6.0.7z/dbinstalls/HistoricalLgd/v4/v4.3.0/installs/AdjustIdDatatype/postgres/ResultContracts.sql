\echo '';
\echo 'Removing ResultContracts Primary Key...';
ALTER TABLE "ResultContracts" DROP CONSTRAINT "PK_ResultContracts";

\echo '';
\echo 'Updating ResultContracts Id column data type to BIGINT...';
ALTER TABLE "ResultContracts" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultContracts Primary Key...';
ALTER TABLE "ResultContracts" ADD CONSTRAINT "PK_ResultContracts" PRIMARY KEY ("Id");