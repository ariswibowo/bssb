\echo '';
\echo 'Removing ResultConsolidatedChainLadderDefinitions Primary Key...';
ALTER TABLE "ResultConsolidatedChainLadderDefinitions" DROP CONSTRAINT "PK_ResultConsolidatedChainLadderDefinitions";

\echo '';
\echo 'Updating ResultConsolidatedChainLadderDefinitions Id column data type to BIGINT...';
ALTER TABLE "ResultConsolidatedChainLadderDefinitions" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultConsolidatedChainLadderDefinitions Primary Key...';
ALTER TABLE "ResultConsolidatedChainLadderDefinitions" ADD CONSTRAINT "PK_ResultConsolidatedChainLadderDefinitions" PRIMARY KEY ("Id");