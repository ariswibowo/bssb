\echo '';
\echo 'Removing ResultProcessed Primary Key...';
ALTER TABLE "ResultProcessed" DROP CONSTRAINT "PK_ResultProcessed";

\echo '';
\echo 'Updating ResultProcessed Id column data type to BIGINT...';
ALTER TABLE "ResultProcessed" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultProcessed Primary Key...';
ALTER TABLE "ResultProcessed" ADD CONSTRAINT "PK_ResultProcessed" PRIMARY KEY ("Id");