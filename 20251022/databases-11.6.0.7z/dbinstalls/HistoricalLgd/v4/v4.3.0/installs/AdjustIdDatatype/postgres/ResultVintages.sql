\echo '';
\echo 'Removing ResultVintages Primary Key...';
ALTER TABLE "ResultVintages" DROP CONSTRAINT "PK_ResultVintages";

\echo '';
\echo 'Updating ResultVintages Id column data type to BIGINT...';
ALTER TABLE "ResultVintages" ALTER COLUMN "Id" TYPE BIGINT;

\echo '';
\echo 'Adding ResultVintages Primary Key...';
ALTER TABLE "ResultVintages" ADD CONSTRAINT "PK_ResultVintages" PRIMARY KEY ("Id");