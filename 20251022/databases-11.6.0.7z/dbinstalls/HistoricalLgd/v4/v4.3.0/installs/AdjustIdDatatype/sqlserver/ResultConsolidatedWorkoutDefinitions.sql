PRINT N'';
PRINT N'Removing ResultConsolidatedWorkoutDefinitions Primary Key...';
ALTER TABLE [ResultConsolidatedWorkoutDefinitions] DROP CONSTRAINT [PK_ResultConsolidatedWorkoutDefinitions];

PRINT N'';
PRINT N'Updating ResultConsolidatedWorkoutDefinitions Id column data type to BIGINT...';
ALTER TABLE [ResultConsolidatedWorkoutDefinitions] ALTER COLUMN [Id] BIGINT;

PRINT N'';
PRINT N'Adding ResultConsolidatedWorkoutDefinitions Primary Key...';
ALTER TABLE [ResultConsolidatedWorkoutDefinitions] ADD CONSTRAINT [PK_ResultConsolidatedWorkoutDefinitions] PRIMARY KEY ([Id]);