DELETE
  FROM [dbo].[CalculationPolicies]
 WHERE [PolicyType] = 'PreflightChecks'
GO

BULK INSERT [dbo].[CalculationPolicies]
FROM '{data}/PreflightCheckPolicies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);