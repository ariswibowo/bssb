PRINT N'';
PRINT N'Dropping table Configurations...';
DROP TABLE IF EXISTS [dbo].[Configurations];
GO