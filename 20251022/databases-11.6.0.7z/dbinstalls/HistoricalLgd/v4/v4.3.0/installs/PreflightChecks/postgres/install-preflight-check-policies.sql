DELETE
  FROM "CalculationPolicies"
 WHERE "PolicyType" = 'PreflightChecks';

\copy "CalculationPolicies" FROM '{data}/PreflightCheckPolicies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;