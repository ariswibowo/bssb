\echo '';
\echo 'Terminating locks...';
SELECT pg_terminate_backend(pg_stat_activity.pid)
FROM pg_stat_activity
WHERE query LIKE '%Configurations%'
  AND pid <> pg_backend_pid();

\echo '';
\echo 'Dropping table Configurations...';
DROP TABLE IF EXISTS "Configurations";