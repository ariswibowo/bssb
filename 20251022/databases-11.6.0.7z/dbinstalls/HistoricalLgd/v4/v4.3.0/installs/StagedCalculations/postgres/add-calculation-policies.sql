\echo '';
\echo 'Dropping table CalculationPolicies...';
DROP TABLE IF EXISTS "CalculationPolicies";

CREATE TABLE "CalculationPolicies" (
    "PolicyId" uuid NOT NULL,
    "PolicyType" varchar(50) NOT NULL,
    "Description" varchar(300) NOT NULL,
    "DefaultPolicy" text NOT NULL,
    "ActivePolicy" text NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);

ALTER TABLE ONLY "CalculationPolicies"
    ADD CONSTRAINT "PK_CalculationPolicies" PRIMARY KEY ("PolicyId");

ALTER TABLE "CalculationPolicies" OWNER TO "Empyrean";

\copy "CalculationPolicies" FROM '{data}/CalculationPolicies.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;
