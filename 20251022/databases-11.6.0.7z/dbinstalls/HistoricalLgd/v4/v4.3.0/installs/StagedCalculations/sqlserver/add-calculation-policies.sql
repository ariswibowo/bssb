PRINT N'';
PRINT N'Dropping table CalculationPolicies...';
DROP TABLE IF EXISTS [dbo].[CalculationPolicies];
GO

CREATE TABLE [dbo].[CalculationPolicies] (
    [PolicyId] uniqueidentifier NOT NULL,
    [PolicyType] nvarchar(50) NOT NULL,
    [Description] nvarchar(300) NOT NULL,
    [DefaultPolicy] nvarchar(max) NOT NULL,
    [ActivePolicy] nvarchar(max) NOT NULL,
    [CreatedBy] uniqueidentifier NOT NULL,
    [CreatedWhen] datetime NOT NULL,
    [LastModifiedBy] uniqueidentifier NOT NULL,
    [LastModifiedWhen] datetime NOT NULL
);

ALTER TABLE [dbo].[CalculationPolicies]
    ADD CONSTRAINT [PK_CalculationPolicies] PRIMARY KEY ([PolicyId]);
GO

BULK INSERT [dbo].[CalculationPolicies]
FROM '{data}/CalculationPolicies.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO