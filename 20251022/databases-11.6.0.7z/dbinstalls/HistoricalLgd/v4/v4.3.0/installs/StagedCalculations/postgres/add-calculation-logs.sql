\echo '';
\echo 'Dropping table CalculationLogs...';
DROP TABLE IF EXISTS "CalculationLogs";

CREATE TABLE "CalculationLogs" (
    "LogId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL,
    "Message" text NOT NULL,
    "Data" text NULL
);

ALTER TABLE ONLY "CalculationLogs"
    ADD CONSTRAINT "PK_CalculationLogs" PRIMARY KEY ("LogId");

ALTER TABLE ONLY "CalculationLogs"
    ADD CONSTRAINT "FK_CalculationLogs_Calculations_CalculationId" FOREIGN KEY ("CalculationId") REFERENCES "Calculations"("CalculationId") ON DELETE CASCADE;

ALTER TABLE "CalculationLogs" OWNER TO "Empyrean";

CREATE INDEX "IX_CalculationLogs_CalculationId" ON "CalculationLogs" USING btree ("CalculationId");