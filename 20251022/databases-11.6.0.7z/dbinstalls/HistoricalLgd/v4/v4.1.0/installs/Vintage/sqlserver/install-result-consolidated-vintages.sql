CREATE TABLE [dbo].[ResultConsolidatedVintages] (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ConsolidatedVintageId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [NumContracts] int NOT NULL,
    [OutstandingAmount] numeric(20,2) NOT NULL,
    [DebtSalesAmount] numeric(20,2) NOT NULL,
    [DiscountedDebtSalesAmount] numeric(20,2) NOT NULL,
    [DebtCollectionCost] numeric(20,2) NOT NULL,
    [DiscountedDebtCollectionCost] numeric(20,2) NOT NULL,
    [LitigationCost] numeric(20,2) NOT NULL,
    [DiscountedLitigationCost] numeric(20,2) NOT NULL
);
GO

ALTER TABLE [dbo].[ResultConsolidatedVintages] ADD CONSTRAINT [PK_ResultConsolidatedVintages] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedVintages_HashCode] ON [dbo].[ResultConsolidatedVintages]([HashCode]);
GO