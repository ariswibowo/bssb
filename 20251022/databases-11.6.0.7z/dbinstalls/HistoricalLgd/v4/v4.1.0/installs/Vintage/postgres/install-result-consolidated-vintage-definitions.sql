CREATE SEQUENCE "ResultConsolidatedVintageDefinitions_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedVintageDefinitions_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultConsolidatedVintageDefinitions" (
    "Id" integer DEFAULT nextval('"ResultConsolidatedVintageDefinitions_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedVintageId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "SegmentId" uuid NOT NULL,
    "SegmentName" varchar(100) NOT NULL,
    "Lgd"  numeric(12, 9) NOT NULL,
    "Data" text NOT NULL
);      

ALTER TABLE ONLY "ResultConsolidatedVintageDefinitions"
    ADD CONSTRAINT "PK_ResultConsolidatedVintageDefinitions" PRIMARY KEY ("Id");

CREATE UNIQUE INDEX "IX_ResultConsolidatedVintageDefinitions_CalcId_SegmentId" 
    ON "ResultConsolidatedVintageDefinitions" USING btree ("CalculationId", "SegmentId");

ALTER TABLE "ResultConsolidatedVintageDefinitions" OWNER TO "Empyrean";