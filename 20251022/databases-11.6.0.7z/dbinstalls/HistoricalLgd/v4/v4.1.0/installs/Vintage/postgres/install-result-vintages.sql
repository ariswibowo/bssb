CREATE SEQUENCE "ResultVintages_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultVintages_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultVintages" (
    "Id" integer DEFAULT nextval('"ResultVintages_Id_seq"'::regclass) NOT NULL,
    "ResultId" uuid NOT NULL,
    "SegmentId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "DebtSalesAmount" numeric(20, 2) NOT NULL,
    "DiscountedDebtSalesAmount" numeric(20, 2) NOT NULL,
    "RecoveryIncrements" text NOT NULL
);

ALTER TABLE ONLY "ResultVintages" ADD CONSTRAINT "PK_ResultVintages" PRIMARY KEY ("Id");

ALTER TABLE "ResultVintages" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultVintages_ResultId" ON "ResultVintages" USING btree ("ResultId");