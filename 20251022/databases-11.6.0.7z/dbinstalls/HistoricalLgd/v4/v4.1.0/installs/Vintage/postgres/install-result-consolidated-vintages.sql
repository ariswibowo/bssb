CREATE SEQUENCE "ResultConsolidatedVintages_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedVintages_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultConsolidatedVintages" (
    "Id" integer DEFAULT nextval('"ResultConsolidatedVintages_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedVintageId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "HashCode" varchar(256),
    "NumContracts" integer NOT NULL,
    "OutstandingAmount" numeric(20, 2) NOT NULL,
    "DebtSalesAmount" numeric(20, 2) NOT NULL,
    "DiscountedDebtSalesAmount" numeric(20, 2) NOT NULL,
    "DebtCollectionCost" numeric(20, 2) NOT NULL,
    "DiscountedDebtCollectionCost" numeric(20, 2) NOT NULL,
    "LitigationCost" numeric(20, 2) NOT NULL,
    "DiscountedLitigationCost" numeric(20, 2) NOT NULL
);

ALTER TABLE ONLY "ResultConsolidatedVintages"
    ADD CONSTRAINT "PK_ResultConsolidatedVintages" PRIMARY KEY ("Id");

ALTER TABLE "ResultConsolidatedVintages" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultConsolidatedVintages_HashCode" ON "ResultConsolidatedVintages" USING btree ("HashCode");