\echo ''
\echo 'Installing new DashboardTypes...';

DELETE
  FROM "DashboardTypes"
 WHERE "DashboardType" IN (
     'VintageLgdResult',
     'VintageLgdExtract'
 );

\copy "DashboardTypes" FROM '{data}/VintageDashboardTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;