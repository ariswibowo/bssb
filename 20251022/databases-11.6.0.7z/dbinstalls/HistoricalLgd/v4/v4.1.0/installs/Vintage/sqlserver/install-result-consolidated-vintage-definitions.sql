CREATE TABLE [dbo].[ResultConsolidatedVintageDefinitions] (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ConsolidatedVintageId] uniqueidentifier NOT NULL,
    [CalculationId] uniqueidentifier NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [SegmentName] nvarchar(100) NOT NULL,
    [Lgd] numeric(12,9) NOT NULL,
    [Data] nvarchar(max) NOT NULL
);
GO

ALTER TABLE [dbo].[ResultConsolidatedVintageDefinitions] ADD CONSTRAINT [PK_ResultConsolidatedVintageDefinitions] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedVintageDefinitions_CalcId_SegmentId] ON [dbo].[ResultConsolidatedVintageDefinitions]([CalculationId], [SegmentId]);
GO