CREATE TABLE [dbo].[ResultConsolidatedVintageRecoveries] (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ConsolidatedVintageId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [RecoveryDate] datetime NOT NULL,
    [HashCode] nvarchar(256) NOT NULL,
    [RecoveryAmount] numeric(20,2) NOT NULL,
    [DiscountedRecoveryAmount] numeric(20,2) NOT NULL
);
GO

ALTER TABLE [dbo].[ResultConsolidatedVintageRecoveries] ADD CONSTRAINT [PK_ResultConsolidatedVintageRecoveries] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_ResultConsolidatedVintageRecoveries_HashCode] ON [dbo].[ResultConsolidatedVintageRecoveries]([HashCode]);
GO