CREATE TABLE [dbo].[ResultVintages] (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ResultId] uniqueidentifier NOT NULL,
    [SegmentId] uniqueidentifier NOT NULL,
    [DefaultDate] datetime NOT NULL,
    [OutstandingAmount] numeric(20, 2) NOT NULL,
    [DebtSalesAmount] numeric(20, 2) NOT NULL,
    [DiscountedDebtSalesAmount] numeric(20, 2) NOT NULL,
    [RecoveryIncrements] nvarchar(max) NOT NULL
);
GO

ALTER TABLE [dbo].[ResultVintages] ADD CONSTRAINT [PK_ResultVintages] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_ResultVintages_ResultId] ON [dbo].[ResultVintages]([ResultId]);
GO