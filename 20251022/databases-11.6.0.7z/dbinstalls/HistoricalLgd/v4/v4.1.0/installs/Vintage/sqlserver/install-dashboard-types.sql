PRINT N''
PRINT N'Installing new DashboardTypes...'
GO

DELETE
  FROM [dbo].[DashboardTypes]
 WHERE [DashboardType] IN (
     'VintageLgdResult',
     'VintageLgdExtract'
 );
GO

BULK INSERT [dbo].[DashboardTypes]
FROM '{data}/VintageDashboardTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO