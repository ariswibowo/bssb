CREATE SEQUENCE "ResultConsolidatedVintageRecoveries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultConsolidatedVintageRecoveries_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultConsolidatedVintageRecoveries" (
    "Id" integer DEFAULT nextval('"ResultConsolidatedVintageRecoveries_Id_seq"'::regclass) NOT NULL,
    "ConsolidatedVintageId" uuid NOT NULL,
    "DefaultDate" timestamp without time zone NOT NULL,
    "RecoveryDate" timestamp without time zone NOT NULL,
    "HashCode" varchar(256),
    "RecoveryAmount" numeric(20, 2) NOT NULL,
    "DiscountedRecoveryAmount" numeric(20, 2) NOT NULL
);

ALTER TABLE ONLY "ResultConsolidatedVintageRecoveries"
    ADD CONSTRAINT "PK_ResultConsolidatedVintageRecoveries" PRIMARY KEY ("Id");

ALTER TABLE "ResultConsolidatedVintageRecoveries" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultConsolidatedVintageRecoveries_HashCode" ON "ResultConsolidatedVintageRecoveries" USING btree ("HashCode");