# README

**Release: HistoricalLgd V4.1.0**

## Release Features & Fixes

- [Feature: Vintage](#feature-vintage)

## Feature: Vintage

- Add new 4 tables for the Vintage method calculation
- Add new 2 dashboard types

[top](#readme)