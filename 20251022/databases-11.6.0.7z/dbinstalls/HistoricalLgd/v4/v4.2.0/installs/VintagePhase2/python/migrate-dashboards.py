import dbhelper
import json

def main(config):

    # generate build script file
    build = dbhelper.init_build("migrate-dashboards", config)

    # get all result consolidated chain ladder definitions
    chain_ladder_definitions_cursor = dbhelper.get_data("get-result-consolidated-chain-ladder-definitions", config)
    chain_ladder_definition_cols = [column[0] for column in chain_ladder_definitions_cursor.description]

    # fetch all result consolidated chain ladder definitions
    chain_ladder_definitions = chain_ladder_definitions_cursor.fetchall()

    # get all result consolidated vintage definitions
    vintage_definitions_cursor = dbhelper.get_data("get-result-consolidated-vintage-definitions", config)
    vintage_definition_cols = [column[0] for column in vintage_definitions_cursor.description]

    # fetch all result consolidated chain ladder definitions
    vintage_definitions = vintage_definitions_cursor.fetchall()

    # prepare updating sql template
    update_sql = dbhelper.get_sql("update-dashboards", config)

    # declare dashboard type id
    chain_ladder_lgd_result_dashboard_type_id = 'debe9c0c-6692-417e-adc5-1b5d513d4731'
    chain_ladder_lgd_extract_dashboard_type_id = 'e00c5a59-7724-43d0-ae25-2c43ccafd3ef'
    vintage_lgd_result_dashboard_type_id = '45f7c504-569f-435c-9f47-6c6a02190db8'

    # get dashboards
    dashboards_cursor = dbhelper.get_data("get-dashboards", config)
    dashboard_cols = [column[0] for column in dashboards_cursor.description]

    # fetch dashboards
    dashboards = dashboards_cursor.fetchall()

    # loop through dashboards
    for dashboard_row in dashboards:
        
        dashboard = dbhelper.get_row_dict(dashboard_row, dashboard_cols, ['Context'])

        # chain ladder lgd result
        if dashboard['DashboardTypeId'].lower() == chain_ladder_lgd_result_dashboard_type_id:
            migrate_chain_ladder_result(dashboard, chain_ladder_definitions, chain_ladder_definition_cols, update_sql, build)
        
        # chain ladder lgd extract
        elif dashboard['DashboardTypeId'].lower() == chain_ladder_lgd_extract_dashboard_type_id:
            migrate_chain_ladder_extract(dashboard, update_sql, build)
            
        # vintage lgd result
        elif dashboard['DashboardTypeId'].lower() == vintage_lgd_result_dashboard_type_id:
            migrate_vintage_result(dashboard, vintage_definitions, vintage_definition_cols, update_sql, build)

    # run the build script
    dbhelper.run_build(build, config)

    # dispose
    dbhelper.dispose(chain_ladder_definitions_cursor, config)
    dbhelper.dispose(vintage_definitions_cursor, config)
    dbhelper.dispose(dashboards_cursor, config)

    return

def migrate_chain_ladder_result(dashboard, definitions, cols, update_sql, build):

    # check if costs already migrated to the new structure
    if not isinstance(dashboard['Data'], dict):

        newDashboardData = {
            "consolidationDetails": None,
            "results": {
                "costColumns": [
                    {
                        "key": "commission",
                        "value": "Commission"
                    },
                    {
                        "key": "discountedcommission",
                        "value": "Discounted Commission"
                    },
                    {
                        "key": "litigationcost",
                        "value": "Litigation Cost"
                    },
                    {
                        "key": "discountedlitigationcost",
                        "value": "Discounted Litigation Cost"
                    }
                ],
                "data": []
            }
        }
        
        for definition_row in definitions:

            definition = dbhelper.get_row_dict(definition_row, cols)

            if definition['CalculationId'].lower() == dashboard['CalculationId'].lower() and definition['SegmentId'].lower() == dashboard['Context']['segmentId'].lower():
                
                methodConfiguration = definition['Data']['methodConfiguration']
                chainLadderParameters = methodConfiguration['chainLadderParameters']
                debtSales = methodConfiguration['debtSales']

                newDashboardData['consolidationDetails'] = {
                    "chainLadderParameters": [
                        {
                            "rows": [
                                {
                                    "name": "Historical Observation Window",
                                    "value": GetWindowTimeText(chainLadderParameters['observationWindowTimeUnitMultiplicity'],
                                        chainLadderParameters['observationWindowTimeUnit'])
                                },
                                {
                                    "name": "Lgd Premium",
                                    "value": chainLadderParameters['lgdPremium']
                                }
                            ]
                        },
                        {
                            "rows": [
                                {
                                    "name": "Performance Window",
                                    "value": GetWindowTimeText(chainLadderParameters['performanceWindowTimeUnitMultiplicity'],
                                        chainLadderParameters['performanceWindowTimeUnit'])
                                },
                                {}
                            ]
                        }
                    ],
                    "debtSales": [
                        {
                            "rows": [
                                {
                                    "name": "Debt Sales Discount Time Window",
                                    "value": GetWindowTimeText(debtSales['discountTimeUnitMultiplicity'],
                                        debtSales['discountTimeUnit'])
                                },
                                {
                                    "name": "Debt Sales Discount Factor",
                                    "value": debtSales['discountFactor']
                                }
                            ]
                        },
                        {
                            "rows": [
                                {
                                    "name": "Debt Sales Percentage",
                                    "value": debtSales['percentage']
                                },
                                {}
                            ]
                        }
                    ],
                    "costs": methodConfiguration['costs']
                }

                break

        # loop through items in dashboard data
        for item in dashboard['Data']:

            newDashboardData['results']['data'].append({
                "firstDefaultDate": item['defaultDate'],
                "contracts": item['numContracts'],
                "outstandingAmount": item['outstandingAmount'],
                "observedRecovery": item['observedRecovery'],
                "expectedRecovery": item['expectedRecovery'],
                "salesOfDebt": item['debtSales'],
                "discountedSalesOfDebt": item['discountedDebtSales'],
                "commission": item['commission'],
                "discountedcommission": item['discountedCommission'],
                "litigationcost": item['litigationCost'],
                "discountedlitigationcost":item['discountedLitigationCost'],
                "timeWeight": item['timeWeight'],
                "ultimateExpectedRecovery": item['ultimateExpectedRecoveryPercentage'],
                "timeWeightedUltimateExpectedRecovery": item['lgd'],
                "costWarning": []
            })

        # update dashboard data
        sql = update_sql.format(data=json.dumps(newDashboardData), dashboardId=dashboard['DashboardId'])      
        dbhelper.write_build(build, sql)

def migrate_chain_ladder_extract(dashboard, update_sql, build):

    # get consolidatedChainLadders
    consolidatedChainLadders = dashboard['Data'].get('consolidatedChainLadders')

    # touch only when data present
    if consolidatedChainLadders is not None:

        newConsolidatedChainLadders = []

        # loop through consolidatedChainLadders
        for consolidatedChainLadder in consolidatedChainLadders:

            if 'costs' not in consolidatedChainLadder:
                newConsolidatedChainLadders.append({
                    "consolidatedChainLadderId": consolidatedChainLadder['consolidatedChainLadderId'],
                    "defaultDate": consolidatedChainLadder['defaultDate'],
                    "numContracts": consolidatedChainLadder['numContracts'],
                    "outstandingAmount": consolidatedChainLadder['outstandingAmount'],
                    "observedRecovery": consolidatedChainLadder['observedRecovery'],
                    "expectedRecovery": consolidatedChainLadder['expectedRecovery'],
                    "debtSales": consolidatedChainLadder['debtSales'],
                    "discountedDebtSales": consolidatedChainLadder['discountedDebtSales'],
                    "costs": [
                        {
                            "name": "Commission",
                            "amount": consolidatedChainLadder['commission']
                        },
                        {
                            "name": "Discounted Commission",
                            "amount": consolidatedChainLadder['discountedCommission']
                        },
                        {
                            "name": "Litigation Cost",
                            "amount": consolidatedChainLadder['litigationCost']
                        },
                        {
                            "name": "Discounted Litigation Cost",
                            "amount": consolidatedChainLadder['discountedLitigationCost']
                        }
                    ],
                    "timeWeight": consolidatedChainLadder['timeWeight'],
                    "ultimateExpectedRecoveryPercentage": consolidatedChainLadder['ultimateExpectedRecoveryPercentage'],
                    "lgd": consolidatedChainLadder['lgd'],
                    "consolidatedChainLadderRecoveries": consolidatedChainLadder['consolidatedChainLadderRecoveries']
                })

            else:
                newConsolidatedChainLadders.append(consolidatedChainLadder)

        dashboard['Data']['consolidatedChainLadders'] = newConsolidatedChainLadders

        # update dashboard data
        sql = update_sql.format(data=json.dumps(dashboard['Data']), dashboardId=dashboard['DashboardId']) 
        dbhelper.write_build(build, sql)

def migrate_vintage_result(dashboard, definitions, cols, update_sql, build):

    # get consolidationDetails
    consolidationDetails = dashboard['Data'].get('consolidationDetails')

    # touch only when data present
    if consolidationDetails is not None:
        
        calculationId = dashboard['CalculationId']
        segmentId = dashboard['Context']['segmentId']

        for definition_row in definitions:

            definition = dbhelper.get_row_dict(definition_row, cols)

            if definition['CalculationId'].lower() == dashboard['CalculationId'].lower() and definition['SegmentId'].lower() == dashboard['Context']['segmentId'].lower():             
                dashboard['Data']['consolidationDetails']['costs'] = definition['Data']['methodConfiguration']['costs']        
                break

    # get results
    results = dashboard['Data'].get('results')

    # touch only when data present
    if results is not None:

        # get data
        data = results.get('data')
        
        # touch only when data present
        if data is not None:

            # loop through items in data
            for item in data:
                item['costWarning'] = []

            results['data'] = data
        
        dashboard['Data']['results'] = results

        # update dashboard data
        sql = update_sql.format(data=json.dumps(dashboard['Data']), dashboardId=dashboard['DashboardId'])
        dbhelper.write_build(build, sql)

def GetWindowTimeText(unitMultiplicity, unit):

    if unit == "M":
        if unitMultiplicity > 1:
            return str(unitMultiplicity) + " Months"
        else:
            return str(unitMultiplicity) + " Month"
    elif unit == "Q":
        if unitMultiplicity > 1:
            return str(unitMultiplicity) + " Quarters"
        else:
            return str(unitMultiplicity) + " Quarter"
    elif unit == "Y":
        if unitMultiplicity > 1:
            return str(unitMultiplicity) + " Years"
        else:
            return str(unitMultiplicity) + " Year"
    else:
        return str(unitMultiplicity) + " " + unit