PRINT N'';
PRINT N'Updating ResultConsolidatedVintages...';
GO

UPDATE [dbo].[ResultConsolidatedVintages]
   SET [Data] = '{data}'
 WHERE [Id] = '{id}';
GO