\echo '';
\echo 'Updating ResultConsolidatedVintages...';

UPDATE "ResultConsolidatedVintages"
   SET "Data" = '{data}'
 WHERE "Id" = '{id}';