IF EXISTS (SELECT 1 FROM sys.columns WHERE Name = 'DebtCollectionCost' AND OBJECT_ID = OBJECT_ID('dbo.ResultConsolidatedVintages'))
BEGIN
	EXEC('SELECT [Id]
    ,[DebtCollectionCost]
    ,[DiscountedDebtCollectionCost]
    ,[LitigationCost]
    ,[DiscountedLitigationCost]
  FROM [dbo].[ResultConsolidatedVintages]
  WHERE [Data] IS NULL;');
END