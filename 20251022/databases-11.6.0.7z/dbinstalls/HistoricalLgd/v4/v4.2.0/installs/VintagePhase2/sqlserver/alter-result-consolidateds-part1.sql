PRINT N''
PRINT N'Altering ResultConsolidateds, adding Data property...'
GO

IF COL_LENGTH('ResultConsolidatedVintages', 'Data') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedVintages] ADD [Data] nvarchar(max);
END
GO

IF COL_LENGTH('ResultConsolidatedChainLadders', 'Data') IS NULL
BEGIN
    ALTER TABLE [dbo].[ResultConsolidatedChainLadders] ADD [Data] nvarchar(max);
END
GO