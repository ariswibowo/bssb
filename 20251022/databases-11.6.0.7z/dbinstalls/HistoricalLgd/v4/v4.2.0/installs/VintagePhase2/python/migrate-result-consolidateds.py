import dbhelper
import json

def main(config):

    # generate build script file
    build = dbhelper.init_build("migrate-result-consolidateds", config)

    # migrate result consolidated vintage definitions
    migrate_data("update-result-consolidated-vintages",
        "get-result-consolidated-vintages", build, config)

    # migrate result consolidated chainladder definitions
    migrate_data("update-result-consolidated-chain-ladders",
        "get-result-consolidated-chain-ladders", build, config)

    # run the build script
    dbhelper.run_build(build, config)

    return

def migrate_data(update_script, get_script, build, config):

    # prepare updating sql template
    update_sql = dbhelper.get_sql(update_script, config)

    # get all result consolidateds
    consolidateds_cursor = dbhelper.get_data(get_script, config)
    cols = [column[0] for column in consolidateds_cursor.description]

    if consolidateds_cursor.rowcount != 0:

        # fetch all result consolidateds
        consolidateds = consolidateds_cursor.fetchall()

        # loop through all result consolidateds
        for consolidated_row in consolidateds:

            consolidated = dbhelper.get_row_dict(consolidated_row, cols)
            
            # touch only when data present
            if consolidated['Id'] is not None:
                
                data = {
                    "costs": [
                        {
                            "costTypeId": "a1ab0992-8e23-4e49-a4b5-1bffa22e8ea5",
                            "costTypeCode": "Commission",
                            "costTypeName": "Commission",
                            # need to convert to string because object of type decimal is not JSON serializable
                            "amount": str(consolidated['DebtCollectionCost']),
                            "discountedAmount": str(consolidated['DiscountedDebtCollectionCost'])
                        },
                        {
                            "costTypeId": "f19fa45d-595e-4b65-9254-9c1dd4a91553",
                            "costTypeCode": "LitigationCost",
                            "costTypeName": "Litigation Cost",
                            # need to convert to string because object of type decimal is not JSON serializable
                            "amount": str(consolidated['LitigationCost']),
                            "discountedAmount": str(consolidated['DiscountedLitigationCost'])
                        }
                    ],
                    "costWarnings": []
                }

                data = json.dumps(data)

                # remove double quotes out from string amount and discounted amount values to make it as a real decimal
                data = data.replace("\"amount\": \"","\"amount\": ")
                data = data.replace("\", \"discountedAmount\": \"",", \"discountedAmount\": ")
                data = data.replace("\"}","}")

                # update result consolidated
                sql = update_sql.format(data=data, id=consolidated['Id'])
                dbhelper.write_build(build, sql)
    
    # dispose
    dbhelper.dispose(consolidateds_cursor, config)