CREATE OR REPLACE FUNCTION get_result_consolidated_vintages()
RETURNS SETOF "ResultConsolidatedVintages" LANGUAGE plpgsql as $$
BEGIN
    IF EXISTS (SELECT column_name FROM information_schema.columns WHERE table_name='ResultConsolidatedVintages' AND column_name='DebtCollectionCost') THEN
        RETURN QUERY SELECT * FROM "ResultConsolidatedVintages" WHERE "Data" IS NULL;
    END IF;
END;
$$;

SELECT * FROM get_result_consolidated_vintages();