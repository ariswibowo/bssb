CREATE OR REPLACE FUNCTION get_result_consolidated_chain_ladders()
RETURNS SETOF "ResultConsolidatedChainLadders" LANGUAGE plpgsql as $$
BEGIN
    IF EXISTS (SELECT column_name FROM information_schema.columns WHERE table_name='ResultConsolidatedChainLadders' AND column_name='DebtCollectionCost') THEN
        RETURN QUERY SELECT * FROM "ResultConsolidatedChainLadders" WHERE "Data" IS NULL;
    END IF;
END;
$$;

SELECT * FROM get_result_consolidated_chain_ladders();