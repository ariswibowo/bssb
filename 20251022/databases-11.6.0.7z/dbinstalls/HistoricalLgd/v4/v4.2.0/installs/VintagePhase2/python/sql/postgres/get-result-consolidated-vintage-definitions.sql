SELECT "Id"
      ,"Data"
      ,"CalculationId"
      ,"SegmentId"
  FROM "ResultConsolidatedVintageDefinitions";