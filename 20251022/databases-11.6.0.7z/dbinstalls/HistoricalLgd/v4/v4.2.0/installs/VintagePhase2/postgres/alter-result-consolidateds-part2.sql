\echo '';
\echo 'Altering ResultConsolidateds, dropping Cost properties...';

SELECT pg_terminate_backend(pid) 
FROM pg_stat_activity 
WHERE datname='{database}' AND state = 'idle in transaction';

ALTER TABLE "ResultConsolidatedVintages" ALTER COLUMN "Data" SET NOT NULL;
ALTER TABLE "ResultConsolidatedVintages" DROP COLUMN IF EXISTS "DebtCollectionCost";
ALTER TABLE "ResultConsolidatedVintages" DROP COLUMN IF EXISTS "DiscountedDebtCollectionCost";
ALTER TABLE "ResultConsolidatedVintages" DROP COLUMN IF EXISTS "LitigationCost";
ALTER TABLE "ResultConsolidatedVintages" DROP COLUMN IF EXISTS "DiscountedLitigationCost";

ALTER TABLE "ResultConsolidatedChainLadders" ALTER COLUMN "Data" SET NOT NULL;
ALTER TABLE "ResultConsolidatedChainLadders" DROP COLUMN IF EXISTS "DebtCollectionCost";
ALTER TABLE "ResultConsolidatedChainLadders" DROP COLUMN IF EXISTS "DiscountedDebtCollectionCost";
ALTER TABLE "ResultConsolidatedChainLadders" DROP COLUMN IF EXISTS "LitigationCost";
ALTER TABLE "ResultConsolidatedChainLadders" DROP COLUMN IF EXISTS "DiscountedLitigationCost";