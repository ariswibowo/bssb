PRINT N'';
PRINT N'Updating ResultConsolidatedChainLadderDefinitions...';
GO

UPDATE [dbo].[ResultConsolidatedChainLadderDefinitions]
   SET [Data] = '{data}'
 WHERE [Id] = '{id}';
GO