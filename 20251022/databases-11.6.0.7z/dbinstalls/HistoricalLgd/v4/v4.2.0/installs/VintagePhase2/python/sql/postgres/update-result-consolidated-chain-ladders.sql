\echo '';
\echo 'Updating ResultConsolidatedChainLadders...';

UPDATE "ResultConsolidatedChainLadders"
   SET "Data" = '{data}'
 WHERE "Id" = '{id}';