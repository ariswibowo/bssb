IF EXISTS (SELECT 1 FROM sys.columns WHERE Name = 'DebtCollectionCost' AND OBJECT_ID = OBJECT_ID('dbo.ResultConsolidatedChainLadders'))
BEGIN
	EXEC('SELECT [Id]
    ,[DebtCollectionCost]
    ,[DiscountedDebtCollectionCost]
    ,[LitigationCost]
    ,[DiscountedLitigationCost]
  FROM [dbo].[ResultConsolidatedChainLadders]
  WHERE [Data] IS NULL;');
END