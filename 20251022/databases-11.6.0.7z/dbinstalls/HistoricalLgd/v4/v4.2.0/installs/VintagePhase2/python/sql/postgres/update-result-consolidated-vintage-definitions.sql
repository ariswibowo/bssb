\echo '';
\echo 'Updating ResultConsolidatedVintageDefinitions...';

UPDATE "ResultConsolidatedVintageDefinitions"
   SET "Data" = '{data}'
 WHERE "Id" = '{id}';