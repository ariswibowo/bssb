PRINT N'';
PRINT N'Updating Dashboards...';
GO

UPDATE [dbo].[Dashboards]
   SET [Data] = '{data}'
 WHERE [DashboardId] = '{dashboardId}';
GO