PRINT N'';
PRINT N'Updating ResultConsolidatedChainLadders...';
GO

UPDATE [dbo].[ResultConsolidatedChainLadders]
   SET [Data] = '{data}'
 WHERE [Id] = '{id}';
GO