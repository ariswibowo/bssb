\echo '';
\echo 'Updating Dashboards...';

UPDATE "Dashboards"
   SET "Data" = '{data}'
 WHERE "DashboardId" = '{dashboardId}';