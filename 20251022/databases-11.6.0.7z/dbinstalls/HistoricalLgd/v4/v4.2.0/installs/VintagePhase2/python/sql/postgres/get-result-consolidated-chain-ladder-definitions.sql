SELECT "Id"
      ,"Data"
      ,"CalculationId"
      ,"SegmentId"
  FROM "ResultConsolidatedChainLadderDefinitions";