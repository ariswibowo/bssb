PRINT N''
PRINT N'Altering ResultConsolidateds, dropping Cost properties...'
GO

ALTER TABLE [dbo].[ResultConsolidatedVintages] ALTER COLUMN [Data] nvarchar(max) NOT NULL;
GO
ALTER TABLE [dbo].[ResultConsolidatedVintages] DROP COLUMN IF EXISTS [DebtCollectionCost];
GO
ALTER TABLE [dbo].[ResultConsolidatedVintages] DROP COLUMN IF EXISTS [DiscountedDebtCollectionCost];
GO
ALTER TABLE [dbo].[ResultConsolidatedVintages] DROP COLUMN IF EXISTS [LitigationCost];
GO
ALTER TABLE [dbo].[ResultConsolidatedVintages] DROP COLUMN IF EXISTS [DiscountedLitigationCost];
GO

ALTER TABLE [dbo].[ResultConsolidatedChainLadders] ALTER COLUMN [Data] nvarchar(max) NOT NULL;
GO
ALTER TABLE [dbo].[ResultConsolidatedChainLadders] DROP COLUMN IF EXISTS [DebtCollectionCost];
GO
ALTER TABLE [dbo].[ResultConsolidatedChainLadders] DROP COLUMN IF EXISTS [DiscountedDebtCollectionCost];
GO
ALTER TABLE [dbo].[ResultConsolidatedChainLadders] DROP COLUMN IF EXISTS [LitigationCost];
GO
ALTER TABLE [dbo].[ResultConsolidatedChainLadders] DROP COLUMN IF EXISTS [DiscountedLitigationCost];
GO