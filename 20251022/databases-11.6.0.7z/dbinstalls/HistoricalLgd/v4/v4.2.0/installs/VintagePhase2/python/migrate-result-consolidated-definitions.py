import dbhelper
import json

def main(config):

    # generate build script file
    build = dbhelper.init_build("migrate-result-consolidated-definitions", config)

    # migrate result consolidated vintage definitions
    migrate_data("update-result-consolidated-vintage-definitions",
        "get-result-consolidated-vintage-definitions", build, config)

    # migrate result consolidated chainladder definitions
    migrate_data("update-result-consolidated-chain-ladder-definitions",
        "get-result-consolidated-chain-ladder-definitions", build, config)

    # run the build script
    dbhelper.run_build(build, config)

    return

def migrate_data(update_script, get_script, build, config):

    # prepare updating sql template
    update_sql = dbhelper.get_sql(update_script, config)

    # get all result consolidated definitions
    definitions_cursor = dbhelper.get_data(get_script, config)
    cols = [column[0] for column in definitions_cursor.description]

    # fetch all result consolidated definitions
    definitions = definitions_cursor.fetchall()

    # loop through all result consolidateds
    for definition_row in definitions:
        
        definition = dbhelper.get_row_dict(definition_row, cols)

        # get costs data
        costs = definition['Data']['methodConfiguration']['costs']

        # check if costs already migrated to the new structure
        if isinstance(costs, dict):
            
            # update costs as the new structure
            definition['Data']['methodConfiguration']['costs'] = [
                {
                    "costTypeId": "a1ab0992-8e23-4e49-a4b5-1bffa22e8ea5",
                    "costTypeCode": "Commission",
                    "costTypeName": "Commission",
                    "costLevel": "Entity",
                    "discountTimeUnitMultiplicity": costs['commissionDiscountTimeUnitMultiplicity'],
                    "discountTimeUnit": costs['commissionDiscountTimeUnit'],
                    "discountFactor": costs['discountFactor'],
                    "costNotFoundAction": "AssumeZero"
                },
                {
                    "costTypeId": "f19fa45d-595e-4b65-9254-9c1dd4a91553",
                    "costTypeCode": "LitigationCost",
                    "costTypeName": "Litigation Cost",
                    "costLevel": "Entity",
                    "discountTimeUnitMultiplicity": costs['litigationDiscountTimeUnitMultiplicity'],
                    "discountTimeUnit": costs['litigationDiscountTimeUnit'],
                    "discountFactor": costs['discountFactor'],
                    "costNotFoundAction": "AssumeZero"
                }
            ]

            # update method
            sql = update_sql.format(data=json.dumps(definition['Data']), id=definition['Id'])
            dbhelper.write_build(build, sql)

    # dispose
    dbhelper.dispose(definitions_cursor, config)