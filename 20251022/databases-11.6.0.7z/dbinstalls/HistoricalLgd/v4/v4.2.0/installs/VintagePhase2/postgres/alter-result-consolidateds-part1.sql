\echo '';
\echo 'Altering ResultConsolidateds, adding Data property...';

ALTER TABLE "ResultConsolidatedVintages" ADD COLUMN IF NOT EXISTS "Data" text;

ALTER TABLE "ResultConsolidatedChainLadders" ADD COLUMN IF NOT EXISTS "Data" text;