\echo '';
\echo 'Updating ResultConsolidatedChainLadderDefinitions...';

UPDATE "ResultConsolidatedChainLadderDefinitions"
   SET "Data" = '{data}'
 WHERE "Id" = '{id}';