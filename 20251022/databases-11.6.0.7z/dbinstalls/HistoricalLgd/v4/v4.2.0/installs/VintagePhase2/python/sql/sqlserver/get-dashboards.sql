SELECT [d].[DashboardId]
      ,[d].[CalculationId]
      ,[d].[DashboardTypeId]
      ,[d].[Context]
      ,[d].[Data]
  FROM [dbo].[Dashboards] AS [d]
  INNER JOIN [dbo].[DashboardTypes] AS [dt] WITH(NOLOCK) ON [d].[DashboardTypeId] = [dt].[DashboardTypeId]
  WHERE [dt].[DashboardType] IN ('ChainLadderLgdResult',
    'ChainLadderLgdExtract',
    'VintageLgdResult');