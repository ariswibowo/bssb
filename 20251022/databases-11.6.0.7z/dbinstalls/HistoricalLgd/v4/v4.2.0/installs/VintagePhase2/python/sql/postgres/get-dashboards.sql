SELECT "d"."DashboardId"
      ,"d"."CalculationId"
      ,"d"."DashboardTypeId"
      ,"d"."Context"
      ,"d"."Data"
  FROM "Dashboards" AS "d"
  INNER JOIN "DashboardTypes" AS "dt" ON "d"."DashboardTypeId" = "dt"."DashboardTypeId"
  WHERE "dt"."DashboardType" IN ('ChainLadderLgdResult',
    'ChainLadderLgdExtract',
    'VintageLgdResult');