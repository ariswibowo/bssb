PRINT N'';
PRINT N'Updating ResultConsolidatedVintageDefinitions...';
GO

UPDATE [dbo].[ResultConsolidatedVintageDefinitions]
   SET [Data] = '{data}'
 WHERE [Id] = '{id}';
GO