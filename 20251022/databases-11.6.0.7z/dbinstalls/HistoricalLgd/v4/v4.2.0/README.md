# README

**Release: HistoricalLgd V4.2.0**

## Release Features & Fixes

- [Feature: Vintage Phase 2](#feature-vintage-phase-2)

## Feature: Vintage Phase 2

- Alter resultConsolidated tables to migrate cost data from 4 fixed cost fields (DebtCollectionCost, DiscountedDebtCollectionCost, LitigationCost, and DiscountedLitigationCost) into JSON data column
- Migrate the existing ResultConsolidatedDefinitions to update method costs configuration data to consistent the dynamic cost
- Migrate the existing Dashboards to update costs data to consistent the dynamic cost

[top](#readme)