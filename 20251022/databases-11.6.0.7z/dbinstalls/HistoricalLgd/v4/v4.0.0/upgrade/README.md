# README

## Release: HistoricalLgd v4.0.0 (upgrade)

No new database features or fixes are required to upgrade from the latest v3.x.x to v4.0.0
