\echo '';
\echo 'Adding an Index to ResultContracts table on ContractId...';

DROP INDEX IF EXISTS "IX_ResultContracts_ContractId";
CREATE INDEX "IX_ResultContracts_ContractId" ON "ResultContracts" USING btree ("ContractId");
