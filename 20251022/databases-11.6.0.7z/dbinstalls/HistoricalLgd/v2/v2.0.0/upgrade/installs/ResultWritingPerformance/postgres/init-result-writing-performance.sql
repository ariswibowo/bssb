\echo '';
\echo 'Initializing ResultWritingPerformance install...';

DROP TABLE IF EXISTS "ResultHops";
DROP SEQUENCE IF EXISTS "ResultHops_Id_seq";

DROP TABLE IF EXISTS "SegmentCollectionIndex";
DROP SEQUENCE IF EXISTS "SegmentCollectionIndex_Id_seq";

DROP TABLE IF EXISTS "ResultSegmentCollections";
DROP SEQUENCE IF EXISTS "ResultSegmentCollections_Id_seq";
