PRINT N''
PRINT N'No action required for SQLServer. No updates made.';
GO
