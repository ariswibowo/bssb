PRINT N''
PRINT N'Backup ResultSegments table...';
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
           WHERE TABLE_NAME = N'ResultSegments' AND TABLE_SCHEMA = N'dbo')
BEGIN
  EXEC sp_rename '[dbo].[ResultSegments]', 'ResultSegments-INSTALL-v.2.0.0-EMP-1414';
END;
GO
