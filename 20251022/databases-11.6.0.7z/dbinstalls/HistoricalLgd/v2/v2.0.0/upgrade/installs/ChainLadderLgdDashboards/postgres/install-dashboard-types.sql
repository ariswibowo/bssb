\echo ''
\echo 'Cleaning up existing dashboard types...';

DELETE
  FROM "DashboardTypes"
 WHERE "DashboardType" IN (
     'Summary',
     'ChainLadderLgdResult',
     'ChainLadderLgdExtract'
 );

\echo ''
\echo 'Adding new dashboard types...';

\copy "DashboardTypes" FROM '{data}/ChainLadderLgdDashboards-DashboardTypes.dat' DELIMITER E'\t' CSV QUOTE '@' HEADER;