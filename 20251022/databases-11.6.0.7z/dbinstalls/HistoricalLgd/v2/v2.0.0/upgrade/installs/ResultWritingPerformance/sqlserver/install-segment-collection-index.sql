PRINT N'';
PRINT N'Installing SegmentCollectionIndex table...';
GO

CREATE TABLE [dbo].[SegmentCollectionIndex] (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [CollectionId] uniqueidentifier NOT NULL,
    [HashCode] nvarchar(256),
    [Data] nvarchar(max)
);
GO

ALTER TABLE [dbo].[SegmentCollectionIndex]
    ADD CONSTRAINT [PK_SegmentCollectionIndex] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_SegmentCollectionIndex_HashCode_CollectionId] ON [dbo].[SegmentCollectionIndex]([HashCode], [CollectionId]);
GO
