\echo '';
\echo 'Installing ResultSegmentCollections table...';

CREATE SEQUENCE "ResultSegmentCollections_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultSegmentCollections_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultSegmentCollections" (
    "Id" integer DEFAULT nextval('"ResultSegmentCollections_Id_seq"'::regclass) NOT NULL,
    "CollectionId" uuid NOT NULL,
    "ResultId" uuid NOT NULL
);

ALTER TABLE ONLY "ResultSegmentCollections"
    ADD CONSTRAINT "PK_ResultSegmentCollections" PRIMARY KEY ("Id");

ALTER TABLE "ResultSegmentCollections" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultSegmentCollections_ResultId" ON "ResultSegmentCollections" USING btree ("ResultId");
