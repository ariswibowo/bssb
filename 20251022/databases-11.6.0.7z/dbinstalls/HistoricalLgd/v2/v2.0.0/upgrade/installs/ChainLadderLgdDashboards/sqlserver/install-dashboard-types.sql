PRINT N''
PRINT N'Cleaning up existing dashboard types...'
GO

DELETE
  FROM [dbo].[DashboardTypes]
 WHERE [DashboardType] IN (
     'Summary',
     'ChainLadderLgdResult',
     'ChainLadderLgdExtract'
 );
GO

PRINT N''
PRINT N'Adding new dashboard types...'
GO

BULK INSERT [dbo].[DashboardTypes]
FROM '{data}/ChainLadderLgdDashboards-DashboardTypes.dat'
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = '\t',
    ROWTERMINATOR = '0x0a'
);
GO