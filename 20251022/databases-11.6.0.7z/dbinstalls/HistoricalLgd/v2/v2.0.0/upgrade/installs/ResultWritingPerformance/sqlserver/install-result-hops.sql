PRINT N'';
PRINT N'Installing ResultHops table...';
GO

CREATE TABLE [dbo].[ResultHops] (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [ResultId] uniqueidentifier NOT NULL,
    [Data] nvarchar(max) NOT NULL
);
GO

ALTER TABLE [dbo].[ResultHops]
    ADD CONSTRAINT [PK_ResultHops] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_ResultHops_ResultId] ON [dbo].[ResultHops]([ResultId]);
GO
