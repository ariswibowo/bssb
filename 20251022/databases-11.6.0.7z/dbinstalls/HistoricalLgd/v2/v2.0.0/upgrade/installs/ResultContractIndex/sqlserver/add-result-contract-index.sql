PRINT N''
PRINT N'Adding an Index to ResultContracts table on ContractId...';
GO

DROP INDEX IF EXISTS [IX_ResultContracts_ContractId] on [dbo].[ResultContracts];
GO

CREATE INDEX [IX_ResultContracts_ContractId] ON [dbo].[ResultContracts]([ContractId]);
GO
