\echo '';
\echo 'Backup ResultSegments table...';

ALTER TABLE IF EXISTS "ResultSegments" RENAME TO "ResultSegments-INSTALL-v.2.0.0-EMP-1414";
