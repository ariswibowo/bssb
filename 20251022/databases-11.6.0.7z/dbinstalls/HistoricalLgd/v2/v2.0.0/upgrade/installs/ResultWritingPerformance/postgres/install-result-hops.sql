\echo '';
\echo 'Installing ResultHops table...';

CREATE SEQUENCE "ResultHops_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "ResultHops_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "ResultHops" (
    "Id" integer DEFAULT nextval('"ResultHops_Id_seq"'::regclass) NOT NULL,
    "ResultId" uuid NOT NULL,
    "Data" text
);

ALTER TABLE ONLY "ResultHops"
    ADD CONSTRAINT "PK_ResultHops" PRIMARY KEY ("Id");

ALTER TABLE "ResultHops" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_ResultHops_ResultId" ON "ResultHops" USING btree ("ResultId");
