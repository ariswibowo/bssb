\echo '';
\echo 'Installing SegmentCollectionIndex table...';

CREATE SEQUENCE "SegmentCollectionIndex_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE "SegmentCollectionIndex_Id_seq" OWNER TO "Empyrean";

CREATE TABLE "SegmentCollectionIndex" (
    "Id" integer DEFAULT nextval('"SegmentCollectionIndex_Id_seq"'::regclass) NOT NULL,
    "CollectionId" uuid NOT NULL,
    "HashCode" varchar(256),
    "Data" text
);

ALTER TABLE ONLY "SegmentCollectionIndex"
    ADD CONSTRAINT "PK_SegmentCollectionIndex" PRIMARY KEY ("Id");

ALTER TABLE "SegmentCollectionIndex" OWNER TO "Empyrean";

CREATE UNIQUE INDEX "IX_SegmentCollectionIndex_HashCode_CollectionId" ON "SegmentCollectionIndex" USING btree ("HashCode", "CollectionId");
