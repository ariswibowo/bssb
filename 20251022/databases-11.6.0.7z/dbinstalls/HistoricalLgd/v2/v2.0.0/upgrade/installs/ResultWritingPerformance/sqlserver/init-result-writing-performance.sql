PRINT N'';
PRINT N'Initializing ResultWritingPerformance install...';
GO

DROP TABLE IF EXISTS [dbo].[ResultHops];
GO

DROP TABLE IF EXISTS [dbo].[SegmentCollectionIndex];
GO

DROP TABLE IF EXISTS [dbo].[ResultSegmentCollections];
GO
