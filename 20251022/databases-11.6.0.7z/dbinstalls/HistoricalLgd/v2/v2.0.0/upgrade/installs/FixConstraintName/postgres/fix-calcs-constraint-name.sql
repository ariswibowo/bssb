\echo '';
\echo 'Renaming Calculation PK Constraint...';

DO $$
BEGIN
    IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE constraint_name = '[PK_Calculations]') THEN
        ALTER TABLE ONLY "Calculations"
            RENAME CONSTRAINT "[PK_Calculations]" TO "PK_Calculations";
  	END IF;
END $$;
