PRINT N'';
PRINT N'Installing ResultSegmentCollections table...';
GO

CREATE TABLE [dbo].[ResultSegmentCollections] (
    [Id] integer IDENTITY(1, 1) NOT NULL,
    [CollectionId] uniqueidentifier NOT NULL,
    [ResultId] uniqueidentifier NOT NULL
);
GO

ALTER TABLE [dbo].[ResultSegmentCollections]
    ADD CONSTRAINT [PK_ResultSegmentCollections] PRIMARY KEY ([Id]);
GO

CREATE UNIQUE INDEX [IX_ResultSegmentCollections_ResultId] ON [dbo].[ResultSegmentCollections]([ResultId]);
GO
