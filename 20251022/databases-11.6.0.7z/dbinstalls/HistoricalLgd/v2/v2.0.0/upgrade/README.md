# README

**Release: HistoricalLgd v2.0.0 (upgrade)**

## Release Features & Fixes

- [Fix: Constraint Name ](#fix-constraint-name)
- [Feature: Result Writing Performance](#feature-result-writing-performance)
- [Feature: Result Contract Index](#feature-result-contract-index)
- [Feature: Chain Ladder LGD Dashboards](#feature-chain-ladder-lgd-dashboards)

## Fix: Constraint Name

Correct naming of primary key constraint (postgres only) on Calculations table from **[PK_Calculations]** to **PK_Calculations**

```
Note: this issue has also been fixed in the original v1.0.0 install scripts; so this is no longer an issue for newer V1 installs
```

[top](#readme)

## Feature: Result Writing Performance

This install applies a combination of techniques to enhance the overall performance of the result writing process:

- Update the ResultHops table to store a single row per result instead of 1 row per result and hop. The hops are to be stored as a JSON data structure in a data field of the ResultHops table. This update reduces the number of records that are stored for a single calculation and it allows for a unique constraint to be created in the ResultHops.ResultId field which in its turn allows for optimistic bulk insert instead of pessimistic bulk insert.
- Revise the Segments Result data model to make use of a SegmentCollectionIndex that stores a single record per unique segmentation result collection. One segment collection represents the collection of segments that were assigned for each of the segmentation ruleset versions that are required to be executed as part of the Historical LGD calculation. A segment collection can be referenced across individual results and calculations. The link between a result and a segment collection is to be stored in table ResultSegmentCollections. The current ResultSegments table is to be decommissioned.

**WARNING:** as part of the migration to the new ResultHops table structure this install removes all recorded ResultHops data.

References: #EMP-1414

[top](#readme)

## Feature: Result Contract Index

Add an index to ResultContracts table on ContractId

[top](#readme)

## Feature: Chain Ladder LGD Dashboards

Adds new Dashboard Types for Chain Ladder LGD Calculation method.

### New Dashboards

| Dashboard Type        | Description                                                                                                             |
| --------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| Summary               | Shows a table that has segment-level cross-calculation type information (number of contracts, outstanding amount, LGD). |
| ChainLadderLgdResult  | Shows the table with consolidated chain ladder results for one segment.                                                 |
| ChainLadderLgdExtract | Prepares a data extract with the full calculation results useful for download.                                          |

References: #EMP-1507

[top](#readme)
