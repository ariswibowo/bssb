import dbhelper
import logger
import json

def main(config):

    # generate build script file.
    build = dbhelper.init_build("handle-duplicate-segment-collection-index-hashcode", config)

    # get collectionIndex which contains duplicate hashcode.
    data = dbhelper.get_data("get-duplicate-segment-collection-index-hashcode", config)
    duplicateHashCodes = data.fetchall()

    if len(duplicateHashCodes) > 0:
        # pick one collectionId from duplicate hashcode collection index.
        pickedCollectionId = duplicateHashCodes.pop(0)[0]
        collectionIds = []
        for duplicateHashCode in duplicateHashCodes:
            collectionIds.append(duplicateHashCode[0])

        # write build sql to update data in ResultSegmentCollection and SegmentCollectionIndex.
        update_sql = dbhelper.get_sql("update-result-segment-collection", config)
        updateCollectionId = update_sql.format(collectionId=pickedCollectionId, collectionIds= (", ".join(repr(c) for c in collectionIds)))
        dbhelper.write_build(build, updateCollectionId)

        update_sql = dbhelper.get_sql("delete-duplicate-segment-collection-index-hashcode", config)
        deleteRecord = update_sql.format(collectionIds= (", ".join(repr(c) for c in collectionIds)))
        dbhelper.write_build(build, deleteRecord)

    dbhelper.run_build(build, config)
    dbhelper.dispose(data, config)
    return