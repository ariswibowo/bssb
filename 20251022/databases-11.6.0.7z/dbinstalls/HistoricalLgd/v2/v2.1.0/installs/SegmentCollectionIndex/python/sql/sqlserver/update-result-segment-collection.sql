PRINT N'';
PRINT N'Modifying ResultSegmentCollections collectionId...';

UPDATE [dbo].[ResultSegmentCollections]
SET [CollectionId] = '{collectionId}'
WHERE [CollectionId] IN ({collectionIds});
GO