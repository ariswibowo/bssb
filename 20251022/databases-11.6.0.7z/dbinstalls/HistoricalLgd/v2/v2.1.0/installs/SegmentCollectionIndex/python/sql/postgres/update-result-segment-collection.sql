\echo '';
\echo 'Modifying ResultSegmentCollections collectionId...';

UPDATE "ResultSegmentCollections"
SET "CollectionId" = '{collectionId}'
WHERE "CollectionId" IN ({collectionIds});