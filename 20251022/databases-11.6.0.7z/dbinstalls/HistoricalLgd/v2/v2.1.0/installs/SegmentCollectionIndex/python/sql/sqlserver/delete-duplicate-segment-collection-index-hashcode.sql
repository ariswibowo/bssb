PRINT N'';
PRINT N'Deleteing SegmentCollectionIndex record(s) contains duplicate hashcode...';

DELETE FROM [dbo].[SegmentCollectionIndex] 
WHERE [CollectionId]
IN ({collectionIds});
GO