SELECT "CollectionId", "HashCode"
FROM "SegmentCollectionIndex"
WHERE "HashCode" IN( 
    SELECT "HashCode" 
    FROM "SegmentCollectionIndex" 
    GROUP BY "HashCode"
    HAVING COUNT(*) > 1);