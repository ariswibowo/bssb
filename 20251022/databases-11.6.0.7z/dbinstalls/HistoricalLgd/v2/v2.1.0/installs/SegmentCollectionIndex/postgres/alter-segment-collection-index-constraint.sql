\echo '';
\echo 'Modifying SegmentCollectionIndex unique index constraint...';

DROP INDEX IF EXISTS "IX_SegmentCollectionIndex_HashCode_CollectionId";
CREATE UNIQUE INDEX IF NOT EXISTS "IX_SegmentCollectionIndex_CollectionId" ON "SegmentCollectionIndex" USING btree ("CollectionId");
CREATE UNIQUE INDEX IF NOT EXISTS "IX_SegmentCollectionIndex_HashCode" ON "SegmentCollectionIndex" USING btree ("HashCode");