\echo '';
\echo 'Deleteing SegmentCollectionIndex record(s) contains duplicate hashcode...';

DELETE FROM "SegmentCollectionIndex" 
WHERE "CollectionId"
IN ({collectionIds});