PRINT N'';
PRINT N'Modifying SegmentCollectionIndex unique index constraint...';

DROP INDEX IF EXISTS [IX_SegmentCollectionIndex_HashCode_CollectionId] ON [dbo].[SegmentCollectionIndex];
GO
IF NOT EXISTS(SELECT name FROM sys.indexes WHERE name= 'IX_SegmentCollectionIndex_CollectionId')
    CREATE UNIQUE INDEX [IX_SegmentCollectionIndex_CollectionId] ON [dbo].[SegmentCollectionIndex]([CollectionId]);
GO
IF NOT EXISTS(SELECT name FROM sys.indexes WHERE name= 'IX_SegmentCollectionIndex_HashCode')
    CREATE UNIQUE INDEX [IX_SegmentCollectionIndex_HashCode] ON [dbo].[SegmentCollectionIndex]([HashCode]);
GO