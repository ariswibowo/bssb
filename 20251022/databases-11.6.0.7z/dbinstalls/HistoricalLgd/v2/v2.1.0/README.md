# README

**Release: HistoricalLgd V2.1.0**

## Release Features & Fixes

- [Fix: SegmentCollection Index Constraint](#feature-segment-collection-index-constraint)

## Fix: SegmentCollection Index Constraint

Unique index name **IX_SegmentCollectionIndex_HashCode_CollectionId** was altered to unique index **IX_SegmentCollectionIndex_CollectionId** and unique index **IX_SegmentCollectionIndex_HashCode**.

[top](#readme)
