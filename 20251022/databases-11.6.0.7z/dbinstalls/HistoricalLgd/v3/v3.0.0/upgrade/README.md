# README

**Release: HistoricalLgd v3.0.0 (upgrade)**

No new database features or fixes are required to upgrade from the latest v2.x.x to v3.0.0
