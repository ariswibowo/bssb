#!/usr/bin/python

"""Database Upgrade Manager (DUM)

CLI to manage database versions and upgrade installations

"""

import scripts.cli.cli as cli

if __name__ == "__main__":
    # activate cli-controller
    cli.main()
