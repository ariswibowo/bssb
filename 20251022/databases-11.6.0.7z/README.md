# Database Upgrade Manager

Empyrean Database Upgrade Manager

## Version History
---

| Version     | Release Date | Commit  |
| ----------- | ------------ | ------- |
| 6-rev.8     | 16-Mar-2021  | 9e9ed70 |
| 6-rev.7     | 21-Jan-2021  | c9371ac |
| 6-rev.6     | 20-Jan-2021  | f342361 |
| 6-rev.5     | 11-Jan-2021  | 98b12ca |
| 6-rev.4     | 05-Jan-2021  | 64ac22c |
| 6-rev.3     | 23-Dec-2020  | 3c1c2b7 |
| 6-rev.2     | 17-Dec-2020  | 7ac5f4c |
| 6-rev.1     | 09-Dec-2020  | 70c6ff2 |
| 5-rev.10    | 30-Oct-2020  | 817873d |
| 5-rev.9     | 22-Oct-2020  | 737ca7a |
| 5-rev.8     | 16-Oct-2020  | fcfca45 |
| 5-rev.7     | 30-Sep-2020  | 7470bff |
| 5-rev.6     | 21-Sep-2020  | b32e80b |
| 5-rev.5     | 16-Sep-2020  | 7b14129 |
| 5-rev.4     | 10-Sep-2020  | 07b1bb1 |
| 5-rev.3     | 31-Aug-2020  | 3179c9c |
| 5-rev.2     | 14-Aug-2020  | bdbee9c |
| 5-rev.1     | 30-Jul-2020  | 6843669 |
| 4-rev.12    | 22-Jun-2020  | 375b648 |
| 4-rev.11    | 29-May-2020  | 3b116af |
| 4-rev.10    | 15-May-2020  | b416e3c |
| 4-rev.9     | 08-May-2020  | d790e1c |
| 4-rev.8     | 08-May-2020  | 1eeaab0 |
| 4-rev.7     | 08-May-2020  | 4f21fda |
| 4-rev.6     | 08-May-2020  | 82c9c60 |
| 4-rev.4     | 24-Mar-2020  | ffd3b51 |
| 4-rev.3     | 04-Mar-2020  | e9837bb |
| 4-rev.2     | 03-Mar-2020  | a3a9707 |
| 4-rev.1     | 20-Feb-2020  | fb2bde2 |
| 3.1.0-rev.2 | 04-Feb-2020  | 2e9201f |
| 3.1.0-rev.1 | 24-Jan-2020  | 6ff6590 |
| 3.0.1       | 14-Jan-2020  | fed18c1 |
| 3.0.0       | 01-Jan-2020  | 9175a30 |

---

- Database syntax/command must be capital letter.  
    
    **WRONG**  
    ![Environment variables](./assets/database-06.png)

    **CORRECT**  
    ![Environment variables](./assets/database-07.png)
    
- Object Encapsulating

    - SQLServer object must be encapsulated by square bracket ([]).
    
    **WRONG**     
    ![Environment variables](./assets/database-08.png)

    **CORRECT**    
    ![Environment variables](./assets/database-09.png)
    
    - Postgres object must be encapsulated by double quote ("").
    
    **WRONG**  
    ![Environment variables](./assets/database-10.png)

    **CORRECT**  
    ![Environment variables](./assets/database-11.png)

- Remove unnecessary empty line from the script.

- File name must be meaningful

---

# Database installation guide

---

This is an database installation guide for setup environment and services that you need in Empyrean.

## Prerequiste

---

###### You can skip this if you have already done.

- Download python installers latest version from https://www.python.org/ and install into your computer.
- Download docker desktop for windows latest version from https://www.docker.com/products/docker-desktop and install into your computer.
- Download postgres open source object-relational database latest version from https://www.postgresql.org/ and install into your computer.
- Download git-bash for window from https://git-scm.com/downloads and install into your computer.
- Configure path postgres path and python path to environment variables

  - Open My computer
  - Right click into area → properties -> Advanced system setting -> Environment Variables.

  ![Environment variables](./assets/readme-01.png)

- Add new postgres path to environment variable

```bash
C:\Program Files\PostgreSQL\11\bin
```

> 11 = postgres version

![Environment variables](./assets/readme-02.png)

- Login into your bitbucket on https://bitbucket.org, go on Database Installation and Deployment Installation

## Database installation

---

###### Currently we have postgres and docker installation for more details we will update this later.

- Clone databases repository from bitbucket by open the terminal and use the following command

```bash
git clone https://{{yourname}}@bitbucket.org/Empyrean-APAC/databases.git
```

- Install requirement packages, go to your databases folder by following command

```bash
cd databases
```

- Install packages from python

```bash
python -m pip install -r requirements.txt
```

- Now you have requirement packages type command `dbcheck.py` to create localDbConfig.json

```bash
dbcheck.py
```

- The result will show you an error because we don’t have localDbConfig at first.

### Postgres Configuration

###### This is an postgres setup configuration if you use an other you can skip this

- Setup your postgres user by pgAdmin

- Open pgAdmin App and login
- Create new Login User

  ![DatabaseInstallation](./assets/database-01.png)

- In General
  - Name = “Empyrean” or as your wish
- In Definition
  - Password = “admin” or as your wish
- In Privileges

  - Toggle can login.
  - Toggle Superuser.

    ![DatabaseInstallation](./assets/database-02.png)

- Now you have postgres user, go back to configure on localDbConfig.json set the “postgres” details up to your username

  ![DatabaseInstallation](./assets/database-03.png)

- Configure your `pg_hba.conf` file to allow any address to access your database in

```bash
C:\Program Files\PostgreSQL\11\data\pg_hba.conf
```

> 11 = postgres version

- Add your configure under #DATABASE

```bash
host all all 0.0.0.0.0/0 md5
```

![DatabaseInstallation](./assets/database-05.png)

### SQL Configuration

###### TODO

---

- After you have to configure the database file config, next step you have to install the database by the following command

```bash
dbinstall.py”
```

- Install your database licenses

- **You need license file from DevOps**
  > If you don’t have it. Please feel free to ask them.
- Create new folder name “dblicenses”
- Move your license file to your folder
- Install your license by following command

```bash
dblicense.py -f {{your license file name}}
```

![DatabaseInstallation](./assets/database-04.png)

- Get your demo data from database by command

```bash
dbrestore.py
```

---

Copyright (c) 2019 Empyrean Solutions Apac Co., Ltd.