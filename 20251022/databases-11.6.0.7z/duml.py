#!/usr/bin/python

"""Database Upgrade Manager (DUM)

CLI to manage database versions and upgrade installations

"""

# note:
# this script is a pure CLI controller that uses the click library to
# accpet and perform parameter validation.
#
# each cli command is routed to it's respective processor passing on
# explicitly named params 1:1.
#
# please if you are changing this script keep things "pure" to this
# cli-controller only model, let the command target handle any
# deeper reasoning that needs to be done.


import sys
import click

import scripts.dbdrop.dbdrop as dbdrop
import scripts.dbfix.dbfix as dbfix
import scripts.dbinspect.dbinspect as dbinspect
import scripts.dbinstalls.dbinstalls as dbinstalls
import scripts.dblicenses.dblicenses as dblicenses
import scripts.dbsupervisors.dbsupervisors as dbsupervisors
import scripts.dbdatadicts.dbdatadicts as dbdatadicts


@click.group()
def dum():
    """Databaase Upgrade Manager (DUM)

    DUM can be used to inspect current install versions, install
    upgrades, product licenses, and manage supervisors.

    DUM is not dumb.
    """
    pass


@dum.command()
@click.option("--file", "-f", type=str, multiple=True, help="Name of license file to install.")
@click.option("--target", "-t", type=click.Choice(["postgres", "sqlserver"]), help="Target databases type.")
@click.option("--loglevel", "-l", type=click.Choice(["debug", "warning", "info", "error", "critical"]), help="Log verbosity level.")
def license(file, target, loglevel):
    """Manage database licenses.

    Displays installed licesnse and/or displays installed license information
    """
    dblicenses.license(file=file, target=target, loglevel=loglevel)


@dum.group()
def supervisors():
    """Manages supervisor packs"""
    pass


@supervisors.command()
@click.option("--target", "-t", type=click.Choice(["postgres", "sqlserver"]), help="Target databases type.")
def inspect(target):
    """Displays the currently installed supervisors"""
    dbsupervisors.inspect(target=target)


@supervisors.command()
@click.argument("supervisor", type=str)
@click.option("--target", "-t", type=click.Choice(["postgres", "sqlserver"]), help="Target databases type.")
def install(supervisor, target):
    """Installs a supervisor"""
    dbsupervisors.install(supervisor=supervisor, target=target)


@supervisors.command()
@click.argument("supervisor", type=str)
@click.option("--target", "-t", type=click.Choice(["postgres", "sqlserver"]), help="Target databases type.")
def remove(supervisor, target):
    """Removes an installed supervisor"""
    dbsupervisors.remove(supervisor=supervisor, target=target)
