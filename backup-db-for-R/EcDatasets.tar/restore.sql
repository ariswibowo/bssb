--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Fdr";
--
-- Name: Fdr; Type: DATABASE; Schema: -; Owner: Elysian
--

CREATE DATABASE "Fdr" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "Fdr" OWNER TO "Elysian";

\unrestrict (null)
\connect "Fdr"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: EcDatasets; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."EcDatasets" (
    "DatasetId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "FdrTypeId" uuid NOT NULL,
    "EffectiveDate" timestamp without time zone NOT NULL,
    "Status" character varying(50) NOT NULL,
    "Data" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."EcDatasets" OWNER TO "Elysian";

--
-- Data for Name: EcDatasets; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."EcDatasets" ("DatasetId", "Name", "Description", "FdrTypeId", "EffectiveDate", "Status", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."EcDatasets" ("DatasetId", "Name", "Description", "FdrTypeId", "EffectiveDate", "Status", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4954.dat';

--
-- Name: EcDatasets PK_EcDatasets; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."EcDatasets"
    ADD CONSTRAINT "PK_EcDatasets" PRIMARY KEY ("DatasetId");


--
-- PostgreSQL database dump complete
--

