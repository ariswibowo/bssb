--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Fdr";
--
-- Name: Fdr; Type: DATABASE; Schema: -; Owner: Elysian
--

CREATE DATABASE "Fdr" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "Fdr" OWNER TO "Elysian";

\unrestrict (null)
\connect "Fdr"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: EcValues; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."EcValues" (
    "ValueId" uuid NOT NULL,
    "DatasetId" uuid NOT NULL,
    "FactorId" uuid NOT NULL,
    "VariantId" uuid NOT NULL,
    "TransformationId" uuid,
    "ObservationDate" timestamp without time zone NOT NULL,
    "Value" numeric(27,9) NOT NULL
);


ALTER TABLE public."EcValues" OWNER TO "Elysian";

--
-- Data for Name: EcValues; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."EcValues" ("ValueId", "DatasetId", "FactorId", "VariantId", "TransformationId", "ObservationDate", "Value") FROM stdin;
\.
COPY public."EcValues" ("ValueId", "DatasetId", "FactorId", "VariantId", "TransformationId", "ObservationDate", "Value") FROM '$$PATH$$/4955.dat';

--
-- Name: EcValues PK_EcValues; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."EcValues"
    ADD CONSTRAINT "PK_EcValues" PRIMARY KEY ("ValueId");


--
-- Name: EcValues FK_EcValues_EcDatasets_DatasetId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."EcValues"
    ADD CONSTRAINT "FK_EcValues_EcDatasets_DatasetId" FOREIGN KEY ("DatasetId") REFERENCES public."EcDatasets"("DatasetId") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

