--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "HistoricalPd";
--
-- Name: HistoricalPd; Type: DATABASE; Schema: -; Owner: Elysian
--

CREATE DATABASE "HistoricalPd" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "HistoricalPd" OWNER TO "Elysian";

\unrestrict (null)
\connect "HistoricalPd"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ResultTransitionMatrices_23025cf3; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."ResultTransitionMatrices_23025cf3" (
    "Id" bigint DEFAULT nextval('public."ResultTransitionMatrices_23025cf3_Id_seq"'::regclass) NOT NULL,
    "PointId" uuid NOT NULL,
    "HashCode" character varying(256),
    "CalculationId" uuid NOT NULL,
    "SegmentId" uuid NOT NULL,
    "SegmentName" character varying(100) NOT NULL,
    "FromObservationDate" timestamp without time zone NOT NULL,
    "ToObservationDate" timestamp without time zone NOT NULL,
    "FromBucketId" uuid NOT NULL,
    "ToBucketId" uuid NOT NULL,
    "FromBucketName" character varying(100) NOT NULL,
    "ToBucketName" character varying(100) NOT NULL,
    "FromBucketType" character varying(50) NOT NULL,
    "ToBucketType" character varying(50) NOT NULL,
    "FromBucketSequence" integer NOT NULL,
    "ToBucketSequence" integer NOT NULL,
    "NumContracts" integer NOT NULL,
    "NumCounterparties" integer NOT NULL,
    "FromOutstandingAmount" numeric(20,2) NOT NULL,
    "ToOutstandingAmount" numeric(20,2) NOT NULL,
    "RetentionCopied" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."ResultTransitionMatrices_23025cf3" OWNER TO "Elysian";

--
-- Data for Name: ResultTransitionMatrices_23025cf3; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."ResultTransitionMatrices_23025cf3" ("Id", "PointId", "HashCode", "CalculationId", "SegmentId", "SegmentName", "FromObservationDate", "ToObservationDate", "FromBucketId", "ToBucketId", "FromBucketName", "ToBucketName", "FromBucketType", "ToBucketType", "FromBucketSequence", "ToBucketSequence", "NumContracts", "NumCounterparties", "FromOutstandingAmount", "ToOutstandingAmount", "RetentionCopied") FROM stdin;
\.
COPY public."ResultTransitionMatrices_23025cf3" ("Id", "PointId", "HashCode", "CalculationId", "SegmentId", "SegmentName", "FromObservationDate", "ToObservationDate", "FromBucketId", "ToBucketId", "FromBucketName", "ToBucketName", "FromBucketType", "ToBucketType", "FromBucketSequence", "ToBucketSequence", "NumContracts", "NumCounterparties", "FromOutstandingAmount", "ToOutstandingAmount", "RetentionCopied") FROM '$$PATH$$/5285.dat';

--
-- Name: ResultTransitionMatrices_23025cf3 PK_ResultTransitionMatrices_23025cf3; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ResultTransitionMatrices_23025cf3"
    ADD CONSTRAINT "PK_ResultTransitionMatrices_23025cf3" PRIMARY KEY ("Id");


--
-- Name: IX_ResultTransitionMatrices_23025cf3_CalculationId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_ResultTransitionMatrices_23025cf3_CalculationId" ON public."ResultTransitionMatrices_23025cf3" USING btree ("CalculationId");


--
-- Name: IX_ResultTransitionMatrices_23025cf3_HashCode; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_ResultTransitionMatrices_23025cf3_HashCode" ON public."ResultTransitionMatrices_23025cf3" USING btree ("HashCode");


--
-- Name: IX_ResultTransitionMatrices_23025cf3_PointId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_ResultTransitionMatrices_23025cf3_PointId" ON public."ResultTransitionMatrices_23025cf3" USING btree ("PointId");


--
-- PostgreSQL database dump complete
--

