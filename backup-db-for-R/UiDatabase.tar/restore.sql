--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Ui";
--
-- Name: Ui; Type: DATABASE; Schema: -; Owner: Elysian
--

CREATE DATABASE "Ui" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "Ui" OWNER TO "Elysian";

\unrestrict (null)
\connect "Ui"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ApplicationLogs_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."ApplicationLogs_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ApplicationLogs_Id_seq" OWNER TO "Elysian";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ApplicationLogs; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."ApplicationLogs" (
    "Id" bigint DEFAULT nextval('public."ApplicationLogs_Id_seq"'::regclass) NOT NULL,
    "LogId" uuid NOT NULL,
    "Origin" character varying(50) NOT NULL,
    "Logs" text NOT NULL,
    "StartTimestamp" timestamp without time zone NOT NULL,
    "EndTimestamp" timestamp without time zone
);


ALTER TABLE public."ApplicationLogs" OWNER TO "Elysian";

--
-- Name: Approvals; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Approvals" (
    "ApprovalId" uuid NOT NULL,
    "Request" text NOT NULL,
    "Response" text,
    "ApprovalStatus" character varying(50) NOT NULL
);


ALTER TABLE public."Approvals" OWNER TO "Elysian";

--
-- Name: DbVersions; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DbVersions" (
    "DbVersionId" uuid NOT NULL,
    "DbVersion" character varying(50) NOT NULL,
    "IsInstalledVersion" boolean NOT NULL,
    "ReleaseName" character varying(100) NOT NULL,
    "ReleaseDescription" character varying(300) NOT NULL,
    "InstallAttempt" integer NOT NULL,
    "InstallStatus" character varying(50) NOT NULL,
    "InstallStarted" timestamp without time zone NOT NULL,
    "InstallEnded" timestamp without time zone NOT NULL,
    "InstallComments" character varying(300) NOT NULL,
    "InstalledBy" character varying(100) NOT NULL
);


ALTER TABLE public."DbVersions" OWNER TO "Elysian";

--
-- Name: DeckActionLogs_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."DeckActionLogs_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeckActionLogs_Id_seq" OWNER TO "Elysian";

--
-- Name: DeckActionLogs; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckActionLogs" (
    "Id" bigint DEFAULT nextval('public."DeckActionLogs_Id_seq"'::regclass) NOT NULL,
    "LogId" uuid NOT NULL,
    "ExecutionId" uuid NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL,
    "Message" text NOT NULL,
    "Level" character varying(50) NOT NULL,
    "Source" character varying(50) NOT NULL,
    "Data" text
);


ALTER TABLE public."DeckActionLogs" OWNER TO "Elysian";

--
-- Name: DeckActions_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."DeckActions_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeckActions_Id_seq" OWNER TO "Elysian";

--
-- Name: DeckActions; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckActions" (
    "Id" bigint DEFAULT nextval('public."DeckActions_Id_seq"'::regclass) NOT NULL,
    "ExecutionId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "ActionId" uuid NOT NULL,
    "Description" character varying(300),
    "Status" character varying(100) NOT NULL,
    "ActionType" character varying(50) NOT NULL,
    "Data" text NOT NULL,
    "Result" text,
    "StartTimestamp" timestamp without time zone,
    "EndTimestamp" timestamp without time zone,
    "Priority" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckActions" OWNER TO "Elysian";

--
-- Name: DeckActivities; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckActivities" (
    "ActivityId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "SourceId" uuid NOT NULL,
    "Source" character varying(50) NOT NULL,
    "Action" character varying(50) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Trace" text,
    "Timestamp" timestamp without time zone NOT NULL,
    "ImpersonatedUserId" uuid
);


ALTER TABLE public."DeckActivities" OWNER TO "Elysian";

--
-- Name: DeckCalculationProps; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckCalculationProps" (
    "DeckCalculationPropId" uuid NOT NULL,
    "CalculationId" uuid NOT NULL,
    "Key" character varying(100) NOT NULL,
    "Value" text NOT NULL
);


ALTER TABLE public."DeckCalculationProps" OWNER TO "Elysian";

--
-- Name: DeckCalculations; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckCalculations" (
    "CalculationId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "Status" character varying(50) NOT NULL,
    "Data" text,
    "Sequence" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckCalculations" OWNER TO "Elysian";

--
-- Name: DeckClassificationVariances; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckClassificationVariances" (
    "VarianceId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "RefDeckId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckClassificationVariances" OWNER TO "Elysian";

--
-- Name: DeckFilterTemplates; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckFilterTemplates" (
    "TemplateId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "ObjectiveTypeId" uuid NOT NULL,
    "FilterOn" character varying(100) NOT NULL,
    "FilterType" character varying(100) NOT NULL,
    "Configuration" text NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "ConcurrencyId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckFilterTemplates" OWNER TO "Elysian";

--
-- Name: DeckImpairmentDisclosureChecks; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentDisclosureChecks" (
    "CheckId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Code" character varying(50) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Recommended" boolean,
    "Url" text
);


ALTER TABLE public."DeckImpairmentDisclosureChecks" OWNER TO "Elysian";

--
-- Name: DeckImpairmentDisclosureDeltas; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentDisclosureDeltas" (
    "ResultId" uuid NOT NULL,
    "DisclosureId" uuid,
    "CheckId" uuid,
    "Code" character varying(50) NOT NULL,
    "Status" character varying(50) NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckImpairmentDisclosureDeltas" OWNER TO "Elysian";

--
-- Name: DeckImpairmentDisclosureEcls; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentDisclosureEcls" (
    "DisclosureEclId" uuid NOT NULL,
    "DisclosureId" uuid NOT NULL,
    "EclId" uuid NOT NULL,
    "RefEclId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL,
    "IsAutomatch" boolean NOT NULL,
    "AnalysisId" uuid NOT NULL,
    "Status" text
);


ALTER TABLE public."DeckImpairmentDisclosureEcls" OWNER TO "Elysian";

--
-- Name: DeckImpairmentDisclosures; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentDisclosures" (
    "DisclosureId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "RefDeckId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckImpairmentDisclosures" OWNER TO "Elysian";

--
-- Name: DeckImpairmentEclCalculations; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentEclCalculations" (
    "EclCalculationId" uuid NOT NULL,
    "EclId" uuid NOT NULL,
    "RequestId" uuid NOT NULL,
    "CalculationId" uuid,
    "Status" character varying(50) NOT NULL,
    "Data" text,
    "Sequence" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckImpairmentEclCalculations" OWNER TO "Elysian";

--
-- Name: DeckImpairmentEcls; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentEcls" (
    "EclId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "IsCombinedEcl" boolean NOT NULL,
    "Weight" integer NOT NULL,
    "Data" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckImpairmentEcls" OWNER TO "Elysian";

--
-- Name: DeckImpairmentVarianceEcls; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentVarianceEcls" (
    "VarianceEclId" uuid NOT NULL,
    "VarianceId" uuid NOT NULL,
    "EclId" uuid NOT NULL,
    "RefEclId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL,
    "IsAutomatch" boolean NOT NULL,
    "AnalysisId" uuid NOT NULL,
    "Status" text
);


ALTER TABLE public."DeckImpairmentVarianceEcls" OWNER TO "Elysian";

--
-- Name: DeckImpairmentVariances; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckImpairmentVariances" (
    "VarianceId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "RefDeckId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckImpairmentVariances" OWNER TO "Elysian";

--
-- Name: DeckJobs; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckJobs" (
    "JobId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "Status" character varying(50) NOT NULL,
    "Data" text,
    "Sequence" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckJobs" OWNER TO "Elysian";

--
-- Name: DeckObjectiveTypes; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckObjectiveTypes" (
    "ObjectiveTypeId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Code" character varying(50) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckObjectiveTypes" OWNER TO "Elysian";

--
-- Name: DeckOverlayEntries_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."DeckOverlayEntries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeckOverlayEntries_Id_seq" OWNER TO "Elysian";

--
-- Name: DeckOverlayEntries; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckOverlayEntries" (
    "Id" bigint DEFAULT nextval('public."DeckOverlayEntries_Id_seq"'::regclass) NOT NULL,
    "EntryId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "OverlayId" uuid NOT NULL,
    "Data" text,
    "Sequence" integer NOT NULL
);


ALTER TABLE public."DeckOverlayEntries" OWNER TO "Elysian";

--
-- Name: DeckOverlayProps; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckOverlayProps" (
    "DeckOverlayPropId" uuid NOT NULL,
    "OverlayId" uuid NOT NULL,
    "Key" character varying(100) NOT NULL,
    "Value" text NOT NULL
);


ALTER TABLE public."DeckOverlayProps" OWNER TO "Elysian";

--
-- Name: DeckOverlays; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckOverlays" (
    "OverlayId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "OverlayRef" character varying(50) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "Priority" integer NOT NULL,
    "OverlayOn" character varying(50) NOT NULL,
    "EntryType" character varying(50) NOT NULL,
    "BalanceType" text NOT NULL,
    "Data" text NOT NULL,
    "ConcurrencyId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckOverlays" OWNER TO "Elysian";

--
-- Name: DeckProps; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckProps" (
    "DeckPropId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "Key" character varying(100) NOT NULL,
    "Value" text NOT NULL
);


ALTER TABLE public."DeckProps" OWNER TO "Elysian";

--
-- Name: DeckPulses; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckPulses" (
    "PulseId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "AccessLevel" character varying(50) NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckPulses" OWNER TO "Elysian";

--
-- Name: DeckReportLogs_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."DeckReportLogs_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeckReportLogs_Id_seq" OWNER TO "Elysian";

--
-- Name: DeckReportLogs; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckReportLogs" (
    "Id" bigint DEFAULT nextval('public."DeckReportLogs_Id_seq"'::regclass) NOT NULL,
    "LogId" uuid NOT NULL,
    "ExecutionId" uuid NOT NULL,
    "Timestamp" timestamp without time zone NOT NULL,
    "Message" text NOT NULL,
    "Level" character varying(50) NOT NULL,
    "Source" character varying(50) NOT NULL,
    "Data" text
);


ALTER TABLE public."DeckReportLogs" OWNER TO "Elysian";

--
-- Name: DeckReports_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."DeckReports_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeckReports_Id_seq" OWNER TO "Elysian";

--
-- Name: DeckReports; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckReports" (
    "Id" bigint DEFAULT nextval('public."DeckReports_Id_seq"'::regclass) NOT NULL,
    "ExecutionId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "ReportRegistryId" uuid NOT NULL,
    "Description" character varying(300),
    "Status" character varying(100) NOT NULL,
    "ReportType" character varying(50) NOT NULL,
    "Data" text NOT NULL,
    "Result" text,
    "StartTimestamp" timestamp without time zone,
    "EndTimestamp" timestamp without time zone,
    "Sequence" integer,
    "Priority" integer NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckReports" OWNER TO "Elysian";

--
-- Name: DeckReportsRegistry; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckReportsRegistry" (
    "ReportRegistryId" uuid NOT NULL,
    "ObjectiveTypeId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "ReportType" character varying(50) NOT NULL,
    "ParentId" uuid,
    "Status" character varying(50) NOT NULL,
    "Data" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckReportsRegistry" OWNER TO "Elysian";

--
-- Name: DeckStressEntries_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."DeckStressEntries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeckStressEntries_Id_seq" OWNER TO "Elysian";

--
-- Name: DeckStressEntries; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckStressEntries" (
    "Id" bigint DEFAULT nextval('public."DeckStressEntries_Id_seq"'::regclass) NOT NULL,
    "EntryId" uuid NOT NULL,
    "DeckId" uuid NOT NULL,
    "StressId" uuid NOT NULL,
    "Data" text,
    "Sequence" integer NOT NULL
);


ALTER TABLE public."DeckStressEntries" OWNER TO "Elysian";

--
-- Name: DeckTypes; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DeckTypes" (
    "DeckTypeId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "Style" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."DeckTypes" OWNER TO "Elysian";

--
-- Name: Decks; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Decks" (
    "DeckId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "DeckTypeId" uuid NOT NULL,
    "ObjectiveTypeId" uuid NOT NULL,
    "ParentDeckId" uuid,
    "Data" text,
    "ReportingDate" timestamp without time zone NOT NULL,
    "ExpiryDate" timestamp without time zone,
    "EntityId" uuid,
    "Currency" character(3),
    "IsPrivate" boolean NOT NULL,
    "Status" character varying(50) NOT NULL,
    "ConcurrencyId" uuid NOT NULL,
    "PublishedBy" uuid,
    "PublishedWhen" timestamp without time zone,
    "PublishComments" character varying(300),
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Decks" OWNER TO "Elysian";

--
-- Name: Policies; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Policies" (
    "PolicyId" uuid NOT NULL,
    "ObjectiveTypeId" uuid,
    "PolicyType" character varying(50) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "DefaultPolicy" text,
    "ActivePolicy" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Policies" OWNER TO "Elysian";

--
-- Name: PortfolioContent; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."PortfolioContent" (
    "ContentId" uuid NOT NULL,
    "Code" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "Route" character varying(300) NOT NULL,
    "DataAccess" text,
    "Content" text NOT NULL,
    "ConcurrencyId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."PortfolioContent" OWNER TO "Elysian";

--
-- Name: PublishRequests; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."PublishRequests" (
    "PublishRequestId" uuid NOT NULL,
    "SeqId" integer NOT NULL,
    "DeckId" uuid NOT NULL,
    "ExpiryDate" timestamp without time zone,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "ApprovalId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "Status" character varying(50) NOT NULL,
    "ApprovedWhen" timestamp without time zone,
    "RejectedWhen" timestamp without time zone,
    "Data" text
);


ALTER TABLE public."PublishRequests" OWNER TO "Elysian";

--
-- Name: ReportLibrary; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."ReportLibrary" (
    "ReportLibraryId" uuid NOT NULL,
    "ReportLibrary" character varying(50) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "DefaultReports" text NOT NULL,
    "ActiveReports" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."ReportLibrary" OWNER TO "Elysian";

--
-- Name: ScriptLogs; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."ScriptLogs" (
    "ScriptLogId" uuid NOT NULL,
    "ScriptId" uuid,
    "OriginId" uuid,
    "Origin" character varying(50) DEFAULT NULL::character varying,
    "Status" character varying(50) NOT NULL,
    "Logs" text,
    "StartTimestamp" timestamp without time zone NOT NULL,
    "EndTimestamp" timestamp without time zone
);


ALTER TABLE public."ScriptLogs" OWNER TO "Elysian";

--
-- Name: Scripts; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Scripts" (
    "ScriptId" uuid NOT NULL,
    "Script" text,
    "Origin" character varying(50),
    "OriginId" uuid,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Scripts" OWNER TO "Elysian";

--
-- Name: SessionEntries_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."SessionEntries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SessionEntries_Id_seq" OWNER TO "Elysian";

--
-- Name: SessionEntries; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."SessionEntries" (
    "Id" bigint DEFAULT nextval('public."SessionEntries_Id_seq"'::regclass) NOT NULL,
    "EntryId" uuid NOT NULL,
    "SessionId" uuid NOT NULL,
    "Data" text,
    "Timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public."SessionEntries" OWNER TO "Elysian";

--
-- Name: Sessions; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Sessions" (
    "SessionId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Status" character varying(50) NOT NULL,
    "UserId" uuid NOT NULL,
    "ContextId" uuid,
    "ContextType" character varying(50) NOT NULL,
    "Context" text,
    "CreatedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Sessions" OWNER TO "Elysian";

--
-- Name: UiCodes; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."UiCodes" (
    "CodeId" uuid NOT NULL,
    "Category" character varying(50),
    "Type" character varying(50) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Code" character varying(50) NOT NULL,
    "Data" text,
    "IsEnabled" boolean,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."UiCodes" OWNER TO "Elysian";

--
-- Name: UiValidationConfigurations; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."UiValidationConfigurations" (
    "ConfigId" uuid NOT NULL,
    "RuleId" uuid NOT NULL,
    "Enable" character varying(50),
    "Options" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."UiValidationConfigurations" OWNER TO "Elysian";

--
-- Name: UiValidationRules; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."UiValidationRules" (
    "RuleId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Category" character varying(50) NOT NULL,
    "Code" character varying(50) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Recommended" character varying(50) NOT NULL,
    "Url" character varying(300),
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."UiValidationRules" OWNER TO "Elysian";

--
-- Name: UserReportLibrary; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."UserReportLibrary" (
    "UserReportLibraryId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "ReportLibrary" character varying(50) NOT NULL,
    "Reports" text NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."UserReportLibrary" OWNER TO "Elysian";

--
-- Name: WorkspaceTemplates; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."WorkspaceTemplates" (
    "WorkspaceTemplateId" uuid NOT NULL,
    "ScriptId" uuid,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Type" character varying(50) NOT NULL,
    "Data" text,
    "IsEnabled" boolean NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."WorkspaceTemplates" OWNER TO "Elysian";

--
-- Name: Workspaces; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Workspaces" (
    "WorkspaceId" uuid NOT NULL,
    "ParentId" uuid,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "Type" character varying(50) NOT NULL,
    "Data" text,
    "Status" character varying(50) NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Workspaces" OWNER TO "Elysian";

--
-- Data for Name: ApplicationLogs; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."ApplicationLogs" ("Id", "LogId", "Origin", "Logs", "StartTimestamp", "EndTimestamp") FROM stdin;
\.
COPY public."ApplicationLogs" ("Id", "LogId", "Origin", "Logs", "StartTimestamp", "EndTimestamp") FROM '$$PATH$$/4752.dat';

--
-- Data for Name: Approvals; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Approvals" ("ApprovalId", "Request", "Response", "ApprovalStatus") FROM stdin;
\.
COPY public."Approvals" ("ApprovalId", "Request", "Response", "ApprovalStatus") FROM '$$PATH$$/4753.dat';

--
-- Data for Name: DbVersions; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DbVersions" ("DbVersionId", "DbVersion", "IsInstalledVersion", "ReleaseName", "ReleaseDescription", "InstallAttempt", "InstallStatus", "InstallStarted", "InstallEnded", "InstallComments", "InstalledBy") FROM stdin;
\.
COPY public."DbVersions" ("DbVersionId", "DbVersion", "IsInstalledVersion", "ReleaseName", "ReleaseDescription", "InstallAttempt", "InstallStatus", "InstallStarted", "InstallEnded", "InstallComments", "InstalledBy") FROM '$$PATH$$/4750.dat';

--
-- Data for Name: DeckActionLogs; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckActionLogs" ("Id", "LogId", "ExecutionId", "Timestamp", "Message", "Level", "Source", "Data") FROM stdin;
\.
COPY public."DeckActionLogs" ("Id", "LogId", "ExecutionId", "Timestamp", "Message", "Level", "Source", "Data") FROM '$$PATH$$/4778.dat';

--
-- Data for Name: DeckActions; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckActions" ("Id", "ExecutionId", "DeckId", "ActionId", "Description", "Status", "ActionType", "Data", "Result", "StartTimestamp", "EndTimestamp", "Priority", "CreatedBy", "CreatedWhen") FROM stdin;
\.
COPY public."DeckActions" ("Id", "ExecutionId", "DeckId", "ActionId", "Description", "Status", "ActionType", "Data", "Result", "StartTimestamp", "EndTimestamp", "Priority", "CreatedBy", "CreatedWhen") FROM '$$PATH$$/4776.dat';

--
-- Data for Name: DeckActivities; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckActivities" ("ActivityId", "UserId", "SourceId", "Source", "Action", "Description", "Trace", "Timestamp", "ImpersonatedUserId") FROM stdin;
\.
COPY public."DeckActivities" ("ActivityId", "UserId", "SourceId", "Source", "Action", "Description", "Trace", "Timestamp", "ImpersonatedUserId") FROM '$$PATH$$/4768.dat';

--
-- Data for Name: DeckCalculationProps; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckCalculationProps" ("DeckCalculationPropId", "CalculationId", "Key", "Value") FROM stdin;
\.
COPY public."DeckCalculationProps" ("DeckCalculationPropId", "CalculationId", "Key", "Value") FROM '$$PATH$$/4773.dat';

--
-- Data for Name: DeckCalculations; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckCalculations" ("CalculationId", "DeckId", "Status", "Data", "Sequence", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckCalculations" ("CalculationId", "DeckId", "Status", "Data", "Sequence", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4772.dat';

--
-- Data for Name: DeckClassificationVariances; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckClassificationVariances" ("VarianceId", "DeckId", "RefDeckId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckClassificationVariances" ("VarianceId", "DeckId", "RefDeckId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4784.dat';

--
-- Data for Name: DeckFilterTemplates; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckFilterTemplates" ("TemplateId", "Name", "Description", "ObjectiveTypeId", "FilterOn", "FilterType", "Configuration", "IsEnabled", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckFilterTemplates" ("TemplateId", "Name", "Description", "ObjectiveTypeId", "FilterOn", "FilterType", "Configuration", "IsEnabled", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4774.dat';

--
-- Data for Name: DeckImpairmentDisclosureChecks; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentDisclosureChecks" ("CheckId", "Name", "Code", "Description", "Recommended", "Url") FROM stdin;
\.
COPY public."DeckImpairmentDisclosureChecks" ("CheckId", "Name", "Code", "Description", "Recommended", "Url") FROM '$$PATH$$/4789.dat';

--
-- Data for Name: DeckImpairmentDisclosureDeltas; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentDisclosureDeltas" ("ResultId", "DisclosureId", "CheckId", "Code", "Status", "CreatedWhen") FROM stdin;
\.
COPY public."DeckImpairmentDisclosureDeltas" ("ResultId", "DisclosureId", "CheckId", "Code", "Status", "CreatedWhen") FROM '$$PATH$$/4791.dat';

--
-- Data for Name: DeckImpairmentDisclosureEcls; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentDisclosureEcls" ("DisclosureEclId", "DisclosureId", "EclId", "RefEclId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen", "IsAutomatch", "AnalysisId", "Status") FROM stdin;
\.
COPY public."DeckImpairmentDisclosureEcls" ("DisclosureEclId", "DisclosureId", "EclId", "RefEclId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen", "IsAutomatch", "AnalysisId", "Status") FROM '$$PATH$$/4792.dat';

--
-- Data for Name: DeckImpairmentDisclosures; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentDisclosures" ("DisclosureId", "DeckId", "RefDeckId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckImpairmentDisclosures" ("DisclosureId", "DeckId", "RefDeckId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4790.dat';

--
-- Data for Name: DeckImpairmentEclCalculations; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentEclCalculations" ("EclCalculationId", "EclId", "RequestId", "CalculationId", "Status", "Data", "Sequence", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckImpairmentEclCalculations" ("EclCalculationId", "EclId", "RequestId", "CalculationId", "Status", "Data", "Sequence", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4786.dat';

--
-- Data for Name: DeckImpairmentEcls; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentEcls" ("EclId", "DeckId", "Name", "Description", "IsCombinedEcl", "Weight", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckImpairmentEcls" ("EclId", "DeckId", "Name", "Description", "IsCombinedEcl", "Weight", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4785.dat';

--
-- Data for Name: DeckImpairmentVarianceEcls; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentVarianceEcls" ("VarianceEclId", "VarianceId", "EclId", "RefEclId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen", "IsAutomatch", "AnalysisId", "Status") FROM stdin;
\.
COPY public."DeckImpairmentVarianceEcls" ("VarianceEclId", "VarianceId", "EclId", "RefEclId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen", "IsAutomatch", "AnalysisId", "Status") FROM '$$PATH$$/4788.dat';

--
-- Data for Name: DeckImpairmentVariances; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckImpairmentVariances" ("VarianceId", "DeckId", "RefDeckId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckImpairmentVariances" ("VarianceId", "DeckId", "RefDeckId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4787.dat';

--
-- Data for Name: DeckJobs; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckJobs" ("JobId", "DeckId", "Status", "Data", "Sequence", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckJobs" ("JobId", "DeckId", "Status", "Data", "Sequence", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4770.dat';

--
-- Data for Name: DeckObjectiveTypes; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckObjectiveTypes" ("ObjectiveTypeId", "Name", "Description", "Code", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckObjectiveTypes" ("ObjectiveTypeId", "Name", "Description", "Code", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4764.dat';

--
-- Data for Name: DeckOverlayEntries; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckOverlayEntries" ("Id", "EntryId", "DeckId", "OverlayId", "Data", "Sequence") FROM stdin;
\.
COPY public."DeckOverlayEntries" ("Id", "EntryId", "DeckId", "OverlayId", "Data", "Sequence") FROM '$$PATH$$/4796.dat';

--
-- Data for Name: DeckOverlayProps; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckOverlayProps" ("DeckOverlayPropId", "OverlayId", "Key", "Value") FROM stdin;
\.
COPY public."DeckOverlayProps" ("DeckOverlayPropId", "OverlayId", "Key", "Value") FROM '$$PATH$$/4794.dat';

--
-- Data for Name: DeckOverlays; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckOverlays" ("OverlayId", "DeckId", "OverlayRef", "Name", "Description", "Priority", "OverlayOn", "EntryType", "BalanceType", "Data", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckOverlays" ("OverlayId", "DeckId", "OverlayRef", "Name", "Description", "Priority", "OverlayOn", "EntryType", "BalanceType", "Data", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4793.dat';

--
-- Data for Name: DeckProps; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckProps" ("DeckPropId", "DeckId", "Key", "Value") FROM stdin;
\.
COPY public."DeckProps" ("DeckPropId", "DeckId", "Key", "Value") FROM '$$PATH$$/4767.dat';

--
-- Data for Name: DeckPulses; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckPulses" ("PulseId", "DeckId", "UserId", "AccessLevel", "Timestamp") FROM stdin;
\.
COPY public."DeckPulses" ("PulseId", "DeckId", "UserId", "AccessLevel", "Timestamp") FROM '$$PATH$$/4769.dat';

--
-- Data for Name: DeckReportLogs; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckReportLogs" ("Id", "LogId", "ExecutionId", "Timestamp", "Message", "Level", "Source", "Data") FROM stdin;
\.
COPY public."DeckReportLogs" ("Id", "LogId", "ExecutionId", "Timestamp", "Message", "Level", "Source", "Data") FROM '$$PATH$$/4783.dat';

--
-- Data for Name: DeckReports; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckReports" ("Id", "ExecutionId", "DeckId", "ReportRegistryId", "Description", "Status", "ReportType", "Data", "Result", "StartTimestamp", "EndTimestamp", "Sequence", "Priority", "CreatedBy", "CreatedWhen") FROM stdin;
\.
COPY public."DeckReports" ("Id", "ExecutionId", "DeckId", "ReportRegistryId", "Description", "Status", "ReportType", "Data", "Result", "StartTimestamp", "EndTimestamp", "Sequence", "Priority", "CreatedBy", "CreatedWhen") FROM '$$PATH$$/4781.dat';

--
-- Data for Name: DeckReportsRegistry; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckReportsRegistry" ("ReportRegistryId", "ObjectiveTypeId", "Name", "Description", "ReportType", "ParentId", "Status", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckReportsRegistry" ("ReportRegistryId", "ObjectiveTypeId", "Name", "Description", "ReportType", "ParentId", "Status", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4779.dat';

--
-- Data for Name: DeckStressEntries; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckStressEntries" ("Id", "EntryId", "DeckId", "StressId", "Data", "Sequence") FROM stdin;
\.
COPY public."DeckStressEntries" ("Id", "EntryId", "DeckId", "StressId", "Data", "Sequence") FROM '$$PATH$$/4798.dat';

--
-- Data for Name: DeckTypes; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DeckTypes" ("DeckTypeId", "Name", "Description", "IsEnabled", "Style", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."DeckTypes" ("DeckTypeId", "Name", "Description", "IsEnabled", "Style", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4763.dat';

--
-- Data for Name: Decks; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Decks" ("DeckId", "Name", "Description", "DeckTypeId", "ObjectiveTypeId", "ParentDeckId", "Data", "ReportingDate", "ExpiryDate", "EntityId", "Currency", "IsPrivate", "Status", "ConcurrencyId", "PublishedBy", "PublishedWhen", "PublishComments", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Decks" ("DeckId", "Name", "Description", "DeckTypeId", "ObjectiveTypeId", "ParentDeckId", "Data", "ReportingDate", "ExpiryDate", "EntityId", "Currency", "IsPrivate", "Status", "ConcurrencyId", "PublishedBy", "PublishedWhen", "PublishComments", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4766.dat';

--
-- Data for Name: Policies; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Policies" ("PolicyId", "ObjectiveTypeId", "PolicyType", "Description", "DefaultPolicy", "ActivePolicy", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Policies" ("PolicyId", "ObjectiveTypeId", "PolicyType", "Description", "DefaultPolicy", "ActivePolicy", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4765.dat';

--
-- Data for Name: PortfolioContent; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."PortfolioContent" ("ContentId", "Code", "Name", "Description", "Route", "DataAccess", "Content", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."PortfolioContent" ("ContentId", "Code", "Name", "Description", "Route", "DataAccess", "Content", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4755.dat';

--
-- Data for Name: PublishRequests; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."PublishRequests" ("PublishRequestId", "SeqId", "DeckId", "ExpiryDate", "Name", "Description", "ApprovalId", "CreatedBy", "CreatedWhen", "Status", "ApprovedWhen", "RejectedWhen", "Data") FROM stdin;
\.
COPY public."PublishRequests" ("PublishRequestId", "SeqId", "DeckId", "ExpiryDate", "Name", "Description", "ApprovalId", "CreatedBy", "CreatedWhen", "Status", "ApprovedWhen", "RejectedWhen", "Data") FROM '$$PATH$$/4771.dat';

--
-- Data for Name: ReportLibrary; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."ReportLibrary" ("ReportLibraryId", "ReportLibrary", "Description", "DefaultReports", "ActiveReports", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."ReportLibrary" ("ReportLibraryId", "ReportLibrary", "Description", "DefaultReports", "ActiveReports", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4754.dat';

--
-- Data for Name: ScriptLogs; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."ScriptLogs" ("ScriptLogId", "ScriptId", "OriginId", "Origin", "Status", "Logs", "StartTimestamp", "EndTimestamp") FROM stdin;
\.
COPY public."ScriptLogs" ("ScriptLogId", "ScriptId", "OriginId", "Origin", "Status", "Logs", "StartTimestamp", "EndTimestamp") FROM '$$PATH$$/4800.dat';

--
-- Data for Name: Scripts; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Scripts" ("ScriptId", "Script", "Origin", "OriginId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Scripts" ("ScriptId", "Script", "Origin", "OriginId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4799.dat';

--
-- Data for Name: SessionEntries; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."SessionEntries" ("Id", "EntryId", "SessionId", "Data", "Timestamp") FROM stdin;
\.
COPY public."SessionEntries" ("Id", "EntryId", "SessionId", "Data", "Timestamp") FROM '$$PATH$$/4762.dat';

--
-- Data for Name: Sessions; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Sessions" ("SessionId", "Name", "Status", "UserId", "ContextId", "ContextType", "Context", "CreatedWhen") FROM stdin;
\.
COPY public."Sessions" ("SessionId", "Name", "Status", "UserId", "ContextId", "ContextType", "Context", "CreatedWhen") FROM '$$PATH$$/4760.dat';

--
-- Data for Name: UiCodes; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."UiCodes" ("CodeId", "Category", "Type", "Name", "Description", "Code", "Data", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."UiCodes" ("CodeId", "Category", "Type", "Name", "Description", "Code", "Data", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4756.dat';

--
-- Data for Name: UiValidationConfigurations; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."UiValidationConfigurations" ("ConfigId", "RuleId", "Enable", "Options", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."UiValidationConfigurations" ("ConfigId", "RuleId", "Enable", "Options", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4758.dat';

--
-- Data for Name: UiValidationRules; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."UiValidationRules" ("RuleId", "Name", "Category", "Code", "Description", "Recommended", "Url", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."UiValidationRules" ("RuleId", "Name", "Category", "Code", "Description", "Recommended", "Url", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4757.dat';

--
-- Data for Name: UserReportLibrary; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."UserReportLibrary" ("UserReportLibraryId", "UserId", "ReportLibrary", "Reports", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."UserReportLibrary" ("UserReportLibraryId", "UserId", "ReportLibrary", "Reports", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4759.dat';

--
-- Data for Name: WorkspaceTemplates; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."WorkspaceTemplates" ("WorkspaceTemplateId", "ScriptId", "Name", "Description", "Type", "Data", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."WorkspaceTemplates" ("WorkspaceTemplateId", "ScriptId", "Name", "Description", "Type", "Data", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4801.dat';

--
-- Data for Name: Workspaces; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Workspaces" ("WorkspaceId", "ParentId", "Name", "Description", "Type", "Data", "Status", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Workspaces" ("WorkspaceId", "ParentId", "Name", "Description", "Type", "Data", "Status", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4802.dat';

--
-- Name: ApplicationLogs_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."ApplicationLogs_Id_seq"', 7488, true);


--
-- Name: DeckActionLogs_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."DeckActionLogs_Id_seq"', 1, false);


--
-- Name: DeckActions_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."DeckActions_Id_seq"', 1, false);


--
-- Name: DeckOverlayEntries_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."DeckOverlayEntries_Id_seq"', 1, false);


--
-- Name: DeckReportLogs_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."DeckReportLogs_Id_seq"', 1, false);


--
-- Name: DeckReports_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."DeckReports_Id_seq"', 1, false);


--
-- Name: DeckStressEntries_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."DeckStressEntries_Id_seq"', 1, false);


--
-- Name: SessionEntries_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."SessionEntries_Id_seq"', 1, false);


--
-- Name: ApplicationLogs PK_ApplicationLogs; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ApplicationLogs"
    ADD CONSTRAINT "PK_ApplicationLogs" PRIMARY KEY ("Id");


--
-- Name: Approvals PK_Approvals; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Approvals"
    ADD CONSTRAINT "PK_Approvals" PRIMARY KEY ("ApprovalId");


--
-- Name: DbVersions PK_DbVersions; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DbVersions"
    ADD CONSTRAINT "PK_DbVersions" PRIMARY KEY ("DbVersionId");


--
-- Name: DeckActionLogs PK_DeckActionLogs; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckActionLogs"
    ADD CONSTRAINT "PK_DeckActionLogs" PRIMARY KEY ("Id");


--
-- Name: DeckActions PK_DeckActions; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckActions"
    ADD CONSTRAINT "PK_DeckActions" PRIMARY KEY ("Id");


--
-- Name: DeckActivities PK_DeckActivities; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckActivities"
    ADD CONSTRAINT "PK_DeckActivities" PRIMARY KEY ("ActivityId");


--
-- Name: DeckCalculationProps PK_DeckCalculationProps; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckCalculationProps"
    ADD CONSTRAINT "PK_DeckCalculationProps" PRIMARY KEY ("DeckCalculationPropId");


--
-- Name: DeckCalculations PK_DeckCalculations; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckCalculations"
    ADD CONSTRAINT "PK_DeckCalculations" PRIMARY KEY ("CalculationId");


--
-- Name: DeckClassificationVariances PK_DeckClassificationVariances; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckClassificationVariances"
    ADD CONSTRAINT "PK_DeckClassificationVariances" PRIMARY KEY ("VarianceId");


--
-- Name: DeckFilterTemplates PK_DeckFilterTemplates; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckFilterTemplates"
    ADD CONSTRAINT "PK_DeckFilterTemplates" PRIMARY KEY ("TemplateId");


--
-- Name: DeckImpairmentDisclosureChecks PK_DeckImpairmentDisclosureChecks; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosureChecks"
    ADD CONSTRAINT "PK_DeckImpairmentDisclosureChecks" PRIMARY KEY ("CheckId");


--
-- Name: DeckImpairmentDisclosureDeltas PK_DeckImpairmentDisclosureDeltas; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosureDeltas"
    ADD CONSTRAINT "PK_DeckImpairmentDisclosureDeltas" PRIMARY KEY ("ResultId");


--
-- Name: DeckImpairmentDisclosureEcls PK_DeckImpairmentDisclosureEcls; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosureEcls"
    ADD CONSTRAINT "PK_DeckImpairmentDisclosureEcls" PRIMARY KEY ("DisclosureEclId");


--
-- Name: DeckImpairmentDisclosures PK_DeckImpairmentDisclosures; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosures"
    ADD CONSTRAINT "PK_DeckImpairmentDisclosures" PRIMARY KEY ("DisclosureId");


--
-- Name: DeckImpairmentEclCalculations PK_DeckImpairmentEclCalculations; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentEclCalculations"
    ADD CONSTRAINT "PK_DeckImpairmentEclCalculations" PRIMARY KEY ("EclCalculationId");


--
-- Name: DeckImpairmentEcls PK_DeckImpairmentEcls; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentEcls"
    ADD CONSTRAINT "PK_DeckImpairmentEcls" PRIMARY KEY ("EclId");


--
-- Name: DeckImpairmentVarianceEcls PK_DeckImpairmentVarianceEcls; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentVarianceEcls"
    ADD CONSTRAINT "PK_DeckImpairmentVarianceEcls" PRIMARY KEY ("VarianceEclId");


--
-- Name: DeckImpairmentVariances PK_DeckImpairmentVariances; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentVariances"
    ADD CONSTRAINT "PK_DeckImpairmentVariances" PRIMARY KEY ("VarianceId");


--
-- Name: DeckJobs PK_DeckJobs; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckJobs"
    ADD CONSTRAINT "PK_DeckJobs" PRIMARY KEY ("JobId");


--
-- Name: DeckObjectiveTypes PK_DeckObjectiveTypes; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckObjectiveTypes"
    ADD CONSTRAINT "PK_DeckObjectiveTypes" PRIMARY KEY ("ObjectiveTypeId");


--
-- Name: DeckOverlayEntries PK_DeckOverlayEntries; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckOverlayEntries"
    ADD CONSTRAINT "PK_DeckOverlayEntries" PRIMARY KEY ("Id");


--
-- Name: DeckOverlayProps PK_DeckOverlayProps; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckOverlayProps"
    ADD CONSTRAINT "PK_DeckOverlayProps" PRIMARY KEY ("DeckOverlayPropId");


--
-- Name: DeckOverlays PK_DeckOverlays; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckOverlays"
    ADD CONSTRAINT "PK_DeckOverlays" PRIMARY KEY ("OverlayId");


--
-- Name: DeckProps PK_DeckProps; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckProps"
    ADD CONSTRAINT "PK_DeckProps" PRIMARY KEY ("DeckPropId");


--
-- Name: DeckPulses PK_DeckPulses; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckPulses"
    ADD CONSTRAINT "PK_DeckPulses" PRIMARY KEY ("PulseId");


--
-- Name: DeckReportLogs PK_DeckReportLogs; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckReportLogs"
    ADD CONSTRAINT "PK_DeckReportLogs" PRIMARY KEY ("Id");


--
-- Name: DeckReports PK_DeckReports; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckReports"
    ADD CONSTRAINT "PK_DeckReports" PRIMARY KEY ("Id");


--
-- Name: DeckReportsRegistry PK_DeckReportsRegistry; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckReportsRegistry"
    ADD CONSTRAINT "PK_DeckReportsRegistry" PRIMARY KEY ("ReportRegistryId");


--
-- Name: DeckStressEntries PK_DeckStressEntries; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckStressEntries"
    ADD CONSTRAINT "PK_DeckStressEntries" PRIMARY KEY ("Id");


--
-- Name: DeckTypes PK_DeckTypes; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckTypes"
    ADD CONSTRAINT "PK_DeckTypes" PRIMARY KEY ("DeckTypeId");


--
-- Name: Decks PK_Decks; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Decks"
    ADD CONSTRAINT "PK_Decks" PRIMARY KEY ("DeckId");


--
-- Name: Policies PK_Policies; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Policies"
    ADD CONSTRAINT "PK_Policies" PRIMARY KEY ("PolicyId");


--
-- Name: PortfolioContent PK_PortfolioContent; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."PortfolioContent"
    ADD CONSTRAINT "PK_PortfolioContent" PRIMARY KEY ("ContentId");


--
-- Name: PublishRequests PK_PublishRequests; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."PublishRequests"
    ADD CONSTRAINT "PK_PublishRequests" PRIMARY KEY ("PublishRequestId");


--
-- Name: ReportLibrary PK_ReportLibrary; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ReportLibrary"
    ADD CONSTRAINT "PK_ReportLibrary" PRIMARY KEY ("ReportLibraryId");


--
-- Name: ScriptLogs PK_ScriptLogs; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ScriptLogs"
    ADD CONSTRAINT "PK_ScriptLogs" PRIMARY KEY ("ScriptLogId");


--
-- Name: Scripts PK_Scripts; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Scripts"
    ADD CONSTRAINT "PK_Scripts" PRIMARY KEY ("ScriptId");


--
-- Name: SessionEntries PK_SessionEntries; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."SessionEntries"
    ADD CONSTRAINT "PK_SessionEntries" PRIMARY KEY ("Id");


--
-- Name: Sessions PK_Sessions; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Sessions"
    ADD CONSTRAINT "PK_Sessions" PRIMARY KEY ("SessionId");


--
-- Name: UiCodes PK_UiCodes; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."UiCodes"
    ADD CONSTRAINT "PK_UiCodes" PRIMARY KEY ("CodeId");


--
-- Name: UiValidationConfigurations PK_UiValidationConfigurations; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."UiValidationConfigurations"
    ADD CONSTRAINT "PK_UiValidationConfigurations" PRIMARY KEY ("ConfigId");


--
-- Name: UiValidationRules PK_UiValidationRules; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."UiValidationRules"
    ADD CONSTRAINT "PK_UiValidationRules" PRIMARY KEY ("RuleId");


--
-- Name: UserReportLibrary PK_UserReportLibrary; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."UserReportLibrary"
    ADD CONSTRAINT "PK_UserReportLibrary" PRIMARY KEY ("UserReportLibraryId");


--
-- Name: WorkspaceTemplates PK_WorkspaceTemplates; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."WorkspaceTemplates"
    ADD CONSTRAINT "PK_WorkspaceTemplates" PRIMARY KEY ("WorkspaceTemplateId");


--
-- Name: Workspaces PK_Workspaces; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Workspaces"
    ADD CONSTRAINT "PK_Workspaces" PRIMARY KEY ("WorkspaceId");


--
-- Name: IX_ApplicationLogs; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_ApplicationLogs" ON public."ApplicationLogs" USING btree ("LogId");


--
-- Name: IX_Approvals_ApprovalId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_Approvals_ApprovalId" ON public."Approvals" USING btree ("ApprovalId");


--
-- Name: IX_DeckActionLogs_ExecutionId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckActionLogs_ExecutionId" ON public."DeckActionLogs" USING btree ("ExecutionId");


--
-- Name: IX_DeckActionLogs_LogId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckActionLogs_LogId" ON public."DeckActionLogs" USING btree ("LogId");


--
-- Name: IX_DeckActions_ExecutionId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckActions_ExecutionId" ON public."DeckActions" USING btree ("ExecutionId");


--
-- Name: IX_DeckCalculations_CalculationId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckCalculations_CalculationId" ON public."DeckCalculations" USING btree ("CalculationId");


--
-- Name: IX_DeckClassificationVariances_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckClassificationVariances_DeckId" ON public."DeckClassificationVariances" USING btree ("DeckId");


--
-- Name: IX_DeckImpairmentDisclosureEcls_DisclosureId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentDisclosureEcls_DisclosureId" ON public."DeckImpairmentDisclosureEcls" USING btree ("DisclosureId");


--
-- Name: IX_DeckImpairmentDisclosureEcls_EclId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentDisclosureEcls_EclId" ON public."DeckImpairmentDisclosureEcls" USING btree ("EclId");


--
-- Name: IX_DeckImpairmentDisclosures_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentDisclosures_DeckId" ON public."DeckImpairmentDisclosures" USING btree ("DeckId");


--
-- Name: IX_DeckImpairmentEclCalculations_EclId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentEclCalculations_EclId" ON public."DeckImpairmentEclCalculations" USING btree ("EclId");


--
-- Name: IX_DeckImpairmentEcls_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentEcls_DeckId" ON public."DeckImpairmentEcls" USING btree ("DeckId");


--
-- Name: IX_DeckImpairmentVarianceEcls_EclId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentVarianceEcls_EclId" ON public."DeckImpairmentVarianceEcls" USING btree ("EclId");


--
-- Name: IX_DeckImpairmentVarianceEcls_VarianceId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentVarianceEcls_VarianceId" ON public."DeckImpairmentVarianceEcls" USING btree ("VarianceId");


--
-- Name: IX_DeckImpairmentVariances_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckImpairmentVariances_DeckId" ON public."DeckImpairmentVariances" USING btree ("DeckId");


--
-- Name: IX_DeckJobs_JobId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckJobs_JobId" ON public."DeckJobs" USING btree ("JobId");


--
-- Name: IX_DeckOverlayEntries_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckOverlayEntries_DeckId" ON public."DeckOverlayEntries" USING btree ("DeckId");


--
-- Name: IX_DeckOverlayEntries_EntryId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckOverlayEntries_EntryId" ON public."DeckOverlayEntries" USING btree ("EntryId");


--
-- Name: IX_DeckOverlayEntries_OverlayId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckOverlayEntries_OverlayId" ON public."DeckOverlayEntries" USING btree ("OverlayId");


--
-- Name: IX_DeckReportLogs_ExecutionId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckReportLogs_ExecutionId" ON public."DeckReportLogs" USING btree ("ExecutionId");


--
-- Name: IX_DeckReportLogs_LogId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckReportLogs_LogId" ON public."DeckReportLogs" USING btree ("LogId");


--
-- Name: IX_DeckReports_ExecutionId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckReports_ExecutionId" ON public."DeckReports" USING btree ("ExecutionId");


--
-- Name: IX_DeckStressEntries_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckStressEntries_DeckId" ON public."DeckStressEntries" USING btree ("DeckId");


--
-- Name: IX_DeckStressEntries_EntryId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_DeckStressEntries_EntryId" ON public."DeckStressEntries" USING btree ("EntryId");


--
-- Name: IX_DeckStressEntries_StressId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_DeckStressEntries_StressId" ON public."DeckStressEntries" USING btree ("StressId");


--
-- Name: IX_PortfolioContent_Code; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_PortfolioContent_Code" ON public."PortfolioContent" USING btree ("Code");


--
-- Name: IX_PortfolioContent_Route; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_PortfolioContent_Route" ON public."PortfolioContent" USING btree ("Route");


--
-- Name: IX_PublishRequests_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_PublishRequests_DeckId" ON public."PublishRequests" USING btree ("DeckId");


--
-- Name: IX_SessionEntries_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_SessionEntries_DeckId" ON public."SessionEntries" USING btree ("SessionId");


--
-- Name: IX_SessionEntries_EntryId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_SessionEntries_EntryId" ON public."SessionEntries" USING btree ("EntryId");


--
-- Name: DeckActionLogs FK_DeckActionLogs_DeckActions_ExecutionId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckActionLogs"
    ADD CONSTRAINT "FK_DeckActionLogs_DeckActions_ExecutionId" FOREIGN KEY ("ExecutionId") REFERENCES public."DeckActions"("ExecutionId") ON DELETE CASCADE;


--
-- Name: DeckActions FK_DeckActions_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckActions"
    ADD CONSTRAINT "FK_DeckActions_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckCalculationProps FK_DeckCalculationProps_DeckCalculations_CalculationId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckCalculationProps"
    ADD CONSTRAINT "FK_DeckCalculationProps_DeckCalculations_CalculationId" FOREIGN KEY ("CalculationId") REFERENCES public."DeckCalculations"("CalculationId") ON DELETE CASCADE;


--
-- Name: DeckCalculations FK_DeckCalculations_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckCalculations"
    ADD CONSTRAINT "FK_DeckCalculations_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckClassificationVariances FK_DeckClassificationVariances_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckClassificationVariances"
    ADD CONSTRAINT "FK_DeckClassificationVariances_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckImpairmentDisclosureDeltas FK_DeckImpairmentDisclosureDeltas_DeckImpairmentDisclosures_Dis; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosureDeltas"
    ADD CONSTRAINT "FK_DeckImpairmentDisclosureDeltas_DeckImpairmentDisclosures_Dis" FOREIGN KEY ("DisclosureId") REFERENCES public."DeckImpairmentDisclosures"("DisclosureId") ON DELETE CASCADE;


--
-- Name: DeckImpairmentDisclosureEcls FK_DeckImpairmentDisclosureEcls_DeckImpairmentDisclosures_Discl; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosureEcls"
    ADD CONSTRAINT "FK_DeckImpairmentDisclosureEcls_DeckImpairmentDisclosures_Discl" FOREIGN KEY ("DisclosureId") REFERENCES public."DeckImpairmentDisclosures"("DisclosureId") ON DELETE CASCADE;


--
-- Name: DeckImpairmentDisclosureEcls FK_DeckImpairmentDisclosureEcls_DeckImpairmentEcls_EclId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosureEcls"
    ADD CONSTRAINT "FK_DeckImpairmentDisclosureEcls_DeckImpairmentEcls_EclId" FOREIGN KEY ("EclId") REFERENCES public."DeckImpairmentEcls"("EclId");


--
-- Name: DeckImpairmentDisclosures FK_DeckImpairmentDisclosures_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentDisclosures"
    ADD CONSTRAINT "FK_DeckImpairmentDisclosures_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckImpairmentEclCalculations FK_DeckImpairmentEclCalculations_DeckImpairmentEcls_EclId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentEclCalculations"
    ADD CONSTRAINT "FK_DeckImpairmentEclCalculations_DeckImpairmentEcls_EclId" FOREIGN KEY ("EclId") REFERENCES public."DeckImpairmentEcls"("EclId") ON DELETE CASCADE;


--
-- Name: DeckImpairmentEcls FK_DeckImpairmentEcls_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentEcls"
    ADD CONSTRAINT "FK_DeckImpairmentEcls_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckImpairmentVarianceEcls FK_DeckImpairmentVarianceEcls_DeckImpairmentEcls_EclId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentVarianceEcls"
    ADD CONSTRAINT "FK_DeckImpairmentVarianceEcls_DeckImpairmentEcls_EclId" FOREIGN KEY ("EclId") REFERENCES public."DeckImpairmentEcls"("EclId") ON DELETE CASCADE;


--
-- Name: DeckImpairmentVarianceEcls FK_DeckImpairmentVarianceEcls_DeckImpairmentVariances_VarianceI; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentVarianceEcls"
    ADD CONSTRAINT "FK_DeckImpairmentVarianceEcls_DeckImpairmentVariances_VarianceI" FOREIGN KEY ("VarianceId") REFERENCES public."DeckImpairmentVariances"("VarianceId");


--
-- Name: DeckImpairmentVariances FK_DeckImpairmentVariances_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckImpairmentVariances"
    ADD CONSTRAINT "FK_DeckImpairmentVariances_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckJobs FK_DeckJobs_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckJobs"
    ADD CONSTRAINT "FK_DeckJobs_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckOverlayEntries FK_DeckOverlayEntries_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckOverlayEntries"
    ADD CONSTRAINT "FK_DeckOverlayEntries_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckOverlayProps FK_DeckOverlayProps_DeckOverlays_OverlayId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckOverlayProps"
    ADD CONSTRAINT "FK_DeckOverlayProps_DeckOverlays_OverlayId" FOREIGN KEY ("OverlayId") REFERENCES public."DeckOverlays"("OverlayId") ON DELETE CASCADE;


--
-- Name: DeckOverlays FK_DeckOverlays_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckOverlays"
    ADD CONSTRAINT "FK_DeckOverlays_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckProps FK_DeckProps_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckProps"
    ADD CONSTRAINT "FK_DeckProps_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckReportLogs FK_DeckReportLogs_DeckReports_ExecutionId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckReportLogs"
    ADD CONSTRAINT "FK_DeckReportLogs_DeckReports_ExecutionId" FOREIGN KEY ("ExecutionId") REFERENCES public."DeckReports"("ExecutionId") ON DELETE CASCADE;


--
-- Name: DeckReports FK_DeckReports_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckReports"
    ADD CONSTRAINT "FK_DeckReports_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: DeckStressEntries FK_DeckStressEntries_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DeckStressEntries"
    ADD CONSTRAINT "FK_DeckStressEntries_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: Policies FK_Policies_ObjectiveTypes_ObjectiveTypeId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Policies"
    ADD CONSTRAINT "FK_Policies_ObjectiveTypes_ObjectiveTypeId" FOREIGN KEY ("ObjectiveTypeId") REFERENCES public."DeckObjectiveTypes"("ObjectiveTypeId") ON DELETE CASCADE;


--
-- Name: PublishRequests FK_PublishRequests_Decks_DeckId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."PublishRequests"
    ADD CONSTRAINT "FK_PublishRequests_Decks_DeckId" FOREIGN KEY ("DeckId") REFERENCES public."Decks"("DeckId") ON DELETE CASCADE;


--
-- Name: ScriptLogs FK_ScriptLogs_Scripts_ScriptId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ScriptLogs"
    ADD CONSTRAINT "FK_ScriptLogs_Scripts_ScriptId" FOREIGN KEY ("ScriptId") REFERENCES public."Scripts"("ScriptId") ON DELETE CASCADE;


--
-- Name: SessionEntries FK_SessionEntries_Sessions_SessionId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."SessionEntries"
    ADD CONSTRAINT "FK_SessionEntries_Sessions_SessionId" FOREIGN KEY ("SessionId") REFERENCES public."Sessions"("SessionId") ON DELETE CASCADE;


--
-- Name: UiValidationConfigurations FK_UiValidationConfigurations_UiValidationRules_RuleId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."UiValidationConfigurations"
    ADD CONSTRAINT "FK_UiValidationConfigurations_UiValidationRules_RuleId" FOREIGN KEY ("RuleId") REFERENCES public."UiValidationRules"("RuleId") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

