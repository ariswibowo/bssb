--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Models";
--
-- Name: Models; Type: DATABASE; Schema: -; Owner: Elysian
--

CREATE DATABASE "Models" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "Models" OWNER TO "Elysian";

\unrestrict (null)
\connect "Models"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: GetApproachSegment(); Type: FUNCTION; Schema: public; Owner: Elysian
--

CREATE FUNCTION public."GetApproachSegment"() RETURNS TABLE("VersionId" text, "ApproachId" text, "SegmentId" text, "MeasurementUnit" text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT
        UPPER(V."VersionId"::text) as "VersionId" ,
        UPPER(approachList."approachId") AS "ApproachId",
        UPPER(segmentList."segmentId") AS "SegmentId",
        cast(approachList."method"::jsonb->'configuration'->'observation'->>'measurementUnit' as text) AS "MeasurementUnit"
    FROM "VersionProps" V,
        jsonb_to_recordset(V."Value"::jsonb->'approaches') AS approachList("approachId" text, "name" text, "description" text, "segments" text, "method" text),
        jsonb_to_recordset(approachList."segments"::jsonb) AS segmentList("segmentId" text)
        --jsonb_to_recordset(approachList."methods"::jsonb) AS configurationList("configuration" text)
    WHERE "Key" = 'Approaches';
END;
$$;


ALTER FUNCTION public."GetApproachSegment"() OWNER TO "Elysian";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Activities; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Activities" (
    "ActivityId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "SourceId" uuid NOT NULL,
    "Source" character varying(50) NOT NULL,
    "Action" character varying(50) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Trace" text,
    "Timestamp" timestamp without time zone NOT NULL,
    "ImpersonatedUserId" uuid
);


ALTER TABLE public."Activities" OWNER TO "Elysian";

--
-- Name: Approvals; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Approvals" (
    "ApprovalId" uuid NOT NULL,
    "Request" text NOT NULL,
    "Response" text,
    "ApprovalStatus" character varying(50) NOT NULL
);


ALTER TABLE public."Approvals" OWNER TO "Elysian";

--
-- Name: CalcMethods; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."CalcMethods" (
    "CalcMethodId" uuid NOT NULL,
    "ObjectiveTypeId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Code" character varying(50) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."CalcMethods" OWNER TO "Elysian";

--
-- Name: ClQuestionnaires; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."ClQuestionnaires" (
    "QuestionnaireId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "QuestionnaireType" character varying(100) NOT NULL,
    "ObjectiveTypeId" uuid NOT NULL,
    "Data" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."ClQuestionnaires" OWNER TO "Elysian";

--
-- Name: Codes; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Codes" (
    "CodeId" uuid NOT NULL,
    "DomainId" uuid NOT NULL,
    "Category" character varying(50) NOT NULL,
    "Type" character varying(50) NOT NULL,
    "Data" text NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Codes" OWNER TO "Elysian";

--
-- Name: DbVersions; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."DbVersions" (
    "DbVersionId" uuid NOT NULL,
    "DbVersion" character varying(50) NOT NULL,
    "IsInstalledVersion" boolean NOT NULL,
    "ReleaseName" character varying(100) NOT NULL,
    "ReleaseDescription" character varying(300) NOT NULL,
    "InstallAttempt" integer NOT NULL,
    "InstallStatus" character varying(50) NOT NULL,
    "InstallStarted" timestamp without time zone NOT NULL,
    "InstallEnded" timestamp without time zone NOT NULL,
    "InstallComments" character varying(300) NOT NULL,
    "InstalledBy" character varying(100) NOT NULL
);


ALTER TABLE public."DbVersions" OWNER TO "Elysian";

--
-- Name: Domains; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Domains" (
    "DomainId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Code" character varying(50) NOT NULL,
    "Data" text NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Domains" OWNER TO "Elysian";

--
-- Name: ModelTypes; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."ModelTypes" (
    "ModelTypeId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "Style" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."ModelTypes" OWNER TO "Elysian";

--
-- Name: Models; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Models" (
    "ModelId" uuid NOT NULL,
    "DomainId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "ModelTypeId" uuid NOT NULL,
    "ObjectiveTypeId" uuid NOT NULL,
    "ParentDeckId" uuid,
    "IsPrivate" boolean NOT NULL,
    "Status" character varying(50) NOT NULL,
    "Data" text,
    "LatestVersionId" uuid NOT NULL,
    "LatestVersion" integer NOT NULL,
    "LatestStatus" character varying(50) NOT NULL,
    "LatestErrors" integer,
    "LatestWarnings" integer,
    "LatestValidatedWhen" timestamp without time zone,
    "PublishedVersions" integer NOT NULL,
    "ArchivedBy" uuid,
    "ArchivedWhen" timestamp without time zone,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Models" OWNER TO "Elysian";

--
-- Name: ObjectiveTypes; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."ObjectiveTypes" (
    "ObjectiveTypeId" uuid NOT NULL,
    "DomainId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Code" character varying(50) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."ObjectiveTypes" OWNER TO "Elysian";

--
-- Name: Policies; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Policies" (
    "PolicyId" uuid NOT NULL,
    "DomainId" uuid,
    "ObjectiveTypeId" uuid,
    "PolicyType" character varying(50) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "DefaultPolicy" text,
    "ActivePolicy" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Policies" OWNER TO "Elysian";

--
-- Name: PublishRequests; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."PublishRequests" (
    "PublishRequestId" uuid NOT NULL,
    "SeqId" integer NOT NULL,
    "VersionId" uuid NOT NULL,
    "ExpiryDate" timestamp without time zone,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "ApprovalId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "Status" character varying(50) NOT NULL,
    "ApprovedWhen" timestamp without time zone,
    "RejectedWhen" timestamp without time zone
);


ALTER TABLE public."PublishRequests" OWNER TO "Elysian";

--
-- Name: Pulses; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Pulses" (
    "PulseId" uuid NOT NULL,
    "TargetId" uuid NOT NULL,
    "TargetType" character varying(50) NOT NULL,
    "UserId" uuid NOT NULL,
    "Context" text,
    "Timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public."Pulses" OWNER TO "Elysian";

--
-- Name: SessionEntries_Id_seq; Type: SEQUENCE; Schema: public; Owner: Elysian
--

CREATE SEQUENCE public."SessionEntries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SessionEntries_Id_seq" OWNER TO "Elysian";

--
-- Name: SessionEntries; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."SessionEntries" (
    "Id" bigint DEFAULT nextval('public."SessionEntries_Id_seq"'::regclass) NOT NULL,
    "EntryId" uuid NOT NULL,
    "SessionId" uuid NOT NULL,
    "Data" text,
    "Timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public."SessionEntries" OWNER TO "Elysian";

--
-- Name: Sessions; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Sessions" (
    "SessionId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Status" character varying(50) NOT NULL,
    "UserId" uuid NOT NULL,
    "ContextId" uuid,
    "ContextType" character varying(50) NOT NULL,
    "Context" text,
    "CreatedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Sessions" OWNER TO "Elysian";

--
-- Name: SupervisorDict; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."SupervisorDict" (
    "SupervisorDictId" uuid NOT NULL,
    "SupervisorId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300),
    "Type" character varying(50) NOT NULL,
    "Regulation" character varying(50),
    "Revision" character varying(50),
    "Class" character varying(50),
    "Code" character varying(50),
    "Ancestors" text,
    "ParentId" uuid,
    "Documents" text,
    "Data" text
);


ALTER TABLE public."SupervisorDict" OWNER TO "Elysian";

--
-- Name: Supervisors; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Supervisors" (
    "SupervisorId" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Description" character varying(300) NOT NULL,
    "Type" character varying(50) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "Data" text,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Supervisors" OWNER TO "Elysian";

--
-- Name: V_CalcMethods; Type: VIEW; Schema: public; Owner: Elysian
--

CREATE VIEW public."V_CalcMethods" AS
 SELECT "CalcMethods"."CalcMethodId",
    "Domains"."DomainId",
    "Domains"."Code" AS "Domain",
    "ObjectiveTypes"."ObjectiveTypeId",
    "ObjectiveTypes"."Code" AS "ObjectiveType",
    "CalcMethods"."Name",
    "CalcMethods"."Description",
    "CalcMethods"."Code",
    "CalcMethods"."IsEnabled",
    "CalcMethods"."CreatedBy",
    "CalcMethods"."LastModifiedBy",
    "CalcMethods"."CreatedWhen",
    "CalcMethods"."LastModifiedWhen"
   FROM ((public."CalcMethods"
     JOIN public."ObjectiveTypes" ON (("ObjectiveTypes"."ObjectiveTypeId" = "CalcMethods"."ObjectiveTypeId")))
     JOIN public."Domains" ON (("Domains"."DomainId" = "ObjectiveTypes"."DomainId")));


ALTER VIEW public."V_CalcMethods" OWNER TO "Elysian";

--
-- Name: V_Codes; Type: VIEW; Schema: public; Owner: Elysian
--

CREATE VIEW public."V_Codes" AS
 SELECT "Codes"."CodeId",
    "Domains"."DomainId",
    "Domains"."Code" AS "Domain",
    "Codes"."Category",
    "Codes"."Type",
    "Codes"."Data",
    "Codes"."CreatedBy",
    "Codes"."LastModifiedBy",
    "Codes"."CreatedWhen",
    "Codes"."LastModifiedWhen"
   FROM (public."Domains"
     JOIN public."Codes" ON (("Domains"."DomainId" = "Codes"."DomainId")));


ALTER VIEW public."V_Codes" OWNER TO "Elysian";

--
-- Name: V_ObjectiveTypes; Type: VIEW; Schema: public; Owner: Elysian
--

CREATE VIEW public."V_ObjectiveTypes" AS
 SELECT "ObjectiveTypes"."ObjectiveTypeId",
    "Domains"."DomainId",
    "Domains"."Code" AS "Domain",
    "ObjectiveTypes"."Name",
    "ObjectiveTypes"."Description",
    "ObjectiveTypes"."Code",
    "ObjectiveTypes"."IsEnabled",
    "ObjectiveTypes"."CreatedBy",
    "ObjectiveTypes"."LastModifiedBy",
    "ObjectiveTypes"."CreatedWhen",
    "ObjectiveTypes"."LastModifiedWhen"
   FROM (public."Domains"
     JOIN public."ObjectiveTypes" ON (("Domains"."DomainId" = "ObjectiveTypes"."DomainId")));


ALTER VIEW public."V_ObjectiveTypes" OWNER TO "Elysian";

--
-- Name: V_Policies; Type: VIEW; Schema: public; Owner: Elysian
--

CREATE VIEW public."V_Policies" AS
 SELECT "Policies"."PolicyId",
    "Domains"."DomainId",
    "Domains"."Code" AS "Domain",
    "ObjectiveTypes"."ObjectiveTypeId",
    "ObjectiveTypes"."Code" AS "ObjectiveType",
    "Policies"."PolicyType",
    "Policies"."Description",
    "Policies"."DefaultPolicy",
    "Policies"."ActivePolicy",
    "Policies"."CreatedBy",
    "Policies"."LastModifiedBy",
    "Policies"."CreatedWhen",
    "Policies"."LastModifiedWhen"
   FROM ((public."Domains"
     JOIN public."Policies" ON (("Domains"."DomainId" = "Policies"."DomainId")))
     LEFT JOIN public."ObjectiveTypes" ON (("ObjectiveTypes"."ObjectiveTypeId" = "Policies"."ObjectiveTypeId")));


ALTER VIEW public."V_Policies" OWNER TO "Elysian";

--
-- Name: VersionProps; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."VersionProps" (
    "VersionPropId" uuid NOT NULL,
    "VersionId" uuid NOT NULL,
    "Key" character varying(100) NOT NULL,
    "Value" text NOT NULL
);


ALTER TABLE public."VersionProps" OWNER TO "Elysian";

--
-- Name: Versions; Type: TABLE; Schema: public; Owner: Elysian
--

CREATE TABLE public."Versions" (
    "VersionId" uuid NOT NULL,
    "ModelId" uuid NOT NULL,
    "Version" integer NOT NULL,
    "Description" character varying(300),
    "Status" character varying(50) NOT NULL,
    "PublishedBy" uuid,
    "PublishedWhen" timestamp without time zone,
    "PublishComments" character varying(300),
    "ExpiryDate" timestamp without time zone,
    "ArchivedBy" uuid,
    "ArchivedWhen" timestamp without time zone,
    "ConcurrencyId" uuid NOT NULL,
    "CreatedBy" uuid NOT NULL,
    "CreatedWhen" timestamp without time zone NOT NULL,
    "LastModifiedBy" uuid NOT NULL,
    "LastModifiedWhen" timestamp without time zone NOT NULL
);


ALTER TABLE public."Versions" OWNER TO "Elysian";

--
-- Data for Name: Activities; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Activities" ("ActivityId", "UserId", "SourceId", "Source", "Action", "Description", "Trace", "Timestamp", "ImpersonatedUserId") FROM stdin;
\.
COPY public."Activities" ("ActivityId", "UserId", "SourceId", "Source", "Action", "Description", "Trace", "Timestamp", "ImpersonatedUserId") FROM '$$PATH$$/4575.dat';

--
-- Data for Name: Approvals; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Approvals" ("ApprovalId", "Request", "Response", "ApprovalStatus") FROM stdin;
\.
COPY public."Approvals" ("ApprovalId", "Request", "Response", "ApprovalStatus") FROM '$$PATH$$/4574.dat';

--
-- Data for Name: CalcMethods; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."CalcMethods" ("CalcMethodId", "ObjectiveTypeId", "Name", "Description", "Code", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."CalcMethods" ("CalcMethodId", "ObjectiveTypeId", "Name", "Description", "Code", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4567.dat';

--
-- Data for Name: ClQuestionnaires; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."ClQuestionnaires" ("QuestionnaireId", "Name", "Description", "QuestionnaireType", "ObjectiveTypeId", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."ClQuestionnaires" ("QuestionnaireId", "Name", "Description", "QuestionnaireType", "ObjectiveTypeId", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4573.dat';

--
-- Data for Name: Codes; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Codes" ("CodeId", "DomainId", "Category", "Type", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Codes" ("CodeId", "DomainId", "Category", "Type", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4564.dat';

--
-- Data for Name: DbVersions; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."DbVersions" ("DbVersionId", "DbVersion", "IsInstalledVersion", "ReleaseName", "ReleaseDescription", "InstallAttempt", "InstallStatus", "InstallStarted", "InstallEnded", "InstallComments", "InstalledBy") FROM stdin;
\.
COPY public."DbVersions" ("DbVersionId", "DbVersion", "IsInstalledVersion", "ReleaseName", "ReleaseDescription", "InstallAttempt", "InstallStatus", "InstallStarted", "InstallEnded", "InstallComments", "InstalledBy") FROM '$$PATH$$/4562.dat';

--
-- Data for Name: Domains; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Domains" ("DomainId", "Name", "Description", "Code", "Data", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Domains" ("DomainId", "Name", "Description", "Code", "Data", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4563.dat';

--
-- Data for Name: ModelTypes; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."ModelTypes" ("ModelTypeId", "Name", "Description", "IsEnabled", "Style", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."ModelTypes" ("ModelTypeId", "Name", "Description", "IsEnabled", "Style", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4565.dat';

--
-- Data for Name: Models; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Models" ("ModelId", "DomainId", "Name", "Description", "ModelTypeId", "ObjectiveTypeId", "ParentDeckId", "IsPrivate", "Status", "Data", "LatestVersionId", "LatestVersion", "LatestStatus", "LatestErrors", "LatestWarnings", "LatestValidatedWhen", "PublishedVersions", "ArchivedBy", "ArchivedWhen", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Models" ("ModelId", "DomainId", "Name", "Description", "ModelTypeId", "ObjectiveTypeId", "ParentDeckId", "IsPrivate", "Status", "Data", "LatestVersionId", "LatestVersion", "LatestStatus", "LatestErrors", "LatestWarnings", "LatestValidatedWhen", "PublishedVersions", "ArchivedBy", "ArchivedWhen", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4569.dat';

--
-- Data for Name: ObjectiveTypes; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."ObjectiveTypes" ("ObjectiveTypeId", "DomainId", "Name", "Description", "Code", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."ObjectiveTypes" ("ObjectiveTypeId", "DomainId", "Name", "Description", "Code", "IsEnabled", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4566.dat';

--
-- Data for Name: Policies; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Policies" ("PolicyId", "DomainId", "ObjectiveTypeId", "PolicyType", "Description", "DefaultPolicy", "ActivePolicy", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Policies" ("PolicyId", "DomainId", "ObjectiveTypeId", "PolicyType", "Description", "DefaultPolicy", "ActivePolicy", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4568.dat';

--
-- Data for Name: PublishRequests; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."PublishRequests" ("PublishRequestId", "SeqId", "VersionId", "ExpiryDate", "Name", "Description", "ApprovalId", "CreatedBy", "CreatedWhen", "Status", "ApprovedWhen", "RejectedWhen") FROM stdin;
\.
COPY public."PublishRequests" ("PublishRequestId", "SeqId", "VersionId", "ExpiryDate", "Name", "Description", "ApprovalId", "CreatedBy", "CreatedWhen", "Status", "ApprovedWhen", "RejectedWhen") FROM '$$PATH$$/4572.dat';

--
-- Data for Name: Pulses; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Pulses" ("PulseId", "TargetId", "TargetType", "UserId", "Context", "Timestamp") FROM stdin;
\.
COPY public."Pulses" ("PulseId", "TargetId", "TargetType", "UserId", "Context", "Timestamp") FROM '$$PATH$$/4576.dat';

--
-- Data for Name: SessionEntries; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."SessionEntries" ("Id", "EntryId", "SessionId", "Data", "Timestamp") FROM stdin;
\.
COPY public."SessionEntries" ("Id", "EntryId", "SessionId", "Data", "Timestamp") FROM '$$PATH$$/4579.dat';

--
-- Data for Name: Sessions; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Sessions" ("SessionId", "Name", "Status", "UserId", "ContextId", "ContextType", "Context", "CreatedWhen") FROM stdin;
\.
COPY public."Sessions" ("SessionId", "Name", "Status", "UserId", "ContextId", "ContextType", "Context", "CreatedWhen") FROM '$$PATH$$/4577.dat';

--
-- Data for Name: SupervisorDict; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."SupervisorDict" ("SupervisorDictId", "SupervisorId", "Name", "Description", "Type", "Regulation", "Revision", "Class", "Code", "Ancestors", "ParentId", "Documents", "Data") FROM stdin;
\.
COPY public."SupervisorDict" ("SupervisorDictId", "SupervisorId", "Name", "Description", "Type", "Regulation", "Revision", "Class", "Code", "Ancestors", "ParentId", "Documents", "Data") FROM '$$PATH$$/4581.dat';

--
-- Data for Name: Supervisors; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Supervisors" ("SupervisorId", "Name", "Description", "Type", "IsEnabled", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Supervisors" ("SupervisorId", "Name", "Description", "Type", "IsEnabled", "Data", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4580.dat';

--
-- Data for Name: VersionProps; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."VersionProps" ("VersionPropId", "VersionId", "Key", "Value") FROM stdin;
\.
COPY public."VersionProps" ("VersionPropId", "VersionId", "Key", "Value") FROM '$$PATH$$/4571.dat';

--
-- Data for Name: Versions; Type: TABLE DATA; Schema: public; Owner: Elysian
--

COPY public."Versions" ("VersionId", "ModelId", "Version", "Description", "Status", "PublishedBy", "PublishedWhen", "PublishComments", "ExpiryDate", "ArchivedBy", "ArchivedWhen", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM stdin;
\.
COPY public."Versions" ("VersionId", "ModelId", "Version", "Description", "Status", "PublishedBy", "PublishedWhen", "PublishComments", "ExpiryDate", "ArchivedBy", "ArchivedWhen", "ConcurrencyId", "CreatedBy", "CreatedWhen", "LastModifiedBy", "LastModifiedWhen") FROM '$$PATH$$/4570.dat';

--
-- Name: SessionEntries_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: Elysian
--

SELECT pg_catalog.setval('public."SessionEntries_Id_seq"', 1, false);


--
-- Name: Activities PK_Activities; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Activities"
    ADD CONSTRAINT "PK_Activities" PRIMARY KEY ("ActivityId");


--
-- Name: Approvals PK_Approvals; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Approvals"
    ADD CONSTRAINT "PK_Approvals" PRIMARY KEY ("ApprovalId");


--
-- Name: CalcMethods PK_CalcMethods; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."CalcMethods"
    ADD CONSTRAINT "PK_CalcMethods" PRIMARY KEY ("CalcMethodId");


--
-- Name: ClQuestionnaires PK_ClQuestionnaires; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ClQuestionnaires"
    ADD CONSTRAINT "PK_ClQuestionnaires" PRIMARY KEY ("QuestionnaireId");


--
-- Name: Codes PK_Codes; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Codes"
    ADD CONSTRAINT "PK_Codes" PRIMARY KEY ("CodeId");


--
-- Name: DbVersions PK_DbVersions; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."DbVersions"
    ADD CONSTRAINT "PK_DbVersions" PRIMARY KEY ("DbVersionId");


--
-- Name: Domains PK_Domains; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Domains"
    ADD CONSTRAINT "PK_Domains" PRIMARY KEY ("DomainId");


--
-- Name: ModelTypes PK_ModelTypes; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ModelTypes"
    ADD CONSTRAINT "PK_ModelTypes" PRIMARY KEY ("ModelTypeId");


--
-- Name: Models PK_Models; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Models"
    ADD CONSTRAINT "PK_Models" PRIMARY KEY ("ModelId");


--
-- Name: ObjectiveTypes PK_ObjectiveTypes; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ObjectiveTypes"
    ADD CONSTRAINT "PK_ObjectiveTypes" PRIMARY KEY ("ObjectiveTypeId");


--
-- Name: Policies PK_Policies; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Policies"
    ADD CONSTRAINT "PK_Policies" PRIMARY KEY ("PolicyId");


--
-- Name: PublishRequests PK_PublishRequests; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."PublishRequests"
    ADD CONSTRAINT "PK_PublishRequests" PRIMARY KEY ("PublishRequestId");


--
-- Name: Pulses PK_Pulses; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Pulses"
    ADD CONSTRAINT "PK_Pulses" PRIMARY KEY ("PulseId");


--
-- Name: SessionEntries PK_SessionEntries; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."SessionEntries"
    ADD CONSTRAINT "PK_SessionEntries" PRIMARY KEY ("Id");


--
-- Name: Sessions PK_Sessions; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Sessions"
    ADD CONSTRAINT "PK_Sessions" PRIMARY KEY ("SessionId");


--
-- Name: SupervisorDict PK_SupervisorDict; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."SupervisorDict"
    ADD CONSTRAINT "PK_SupervisorDict" PRIMARY KEY ("SupervisorDictId");


--
-- Name: Supervisors PK_Supervisors; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Supervisors"
    ADD CONSTRAINT "PK_Supervisors" PRIMARY KEY ("SupervisorId");


--
-- Name: VersionProps PK_VersionProps; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."VersionProps"
    ADD CONSTRAINT "PK_VersionProps" PRIMARY KEY ("VersionPropId");


--
-- Name: Versions PK_Versions; Type: CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Versions"
    ADD CONSTRAINT "PK_Versions" PRIMARY KEY ("VersionId");


--
-- Name: IX_Approvals_ApprovalId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_Approvals_ApprovalId" ON public."Approvals" USING btree ("ApprovalId");


--
-- Name: IX_Codes; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_Codes" ON public."Codes" USING btree ("DomainId", "Category", "Type");


--
-- Name: IX_ObjectiveTypes; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_ObjectiveTypes" ON public."ObjectiveTypes" USING btree ("DomainId", "Code");


--
-- Name: IX_PublishRequests_VersionId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_PublishRequests_VersionId" ON public."PublishRequests" USING btree ("VersionId");


--
-- Name: IX_SessionEntries_DeckId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_SessionEntries_DeckId" ON public."SessionEntries" USING btree ("SessionId");


--
-- Name: IX_SessionEntries_EntryId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE UNIQUE INDEX "IX_SessionEntries_EntryId" ON public."SessionEntries" USING btree ("EntryId");


--
-- Name: IX_Versions_ModelId; Type: INDEX; Schema: public; Owner: Elysian
--

CREATE INDEX "IX_Versions_ModelId" ON public."Versions" USING btree ("ModelId");


--
-- Name: CalcMethods FK_CalcMethods_ObjectiveTypes_ObjectiveTy; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."CalcMethods"
    ADD CONSTRAINT "FK_CalcMethods_ObjectiveTypes_ObjectiveTy" FOREIGN KEY ("ObjectiveTypeId") REFERENCES public."ObjectiveTypes"("ObjectiveTypeId") ON DELETE CASCADE;


--
-- Name: ClQuestionnaires FK_ClQuestionnaires_ObjectiveTypes_ObjectiveTypeId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ClQuestionnaires"
    ADD CONSTRAINT "FK_ClQuestionnaires_ObjectiveTypes_ObjectiveTypeId" FOREIGN KEY ("ObjectiveTypeId") REFERENCES public."ObjectiveTypes"("ObjectiveTypeId");


--
-- Name: Codes FK_Codes_Domains_DomainId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Codes"
    ADD CONSTRAINT "FK_Codes_Domains_DomainId" FOREIGN KEY ("DomainId") REFERENCES public."Domains"("DomainId");


--
-- Name: Models FK_Models_Domains_DomainId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Models"
    ADD CONSTRAINT "FK_Models_Domains_DomainId" FOREIGN KEY ("DomainId") REFERENCES public."Domains"("DomainId");


--
-- Name: ObjectiveTypes FK_ObjectiveTypes_Domains_DomainId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."ObjectiveTypes"
    ADD CONSTRAINT "FK_ObjectiveTypes_Domains_DomainId" FOREIGN KEY ("DomainId") REFERENCES public."Domains"("DomainId");


--
-- Name: Policies FK_Policies_Domains_DomainId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Policies"
    ADD CONSTRAINT "FK_Policies_Domains_DomainId" FOREIGN KEY ("DomainId") REFERENCES public."Domains"("DomainId");


--
-- Name: Policies FK_Policies_ObjectiveTypes_ObjectiveTypeId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Policies"
    ADD CONSTRAINT "FK_Policies_ObjectiveTypes_ObjectiveTypeId" FOREIGN KEY ("ObjectiveTypeId") REFERENCES public."ObjectiveTypes"("ObjectiveTypeId");


--
-- Name: PublishRequests FK_PublishRequests_Versions_VersionId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."PublishRequests"
    ADD CONSTRAINT "FK_PublishRequests_Versions_VersionId" FOREIGN KEY ("VersionId") REFERENCES public."Versions"("VersionId") ON DELETE CASCADE;


--
-- Name: SessionEntries FK_SessionEntries_Sessions_SessionId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."SessionEntries"
    ADD CONSTRAINT "FK_SessionEntries_Sessions_SessionId" FOREIGN KEY ("SessionId") REFERENCES public."Sessions"("SessionId") ON DELETE CASCADE;


--
-- Name: SupervisorDict FK_SupervisorDict_Supervisors_SupervisorId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."SupervisorDict"
    ADD CONSTRAINT "FK_SupervisorDict_Supervisors_SupervisorId" FOREIGN KEY ("SupervisorId") REFERENCES public."Supervisors"("SupervisorId") ON DELETE CASCADE;


--
-- Name: VersionProps FK_VersionProps_Versions_VersionId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."VersionProps"
    ADD CONSTRAINT "FK_VersionProps_Versions_VersionId" FOREIGN KEY ("VersionId") REFERENCES public."Versions"("VersionId") ON DELETE CASCADE;


--
-- Name: Versions FK_Versions_Models_ModelId; Type: FK CONSTRAINT; Schema: public; Owner: Elysian
--

ALTER TABLE ONLY public."Versions"
    ADD CONSTRAINT "FK_Versions_Models_ModelId" FOREIGN KEY ("ModelId") REFERENCES public."Models"("ModelId") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

